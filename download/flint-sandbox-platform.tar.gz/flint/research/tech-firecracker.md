# Firecracker Internals — Deep Dive (R4 research)

Sources: firecracker-microvm/firecracker `main` docs (design.md, jailer.md, vsock.md, snapshot-support.md, mmds-user-guide.md, SPECIFICATION.md, `src/firecracker/swagger/firecracker.yaml` — fetched 2026-02), NSDI'20 paper "Firecracker: Lightweight Virtualization for Serverless Applications" (https://www.usenix.org/system/files/nsdi20-paper-agache.pdf), E2B runtime source (github.com/e2b-dev/runtime, formerly e2b-dev/infra).

## 1. What Firecracker is

- A **Rust VMM** (virtual machine monitor) built by AWS, open-sourced 2018 (Apache-2.0), powering **AWS Lambda and Fargate**. It talks directly to **`/dev/kvm`** (Linux KVM) and boots "microVMs": minimal VMs with a very small device model. Written for *serverless*: fast startup, high density, multi-tenant security.
- Deliberately **excluded**: display/framebuffer, USB, PCI bus emulation (uses MMIO-based virtio), hotplug of most devices, live migration, vhost kernel backends (vhost-vsock/vhost-net are **not** used — Firecracker implements virtio device models in userspace on a single epoll loop). Each Firecracker process encapsulates **exactly one microVM**.
- **NSDI'20 paper numbers**: at launch Lambda paid ~44 MB RSS per VM + boot cost; Firecracker reduced memory overhead 11–37× vs their previous QEMU-based stack, supports >1000 VMs on one 72-vCPU host (paper: ~1020 active VMs, ~23k previously-run in 14h), boot **125 ms** from `InstanceStart` to `/sbin/init`.

## 2. Process/thread architecture (design.md)

One process = one microVM, with threads:

| Thread | Role |
|---|---|
| **API thread** | HTTP server on a **Unix Domain Socket** (default `/run/firecracker.socket`; when jailed: `<chroot_dir>/run/firecracker.socket`). Serves the REST API described by the swagger. Never in the I/O fast path. |
| **VMM thread** | Machine model, legacy device model (i8042, serial console), **MMDS**, virtio net/blk/vsock device models, rate limiting. Driven by a **single epoll event loop**. When VM is `Paused`, the VMM thread stops polling events (no device emulation, no TAP/timer polling) and only serves API requests. |
| **vCPU threads** (1 per guest CPU, max 32) | Created via KVM, run the `KVM_RUN` ioctl loop. Executed guest code is considered **malicious** (threat model). |

Guest-visible devices: virtio-net, virtio-blk, virtio-vsock, virtio-balloon, virtio-rng (entropy), serial console (ttyS0), i8042 (used to deliver reboot), PMEM, plus KVM-provided PIC/IOAPIC/PIT. CPU exposure controlled by **CPU templates** (`PUT /cpu-config` with custom templates; static templates like C3/T2/T2A/S3 mask CPUID bits for cross-generation snapshot/live compatibility).

## 3. The REST API over UDS (swagger: `src/firecracker/swagger/firecracker.yaml`)

All calls go to `curl --unix-socket /run/firecracker.socket http://localhost/<resource>`. Machine-config and devices are **pre-boot only**; the swagger is the source of truth (19 API "resources" per apis.io). Key resources:

- `PUT /boot-source` — `{ "kernel_image_path", "initrd_path", "boot_args" }` (kernel required; e.g. boot_args `console=ttyS0 reboot=k panic=1 pci=off`).
- `PUT /machine-config` — `{ "vcpu_count" (1..32; 1 or even if smt=true), "mem_size_mib" (required; must be even for 2M hugepages), "smt" (default false, x86 only), "track_dirty_pages" (enables KVM dirty logging for diff snapshots), "cpu_template", "huge_pages": "None"|"Transparent"|"2M" }`. Defaults before PUT: 1 vCPU, 128 MiB.
- `PUT /drives/{drive_id}` — `{ "drive_id", "is_root_device", "path_on_host", "is_read_only", "partuuid", "io_engine": "Sync"|"Async" (Async=io_uring, kernel>5.10.51), "cache_type": "Unsafe"|"Writeback", "rate_limiter", "blk_size" (default 512), "discard", "socket" (vhost-user) }`. Patchable post-boot: `PATCH /drives/{id}` can retarget `path_on_host` and rate limiter.
- `PUT /network-interfaces/{iface_id}` — `{ "iface_id", "host_dev_name" (TAP name, pre-created by you), "guest_mac", "mtu" (68–65535; VIRTIO_NET_F_MTU), "rx_rate_limiter", "tx_rate_limiter" }`. Post-boot `PATCH` only updates rate limiters.
- `PUT /vsock` — `{ "guest_cid" (int ≥ 3), "uds_path" }` (see tech-networking.md).
- `PUT /balloon` — `{ "amount_mib", "deflate_on_oom", "stats_polling_interval_s", "free_page_hinting", "free_page_reporting" }` (required: amount_mib, deflate_on_oom); `PATCH /balloon` post-boot resizes.
- `PUT /logger`, `PUT /metrics` — log/metrics **named pipes** (must be configured before anything else; metrics flushed every 60 s). Only logger+metrics may precede `PUT /snapshot/load`.
- `PUT /mmds` + `PUT /mmds/config` — metadata service (below).
- `PUT /actions` — `{ "action_type": "InstanceStart" | "FlushMetrics" | "SendCtrlAltDel" }` (sync; 204 on success). Note: **Pause/Resume are NOT actions** — they're `PATCH /vm { "state": "Paused"|"Resumed" }`.
- `PATCH /vm` — pause/resume. `GET /` — InstanceInfo (`state`: `Not started|Running|Paused`). `GET /vm/config` — full config export.

**Cold-boot sequence (exact order, as E2B's orchestrator does it)**: start Firecracker (optionally via jailer) → set metrics → set boot-source (kernel + cmdline with `ip=...` if you want static net config) → PUT drive(s) (root drive `is_root_device=true`) → PUT network-interfaces → PUT machine-config (+ optional `/cpu-config`) → PUT entropy → PUT balloon (optional) → PUT vsock (optional) → PUT /mmds/config → PUT /mmds (metadata) → `PUT /actions {"action_type":"InstanceStart"}`.

## 4. Rate limiter

Per-device token buckets, two buckets each (`bandwidth` bytes + `ops` ops/s), each `TokenBucket = { "size" (capacity), "one_time_burst", "refill_time" (ms to refill) }`. Refill rate = size/refill_time; burst consumption is unbounded until the bucket empties. Applied to drives (`rate_limiter`), net rx/tx, vsock, pmem. E2B pattern: set initial limits at boot; `PATCH` post-boot to change (e.g. throttle a misbehaving sandbox); an *empty* RateLimiter object resets/removes a limit persisted in a snapshot. Example: entropy device default in E2B — 1 KB bucket, 100 ms refill.

## 5. MMDS (MicroVM Metadata Service)

- Host side: `PUT /mmds` sets an **arbitrary JSON** document (mutable at any time); `PUT /mmds/config { "network_interfaces": ["eth0"], "ipv4_address": "169.254.169.254", "version": "V2" }` (V2 is IMDSv2-like; V1 deprecated). Pre-boot only config.
- Guest side: HTTP requests to the link-local IP; guest needs a route (`ip route add 169.254.169.254 dev eth0`). V2 requires session tokens: `PUT http://169.254.169.254/latest/api/token` with header `X-metadata-token-ttl-seconds: 60` → token → `GET .../latest/meta-data/...` with `X-metadata-token`. E2B uses MMDS to inject sandbox ID + envd access-token hash; envd polls `getMMDSMoToken` on boot (10s timeout, 60s TTL).
- MMDS is intercepted in the virtio-net device model (it never leaves the VM's TAP; you must attach a NIC to use MMDS).

## 6. Jailer (docs/jailer.md)

Wrapper that must launch Firecracker in production. Steps: validates paths/ID (ID ≤ 64 chars) → closes all FDs → clears env → builds chroot `<chroot_base>/<exec_file_name>/<id>/root` (default `/srv/jailer`) → copies the FC binary in (so processes never share text pages) → `setrlimit` (`--resource-limit fsize=… no-file=1024`, default no-file cap 2048; `fsize` must cover snapshot memfiles ≈ guest RAM) → creates cgroups (`--cgroup cpuset.cpus=0-3 --cgroup cpu.max=...`, `--cgroup-version 1|2`) → `unshare(CLONE_NEWNS)` + `pivot_root` + `chroot` → `mknod /dev/kvm` and `/dev/net/tun` (10,200) inside jail, chown to `--uid/--gid` → optional `--netns /var/run/netns/<ns>` (setns into your pre-created netns) → `--daemonize` (setsid) / `--new-pid-ns` (CLONE_NEWPID, child PID in `firecracker.pid`) → drop uid/gid → exec Firecracker. **You must hard-link/copy kernel, rootfs, and sockets into the jail before start; jailed FC paths in API calls are relative to the jail root.** Jail-creation latency grows with host mount count (10 parallel jails = 2× slowdown at 0 mounts, 10× at 500 mounts). Jailer cleanup is your job (cgroup `notify_on_release`, systemd units).
- Firecracker itself also self-applies **seccomp** (minimal syscall allowlist, per-thread, applied before running guest code) even without the jailer.

## 7. Performance & known limits

- SPECIFICATION.md: FC process start → API socket ready in **≤ 8 CPU ms** (wall 6–60 ms, typical 12 ms); **≤ 125 ms** from `InstanceStart` to guest `/sbin/init` (minimal kernel+rootfs, serial off); >95% bare-metal CPU perf; steady mutation rate target **5 microVMs/sec/host core** (e.g. 180/s on 36 cores); memory overhead target ≤ 10 MB per microVM on top of guest RAM.
- Limits: **no nested virtualization** (KVM-in-FC not exposed), no GPU, no live migration (use snapshots), single virtio queue per net device (no multiqueue TAP), guest Linux only, host must be Linux bare-metal with KVM (`.metal` instances on AWS), snapshot restore requires **same CPU microarchitecture** + compatible host kernel (5.10→6.1 restore on same instance types is tested; not guaranteed), cgroups v1 causes slow snapshot restore (use cgroups v2), track_dirty_pages negates hugepage benefits. Boot-time only windows: machine-config/drives/net/vsock are rejected after boot; snapshot/load only before any config except logger/metrics.
