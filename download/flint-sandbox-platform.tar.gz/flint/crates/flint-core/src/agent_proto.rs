//! The guest-agent wire protocol shared by the host-side client
//! (`flint-vm`) and the in-sandbox agent (`flint-guest-agent`).
//!
//! Framing: `[u32 BE length][JSON WireMsg]` over any ordered byte stream —
//! AF_VSOCK (prod, host dials the Firecracker vsock UDS and sends
//! `CONNECT 5252\n` first) or plain TCP on localhost (dev / ProcessDriver).
//!
//! Requests carry a monotonically increasing `id`; responses match by id;
//! long-lived operations (exec, PTY, port tunnels) also push `Event`
//! frames carrying the same id. JSON keeps the protocol debuggable; the
//! format is versioned so it can move to a binary codec later without
//! changing semantics.

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

pub const PROTOCOL_VERSION: u32 = 1;
pub const AGENT_VSOCK_PORT: u32 = 5252;

/// Methods the agent serves.
pub mod methods {
    pub const PING: &str = "ping";
    pub const VERSION: &str = "version";
    pub const EXEC: &str = "exec";
    pub const PROCESS_SPAWN: &str = "process.spawn";
    pub const PROCESS_LIST: &str = "process.list";
    pub const PROCESS_KILL: &str = "process.kill";
    pub const PROCESS_SIGNAL: &str = "process.signal";
    pub const PROCESS_INPUT: &str = "process.input";
    pub const PROCESS_WAIT: &str = "process.wait";
    pub const FS_WRITE: &str = "fs.write";
    pub const FS_READ: &str = "fs.read";
    pub const FS_LIST: &str = "fs.list";
    pub const FS_MKDIR: &str = "fs.mkdir";
    pub const FS_REMOVE: &str = "fs.remove";
    pub const FS_MOVE: &str = "fs.move";
    pub const FS_STAT: &str = "fs.stat";
    pub const ENV_SET: &str = "env.set";
    pub const ENV_GET: &str = "env.get";
    pub const TERM_OPEN: &str = "term.open";
    pub const TERM_INPUT: &str = "term.input";
    pub const TERM_RESIZE: &str = "term.resize";
    pub const TERM_CLOSE: &str = "term.close";
    pub const BARRIER: &str = "barrier";
    pub const TOOLS_INVOKE: &str = "tools.invoke";
    pub const PORT_CONNECT: &str = "port.connect";
    pub const JOURNAL_STATUS: &str = "journal.status";
    pub const SHUTDOWN: &str = "shutdown";
}

/// Event kinds (for `Event.kind`).
pub mod events {
    pub const STDOUT: &str = "stdout";
    pub const STDERR: &str = "stderr";
    pub const EXIT: &str = "exit";
    pub const TERM_OUT: &str = "term.out";
    pub const PORT_DATA: &str = "port.data";
    pub const CLOSED: &str = "closed";
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "t", rename_all = "snake_case")]
pub enum WireMsg {
    /// Host → agent call.
    Req { id: u64, method: String, params: Value },
    /// Agent → host reply.
    Resp { id: u64, ok: bool, #[serde(default)] result: Value, #[serde(default)] error: Option<String> },
    /// Agent → host push (stream events).
    Ev { id: u64, seq: u64, kind: String, #[serde(default)] data: Value },
    /// Host → agent push (input frames for processes/terminals/tunnels).
    Push { id: u64, kind: String, #[serde(default)] data: Value },
}

/// Encode a frame (4-byte BE length + JSON) into `out`.
pub fn encode(msg: &WireMsg, out: &mut Vec<u8>) {
    let payload = serde_json::to_vec(msg).expect("wire msg serializes");
    out.reserve(4 + payload.len());
    out.extend_from_slice(&(payload.len() as u32).to_be_bytes());
    out.extend_from_slice(&payload);
}

/// Decoder state machine for length-prefixed frames.
#[derive(Default)]
pub struct FrameDecoder {
    buf: Vec<u8>,
}

impl FrameDecoder {
    pub fn feed(&mut self, bytes: &[u8]) {
        self.buf.extend_from_slice(bytes);
    }

    /// Pop the next complete frame, if any.
    pub fn next(&mut self) -> Option<WireMsg> {
        if self.buf.len() < 4 {
            return None;
        }
        let len = u32::from_be_bytes([self.buf[0], self.buf[1], self.buf[2], self.buf[3]]) as usize;
        if len > 64 * 1024 * 1024 {
            // Protocol violation; drop everything (caller should close).
            self.buf.clear();
            return None;
        }
        if self.buf.len() < 4 + len {
            return None;
        }
        let payload = self.buf[4..4 + len].to_vec();
        self.buf.drain(..4 + len);
        serde_json::from_slice(&payload).ok()
    }
}

// ---------------------------------------------------------------------------
// Typed params/results helpers
// ---------------------------------------------------------------------------

pub fn params_exec(spec: &crate::ExecSpec, op_id: &str) -> Value {
    json!({ "spec": spec, "op_id": op_id })
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ExecEvent {
    pub kind: String, // stdout | stderr | exit
    #[serde(default)]
    pub data_b64: String,
    #[serde(default)]
    pub exit_code: Option<i32>,
    #[serde(default)]
    pub signal: Option<i32>,
    #[serde(default)]
    pub timed_out: bool,
}

pub fn fs_write_params(path: &str, content_b64: &str, mode: Option<u32>, op_id: &str) -> Value {
    json!({ "path": path, "content_b64": content_b64, "mode": mode, "op_id": op_id })
}

pub fn fs_path_params(path: &str, op_id: &str) -> Value {
    json!({ "path": path, "op_id": op_id })
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FsEntry {
    pub path: String,
    pub name: String,
    pub is_dir: bool,
    pub size_b: u64,
    #[serde(default)]
    pub mode: u32,
    #[serde(default)]
    pub mtime_ms: i64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frame_roundtrip() {
        let msg = WireMsg::Req { id: 7, method: "ping".into(), params: json!({}) };
        let mut buf = Vec::new();
        encode(&msg, &mut buf);
        assert_eq!(u32::from_be_bytes([buf[0], buf[1], buf[2], buf[3]]) as usize, buf.len() - 4);

        let mut dec = FrameDecoder::default();
        dec.feed(&buf[..buf.len() - 2]); // partial
        assert!(dec.next().is_none());
        dec.feed(&buf[buf.len() - 2..]);
        assert_eq!(dec.next(), Some(msg));
        assert!(dec.next().is_none());
    }

    #[test]
    fn events_split_across_feeds() {
        let msgs = vec![
            WireMsg::Resp { id: 1, ok: true, result: json!({"a": 1}), error: None },
            WireMsg::Ev { id: 1, seq: 0, kind: "stdout".into(), data: json!({"d": "aGk="}) },
        ];
        let mut buf = Vec::new();
        for m in &msgs {
            encode(m, &mut buf);
        }
        let mut dec = FrameDecoder::default();
        dec.feed(&buf[..7]);
        dec.feed(&buf[7..43]);
        dec.feed(&buf[43..]);
        assert_eq!(dec.next(), Some(msgs[0].clone()));
        assert_eq!(dec.next(), Some(msgs[1].clone()));
        assert!(dec.next().is_none());
    }
}
