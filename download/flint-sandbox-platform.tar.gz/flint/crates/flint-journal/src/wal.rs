//! The write-ahead log: CRC32-framed JSON records with crash-truncating
//! recovery.
//!
//! Record framing: `[u32 BE payload_len][u32 BE crc32(payload)][payload]`.
//! Recovery scans sequentially, stops at the first record whose length,
//! CRC or JSON is invalid, and reports the valid prefix (classic torn-tail
//! handling — the same approach SQLite takes with its WAL).

use crate::ops::Op;
use serde::{Deserialize, Serialize};
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum WalRecord {
    /// An operation was accepted and dispatched to the sandbox.
    OpApplied { op_id: String, op: Op },
    /// Guest-side durability barrier reached.
    Barrier,
    /// A snapshot was cut at this WAL position.
    SnapshotRef { snap_id: String, wal_seq: u64, manifest_json: String },
    /// Sandbox state transition.
    StateChange { from: String, to: String },
    /// Extension point (forward compatibility).
    Custom { kind: String, json: String },
}

impl From<WalError> for flint_core::FlintError {
    fn from(e: WalError) -> Self {
        flint_core::FlintError::Internal(format!("wal: {e}"))
    }
}

#[derive(Debug, thiserror::Error)]
pub enum WalError {
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("serialize: {0}")]
    Serde(#[from] serde_json::Error),
    #[error("bad record at seq {0}: {1}")]
    BadRecord(u64, String),
}

/// Scan a WAL file and return the valid record prefix.
/// Returns `(records, tail_truncated)` where records are `(seq, record)`
/// with seq starting at 1. A truncated tail is normal after a crash.
pub fn recover_records(path: &Path) -> (Vec<(u64, WalRecord)>, bool) {
    let mut records = Vec::new();
    let mut truncated = false;
    let data = match std::fs::read(path) {
        Ok(d) => d,
        Err(_) => return (records, false),
    };
    let mut off = 0usize;
    let mut seq: u64 = 0;
    while off + 8 <= data.len() {
        let len = u32::from_be_bytes([data[off], data[off + 1], data[off + 2], data[off + 3]]) as usize;
        let crc = u32::from_be_bytes([data[off + 4], data[off + 5], data[off + 6], data[off + 7]]);
        let start = off + 8;
        let end = start.checked_add(len);
        let Some(end) = end else { truncated = true; break };
        if end > data.len() {
            truncated = true;
            break;
        }
        let payload = &data[start..end];
        if crc32fast::hash(payload) != crc {
            truncated = true;
            break;
        }
        match serde_json::from_slice::<WalRecord>(payload) {
            Ok(rec) => {
                seq += 1;
                records.push((seq, rec));
            }
            Err(_) => {
                truncated = true;
                break;
            }
        }
        off = end;
    }
    if off < data.len() {
        truncated = true;
    }
    (records, truncated)
}

/// Append-only WAL handle.
pub struct Wal {
    path: PathBuf,
    file: File,
    next_seq: u64,
    fsync: crate::FsyncPolicy,
}

impl Wal {
    /// Open (create) a WAL for appending. Recovers the last valid seq.
    pub fn open(path: &Path, fsync: crate::FsyncPolicy) -> Result<Wal, WalError> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let (records, truncated) = recover_records(path);
        if truncated {
            // Truncate the torn tail so future appends are clean.
            let valid_bytes: usize = {
                // Recompute where the valid prefix ends.
                let data = std::fs::read(path)?;
                let mut off = 0usize;
                for (_seq, rec) in &records {
                    let payload = serde_json::to_vec(rec).expect("serialize record");
                    off += 8 + payload.len();
                }
                off.min(data.len())
            };
            let f = OpenOptions::new().write(true).open(path)?;
            f.set_len(valid_bytes as u64)?;
            f.sync_all()?;
            tracing::info!(wal = %path.display(), valid = records.len(), "truncated torn WAL tail");
        }
        let file = OpenOptions::new().create(true).append(true).open(path)?;
        Ok(Wal { path: path.to_path_buf(), file, next_seq: records.len() as u64, fsync })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Next sequence number that will be assigned.
    pub fn next_seq(&self) -> u64 {
        self.next_seq + 1
    }

    /// Current durable sequence count.
    pub fn len(&self) -> u64 {
        self.next_seq
    }

    pub fn is_empty(&self) -> bool {
        self.next_seq == 0
    }

    /// Append a record; returns its seq. With `FsyncPolicy::Always` the
    /// record is fsync'd before returning (write-ahead discipline).
    pub fn append(&mut self, record: WalRecord) -> Result<u64, WalError> {
        let payload = serde_json::to_vec(&record)?;
        let crc = crc32fast::hash(&payload);
        let mut frame = Vec::with_capacity(payload.len() + 8);
        frame.extend_from_slice(&(payload.len() as u32).to_be_bytes());
        frame.extend_from_slice(&crc.to_be_bytes());
        frame.extend_from_slice(&payload);
        self.file.write_all(&frame)?;
        if self.fsync == crate::FsyncPolicy::Always {
            self.file.sync_all()?;
        }
        self.next_seq += 1;
        Ok(self.next_seq)
    }

    /// Force-fsync (used for barriers and pre-snapshot flushes).
    pub fn barrier(&mut self) -> Result<u64, WalError> {
        self.append(WalRecord::Barrier)?;
        self.file.sync_all()?;
        Ok(self.next_seq)
    }

    pub fn size_bytes(&self) -> u64 {
        self.file.metadata().map(|m| m.len()).unwrap_or(0)
    }
}

/// Read a WAL file fully into memory and drop the file (used by tests and
/// by reconciliation tooling).
pub fn read_all(path: &Path) -> Vec<WalRecord> {
    let mut f = match File::open(path) {
        Ok(f) => f,
        Err(_) => return Vec::new(),
    };
    let mut buf = Vec::new();
    if f.read_to_end(&mut buf).is_err() {
        return Vec::new();
    }
    recover_records(path).0.into_iter().map(|(_, r)| r).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::ops::Op;
    use flint_core::ExecSpec;

    fn tmp_wal() -> (tempfile::TempDir, std::path::PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let p = dir.path().join("wal.log");
        (dir, p)
    }

    #[test]
    fn append_recover_roundtrip() {
        let (_d, p) = tmp_wal();
        let mut wal = Wal::open(&p, crate::FsyncPolicy::Always).unwrap();
        wal.append(WalRecord::OpApplied {
            op_id: "op_1".into(),
            op: Op::FileWrite { path: "/a".into(), content_b64: "aGk=".into(), mode: None },
        })
        .unwrap();
        wal.append(WalRecord::StateChange { from: "creating".into(), to: "running".into() }).unwrap();
        drop(wal);

        let (recs, truncated) = recover_records(&p);
        assert_eq!(recs.len(), 2);
        assert!(!truncated);
        assert_eq!(recs[0].0, 1);
        match &recs[0].1 {
            WalRecord::OpApplied { op_id, .. } => assert_eq!(op_id, "op_1"),
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn torn_tail_is_truncated() {
        let (_d, p) = tmp_wal();
        let mut wal = Wal::open(&p, crate::FsyncPolicy::Always).unwrap();
        wal.append(WalRecord::Barrier).unwrap();
        wal.append(WalRecord::Barrier).unwrap();
        drop(wal);

        // Simulate a crash mid-write: append garbage partial frame.
        let mut f = OpenOptions::new().append(true).open(&p).unwrap();
        f.write_all(&[0x00, 0x00, 0x10, 0x00, 0xAB]).unwrap();
        drop(f);

        let (recs, truncated) = recover_records(&p);
        assert_eq!(recs.len(), 2);
        assert!(truncated);

        // Reopening truncates the torn tail; appends continue cleanly.
        let mut wal = Wal::open(&p, crate::FsyncPolicy::Always).unwrap();
        assert_eq!(wal.len(), 2);
        wal.append(WalRecord::Barrier).unwrap();
        drop(wal);
        let (recs, truncated) = recover_records(&p);
        assert_eq!(recs.len(), 3);
        assert!(!truncated);
    }

    #[test]
    fn corruption_mid_file_stops_replay() {
        let (_d, p) = tmp_wal();
        let mut wal = Wal::open(&p, crate::FsyncPolicy::Always).unwrap();
        wal.append(WalRecord::Barrier).unwrap();
        wal.append(WalRecord::OpApplied {
            op_id: "op_2".into(),
            op: Op::Exec { spec: ExecSpec::shell("true") },
        })
        .unwrap();
        drop(wal);

        // Corrupt the second record's payload byte.
        let data = std::fs::read(&p).unwrap();
        let mut corrupted = data.clone();
        *corrupted.last_mut().unwrap() ^= 0xFF;
        std::fs::write(&p, &corrupted).unwrap();

        let (recs, truncated) = recover_records(&p);
        assert_eq!(recs.len(), 1);
        assert!(truncated);
    }
}
