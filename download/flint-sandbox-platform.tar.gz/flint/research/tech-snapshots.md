# Snapshot / Restore Strategies for Firecracker microVMs (R4 research)

Sources: `docs/snapshotting/snapshot-support.md`, `network-for-clones.md`, `random-for-clones.md`, `versioning.md`, `handling-page-faults-on-snapshot-resume.md` (firecracker main), E2B runtime source + ARCHITECTURE.md, AWS Lambda snapshot docs, BuildBuddy/Snapipeline systems research.

## 1. The Firecracker snapshot model

A snapshot = **two files** (+ disks, which are *yours* to manage):

1. **Memory file** (`mem_file_path`): raw guest RAM image.
2. **microVM state file** (`snapshot_path`, "snapfile"): serialized KVM state (vCPU registers, MP state), device emulation state, GIC state on arm64. Versioned `MAJOR.MINOR.PATCH`; loader validates version + 64-bit CRC (integrity against accidental corruption only — encryption/auth is your job when snapshots cross a trust boundary).

Block device backing files are **not** included; they are drained + `fsync`'d by `CreateSnapshot` and must be provided at the same relative path at restore time.

## 2. Exact pause → snapshot → restore sequence

```
# 1. Pause (VM must be booted; vCPU threads stop, device emulation stops)
curl --unix-socket fc.sock -X PATCH http://localhost/vm -d '{"state":"Paused"}'
# 2. Create snapshot (VM must be Paused)
curl --unix-socket fc.sock -X PUT http://localhost/snapshot/create -d '{
  "snapshot_type": "Full",            # or "Diff" (developer preview)
  "snapshot_path": "./snapfile",
  "mem_file_path": "./memfile",
  "sync_snapshot_files": true         # fsync before returning; false = faster, page-cache only
}'
# 3. (original VM can be resumed: PATCH /vm {"state":"Resumed"} — or killed)
# 4. Restore: fresh Firecracker process, configure ONLY logger/metrics, then:
curl --unix-socket fc.sock -X PUT http://localhost/snapshot/load -d '{
  "snapshot_path": "./snapfile",
  "mem_backend": { "backend_type": "File", "backend_path": "./memfile" },
  "track_dirty_pages": true,          # enable KVM dirty log for future diffs
  "resume_vm": false,                 # if true, auto-resumes after load
  "clock_realtime": true,             # x86_64, host>=5.16: advance kvmclock to wall time
  "network_overrides": [ { "iface_id": "eth0", "host_dev_name": "vmtap01" } ],
  "vsock_override":   { "uds_path": "./v.sock.2" }
}'
# 5. Resume
curl --unix-socket fc.sock -X PATCH http://localhost/vm -d '{"state":"Resumed"}'
```

**Restore semantics (the important details):**
- `File` backend: Firecracker `mmap`s the memory file **MAP_PRIVATE** — pages load **on demand via page faults**, writes go to a private COW copy. Restore is nearly instant (only snapfile is parsed), but **the memfile must live as long as the VM and be treated as immutable** (external mutation corrupts the guest).
- `Uffd` backend: `backend_path` is a **UDS where your handler listens**. Flow: handler binds UDS → `PUT /snapshot/load` with backend_type=Uffd → FC creates userfaultfd, anonymously mmaps guest RAM, connects to your UDS and **passes the uffd FD + memory layout (region sizes, page size)** → your handler `mmap`s the template memfile and serves `UFFDIO_COPY` on each fault. This is how E2B serves pages **from object storage/NFS/local cache lazily**, plus a prefetcher for known-hot pages (template "optimize" phase records which pages a fresh resume touches). Kernel 6.1+: use `/dev/userfaultfd` (jailer makes it available in the jail). E2B extras: `use_memfd`, `use_sync_wp` custom extensions; wait for "uffd ready" event before resume.
- Diff snapshots: require `track_dirty_pages: true` in machine-config (or at load). KVM dirty-log gives exact dirty pages; without it FC falls back to `mincore(2)` (**requires swap disabled**, may over-include). Diffs are sparse files, **not independently resumable** (except diffs of booted VMs) — merge with `snapshot-editor edit-memory rebase --memory-path base --diff-path layer` in creation order; use the state file from the *last* create call.
- **Snapshot load failure kills the Firecracker process** (it may be in an invalid state) — orchestrators must expect the process to die and restart cleanly.

## 3. Snapshot gotchas (production pain points)

- **Network**: snapshot stores the *TAP device name* and guest net config. All clones restore with identical IPs/MAC/ARP state. Fixes: (a) per-clone **network namespaces** so the same TAP name exists per VM (Firecracker's own doc pattern: `ip netns add fcN` + `ip netns exec fcN ip tuntap add name vmtap0 mode tap` + veth to host + iptables MASQUERADE; guest may need `ip neigh flush` to clear stale ARP); (b) `network_overrides` at load to point `iface_id` at a fresh TAP, then push new IP config to the guest via vsock/MMDS. TCP connections do **not** survive; packet loss on both net and vsock is expected. E2B sidesteps this: every sandbox always gets a slot with identical TAP name/IPs (`tap0`, guest `169.254.0.21/30`, gw `169.254.0.22`) and **the same shared TAP MAC on the host side** (`02:FC:00:00:00:06`), so a resumed guest's cached ARP entry stays valid; the outer /31 veth address is what's unique.
- **vsock**: all open vsock connections are killed at `SnapshotCreate` — FC sends `VIRTIO_VSOCK_EVENT_TRANSPORT_RESET`; listen sockets in the guest survive and can accept new connections after resume (CID updated to current `guest_cid`). Host-side UDS path collisions on clones → use `vsock_override` (or jailer-per-VM paths).
- **Uniqueness/security**: resuming the same snapshot more than once duplicates entropy, secrets, tokens, machine IDs. FC ships **VMGenID** (16-byte ACPI ID regenerated at every resume + interrupt; Linux ≥5.18 reseeds the kernel PRNG) and **VMClock** (`vm_generation_counter` readable/pollable by userspace — needs patched kernel ≥ 6.1 backports / v7.0). Userspace RNG state must be re-seeded by your agent. Snapshot-before-full-boot can crash on resume (VMGenID interrupt unhandled) — snapshot **only after guest userspace is up**.
- **Clock**: guest wall clock resumes from snapshot time; fix with NTP/systemd-timesyncd in guest, or `clock_realtime: true` (x86, kvm-clock only). x86 quirk: FC rewrites `MSR_IA32_TSC_DEADLINE=0` to the vCPU's TSC so lost timer interrupts still fire.
- **Portability**: restore only on **identical CPU microarchitecture**; same or (5.10→6.1, same instance type) newer host kernel. Pin CPU templates (`/cpu-config`) to be safe across fleet hardware.
- **MMDS config survives snapshots; MMDS *data* does not** — re-`PUT /mmds` after load. Metrics/logger config also must be re-set.
- **Disk space**: memfiles are as big as guest RAM; enforce quotas (DoS vector); E2B refuses pauses when disk headroom (mem + rootfs cache + snapfile allowance, doubled for local template storage) is insufficient (`pause-admission-disk-headroom-mib`).

## 4. CRIU vs Firecracker snapshots

CRIU checkpoints a **process tree** (dump /proc/PID state: memory maps, FDs, sockets, IPC) and requires a cooperating kernel + per-syscall handling; anything not merged into the kernel (weird io_uring, exotic BPF, GPU state) fails. Firecracker snapshots a **whole machine** at the KVM boundary — every guest process is captured implicitly, so "arbitrary user code" works with zero per-app awareness. Container runtimes checkpointing = CRIU on the host namespace model (runc checkpoint, Docker `checkpoint`), fragile for the same reasons; microVM snapshotting = one consistent world, at the cost of RAM-sized images and no cross-CPU portability. OpenJDK CRaC exists precisely because Java couldn't snapshot; CRaC + FC snapshots make both layers stateless-friendly. See kata-containers issue #13754 for the same "VM-level CRIU" argument.

## 5. Durable disk state: overlayfs upperdir as incremental journal

- **overlayfs pattern (E2B blog, Feb 2025 "Scaling Firecracker: Using OverlayFS to save disk space")**: mount guest root as `overlay` with read-only template lowerdir (e.g. squashfs rootfs) + per-sandbox upperdir (`upper/`, `work/`). COW copy-up makes upperdir an **incremental journal of all filesystem changes** — pause = upload the (tiny) upperdir; resume = re-mount overlay; no block-level dedup needed. Guest-side approach: initramfs `overlay-init` script sets up `/ = overlay(lower=ro squashfs, upper=tmpfs or /dev/vdb)` then execs real init.
- **E2B's current production evolution**: the guest sees a **flat ext4 rootfs drive**; the *host* runs an in-process **userspace NBD server** presenting a COW block device (template rootfs read-only base + per-sandbox dirty-block cache) to Firecracker as a normal virtio-blk drive. On pause, dirty blocks are exported as a **block-level diff** (`reflink`-sealed in background: "deferred-rootfs-export"), uploaded keyed `{buildID}/rootfs.ext4` + `.header` index; chains resolved through header files. Same artifact shape for templates and paused sandboxes — "a sandbox **is** a resumed snapshot + disk diff layers". Filesystem-only checkpoints (`memory:false`) export rootfs only → cold boot next time (with jailed `e2fsck -p -E journal_only` pre-boot recovery).
- **Event-sourcing / op-log alternative**: instead of snapshots, stream every mutating operation (file writes, execs) through the agent into an append-only log, and reconstruct by replay. Pros: tiny deltas, forkable history, human-inspectable. Cons: needs full control of the workload (users bypassing the agent breaks it), replay is slow for bulk writes. Hybrid is best-practice: **block/page-level COW diffs for capture + op-log for audit/replayable events**.

## 6. Recommended durability design (for our platform)

1. Templates = pre-booted snapshot (memfile + snapfile + read-only rootfs), UFFD-served from object storage with local/NFS chunk cache.
2. Pause: FC `Paused` → `CreateSnapshot (Full, sync=false)` → export NBD dirty blocks as rootfs diff → async upload with retry budget; local cache keeps it resumable on the origin node ("resume prefers origin node").
3. Track everything as **layered builds** (E2B: `env_builds` table; layers hashed & cached; superseded-layer pin/refcount eviction).
4. Never resume a memory snapshot twice into parallel worlds without re-keying (VMGenID + agent-side re-seed + fresh network identity).
