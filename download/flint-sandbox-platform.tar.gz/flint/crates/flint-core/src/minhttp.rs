//! Minimal HTTP/1.1 client that works over *any* async byte stream
//! (Unix sockets, TCP, port tunnels). Used for the Firecracker UDS API
//! and the gateway's sandbox preview proxy.
//!
//! Supports request bodies, `Content-Length` and `chunked` responses,
//! and connection-close framing. Deliberately tiny: no redirects, no
//! compression, no keep-alive pools — callers open a stream per request.

use crate::{FlintError, Result};
use tokio::io::{AsyncReadExt, AsyncWriteExt};

pub struct HttpResponse {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

impl HttpResponse {
    pub fn header(&self, name: &str) -> Option<&str> {
        self.headers
            .iter()
            .find(|(k, _)| k.eq_ignore_ascii_case(name))
            .map(|(_, v)| v.as_str())
    }

    pub fn body_string(&self) -> String {
        String::from_utf8_lossy(&self.body).into_owned()
    }

    pub fn is_success(&self) -> bool {
        (200..300).contains(&self.status)
    }
}

fn encode_request(method: &str, path: &str, headers: &[(&str, &str)], body: Option<&[u8]>) -> Vec<u8> {
    let mut out = format!("{method} {path} HTTP/1.1\r\nHost: localhost\r\n");
    for (k, v) in headers {
        out.push_str(&format!("{k}: {v}\r\n"));
    }
    let body = body.unwrap_or(&[]);
    if !body.is_empty() {
        out.push_str(&format!("Content-Length: {}\r\n", body.len()));
        out.push_str("Content-Type: application/json\r\n");
    }
    if body.is_empty() {
        out.push_str("Content-Length: 0\r\n");
    }
    out.push_str("Connection: close\r\n\r\n");
    let mut bytes = out.into_bytes();
    bytes.extend_from_slice(body);
    bytes
}

/// Encode a minimal GET request (used by the preview proxy to speak HTTP
/// through sandbox port tunnels).
pub fn encode_request_for(method: &str, path: &str) -> Vec<u8> {
    encode_request(method, path, &[], None)
}

/// Issue one HTTP request over `stream`.
pub async fn request_over<S>(
    stream: &mut S,
    method: &str,
    path: &str,
    headers: &[(&str, &str)],
    body: Option<&[u8]>,
) -> Result<HttpResponse>
where
    S: AsyncReadExt + AsyncWriteExt + Unpin,
{
    let req = encode_request(method, path, headers, body);
    stream.write_all(&req).await?;
    stream.flush().await?;

    // Read the head.
    let mut buf: Vec<u8> = Vec::with_capacity(1024);
    let mut tmp = [0u8; 4096];
    let head_end = loop {
        if let Some(pos) = find_head_end(&buf) {
            break pos;
        }
        let n = stream.read(&mut tmp).await?;
        if n == 0 {
            return Err(FlintError::Internal("http: stream closed before headers".into()));
        }
        buf.extend_from_slice(&tmp[..n]);
        if buf.len() > 64 * 1024 {
            return Err(FlintError::Internal("http: response head too large".into()));
        }
    };

    let head = String::from_utf8_lossy(&buf[..head_end]).into_owned();
    let mut lines = head.split("\r\n");
    let status_line = lines.next().unwrap_or_default();
    let status: u16 = status_line
        .split_whitespace()
        .nth(1)
        .and_then(|s| s.parse().ok())
        .ok_or_else(|| FlintError::Internal(format!("http: bad status line: {status_line}")))?;

    let mut hdrs = Vec::new();
    for line in lines {
        if line.is_empty() {
            continue;
        }
        if let Some((k, v)) = line.split_once(':') {
            hdrs.push((k.trim().to_string(), v.trim().to_string()));
        }
    }

    let mut body_bytes = buf[head_end + 4..].to_vec();
    let content_length = hdrs
        .iter()
        .find(|(k, _)| k.eq_ignore_ascii_case("content-length"))
        .and_then(|(_, v)| v.parse::<usize>().ok());
    let chunked = hdrs
        .iter()
        .any(|(k, v)| k.eq_ignore_ascii_case("transfer-encoding") && v.to_ascii_lowercase().contains("chunked"));

    if chunked {
        body_bytes = decode_chunked(stream, body_bytes).await?;
    } else if let Some(cl) = content_length {
        while body_bytes.len() < cl {
            let n = stream.read(&mut tmp).await?;
            if n == 0 {
                break;
            }
            body_bytes.extend_from_slice(&tmp[..n]);
        }
        body_bytes.truncate(cl);
    } else if status != 204 && status != 304 {
        // Read until close.
        loop {
            let n = stream.read(&mut tmp).await?;
            if n == 0 {
                break;
            }
            body_bytes.extend_from_slice(&tmp[..n]);
            if body_bytes.len() > 64 * 1024 * 1024 {
                return Err(FlintError::Internal("http: response body too large".into()));
            }
        }
    }

    Ok(HttpResponse { status, headers: hdrs, body: body_bytes })
}

fn find_head_end(buf: &[u8]) -> Option<usize> {
    buf.windows(4).position(|w| w == b"\r\n\r\n")
}

async fn decode_chunked<S: AsyncReadExt + Unpin + AsyncWriteExt>(
    stream: &mut S,
    mut carry: Vec<u8>,
) -> Result<Vec<u8>> {
    let mut out = Vec::new();
    let mut tmp = [0u8; 4096];
    loop {
        // Ensure we have a size line.
        let line_end = loop {
            if let Some(pos) = find_crlf(&carry) {
                break pos;
            }
            let n = stream.read(&mut tmp).await?;
            if n == 0 {
                return Err(FlintError::Internal("http: chunked stream ended early".into()));
            }
            carry.extend_from_slice(&tmp[..n]);
        };
        let size_str = String::from_utf8_lossy(&carry[..line_end]).into_owned();
        let size = usize::from_str_radix(size_str.trim().split(';').next().unwrap_or("0"), 16)
            .map_err(|_| FlintError::Internal(format!("http: bad chunk size: {size_str}")))?;
        let mut consumed = line_end + 2;
        if size == 0 {
            return Ok(out);
        }
        // Read `size` payload bytes + trailing CRLF.
        while carry.len() < consumed + size + 2 {
            let n = stream.read(&mut tmp).await?;
            if n == 0 {
                return Err(FlintError::Internal("http: chunked stream ended early".into()));
            }
            carry.extend_from_slice(&tmp[..n]);
        }
        out.extend_from_slice(&carry[consumed..consumed + size]);
        consumed += size + 2;
        carry.drain(..consumed);
    }
}

fn find_crlf(buf: &[u8]) -> Option<usize> {
    buf.windows(2).position(|w| w == b"\r\n")
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::io::duplex;

    #[tokio::test]
    async fn request_roundtrip_content_length() {
        let (mut client, mut server) = duplex(8192);
        let server_task = tokio::spawn(async move {
            let mut buf = vec![0u8; 4096];
            // Read request head.
            let mut got = Vec::new();
            loop {
                let n = server.read(&mut buf).await.unwrap();
                got.extend_from_slice(&buf[..n]);
                if let Some(pos) = find_head_end(&got) {
                    // read body
                    let head = String::from_utf8_lossy(&got[..pos]).into_owned();
                    let cl: usize = head
                        .lines()
                        .find(|l| l.to_lowercase().starts_with("content-length:"))
                        .and_then(|l| l.split(':').nth(1))
                        .and_then(|v| v.trim().parse().ok())
                        .unwrap_or(0);
                    while got.len() < pos + 4 + cl {
                        let n = server.read(&mut buf).await.unwrap();
                        got.extend_from_slice(&buf[..n]);
                    }
                    break;
                }
            }
            let resp = "HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\nhello";
            server.write_all(resp.as_bytes()).await.unwrap();
        });

        let resp = request_over(&mut client, "PUT", "/machine-config", &[], Some(br#"{"x":1}"#))
            .await
            .unwrap();
        assert_eq!(resp.status, 200);
        assert_eq!(resp.body_string(), "hello");
        server_task.await.unwrap();
    }

    #[tokio::test]
    async fn request_roundtrip_chunked() {
        let (mut client, mut server) = duplex(8192);
        let server_task = tokio::spawn(async move {
            let mut buf = vec![0u8; 4096];
            let mut got = Vec::new();
            loop {
                let n = server.read(&mut buf).await.unwrap();
                got.extend_from_slice(&buf[..n]);
                if find_head_end(&got).is_some() {
                    break;
                }
            }
            let resp = "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nabc\r\n5\r\ndefgh\r\n0\r\n\r\n";
            server.write_all(resp.as_bytes()).await.unwrap();
        });

        let resp = request_over(&mut client, "GET", "/instance-info", &[], None).await.unwrap();
        assert_eq!(resp.status, 200);
        assert_eq!(resp.body_string(), "abcdefgh");
        server_task.await.unwrap();
    }

    #[tokio::test]
    async fn no_content_204() {
        let (mut client, mut server) = duplex(8192);
        let server_task = tokio::spawn(async move {
            let mut buf = vec![0u8; 4096];
            let n = server.read(&mut buf).await.unwrap();
            assert!(String::from_utf8_lossy(&buf[..n]).starts_with("PUT /actions"));
            server
                .write_all(b"HTTP/1.1 204\r\nContent-Length: 0\r\n\r\n")
                .await
                .unwrap();
        });
        let resp = request_over(&mut client, "PUT", "/actions", &[], Some(br#"{"action_type":"InstanceStart"}"#))
            .await
            .unwrap();
        assert_eq!(resp.status, 204);
        assert!(resp.body.is_empty());
        server_task.await.unwrap();
    }
}
