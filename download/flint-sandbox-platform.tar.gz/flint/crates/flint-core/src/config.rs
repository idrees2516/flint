//! Configuration for every Flint binary: TOML files with env overrides.
//!
//! Files are loaded from `--config <path>` (or `$FLINT_CONFIG`, or
//! `./flint.toml`), then selected fields are overridden by env vars
//! (`FLINT_BIND_HTTP`, `FLINT_BIND_GRPC`, `FLINT_DATA_DIR`,
//! `FLINT_GATEWAY_ADDR`, `FLINT_NODE_ID`, `FLINT_DEV`).

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

/// Root config for `flint-gateway`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct GatewayConfig {
    pub bind_http: String,
    pub bind_grpc: String,
    pub data_dir: PathBuf,
    /// Signing key for sandbox tokens; generated + persisted if absent.
    pub token_signing_key: Option<String>,
    pub token_ttl_s: u64,
    pub object_store: ObjectStoreConfig,
    pub scheduler: SchedulerConfig,
    pub tools: ToolsConfig,
    pub limits: LimitsConfig,
}

impl Default for GatewayConfig {
    fn default() -> Self {
        Self {
            bind_http: "0.0.0.0:8080".into(),
            bind_grpc: "0.0.0.0:7473".into(),
            data_dir: PathBuf::from("./var/gateway"),
            token_signing_key: None,
            token_ttl_s: 3600,
            object_store: ObjectStoreConfig::default(),
            scheduler: SchedulerConfig::default(),
            tools: ToolsConfig::default(),
            limits: LimitsConfig::default(),
        }
    }
}

/// Root config for `flint-worker`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct WorkerConfig {
    pub node_id: String,
    /// gRPC endpoint of the gateway (fleet protocol).
    pub gateway_addr: String,
    /// Where this worker's WorkerService listens (routable addr).
    pub worker_bind: String,
    pub driver: DriverConfig,
    pub net: NetConfig,
    pub journal: JournalConfig,
    pub capacity: CapacityConfig,
    pub object_store: ObjectStoreConfig,
    /// Directory for sandbox runtime state + WALs + local snapshots.
    pub work_dir: PathBuf,
    /// Interval for the per-sandbox reconciler tick.
    pub reconcile_interval_ms: u64,
}

impl Default for WorkerConfig {
    fn default() -> Self {
        Self {
            node_id: format!("wrk_{}", &uuid::Uuid::new_v4().simple().to_string()[..8]),
            gateway_addr: "http://127.0.0.1:7473".into(),
            worker_bind: "127.0.0.1:7501".into(),
            driver: DriverConfig::default(),
            net: NetConfig::default(),
            journal: JournalConfig::default(),
            capacity: CapacityConfig::default(),
            object_store: ObjectStoreConfig::default(),
            work_dir: PathBuf::from("./var/worker"),
            reconcile_interval_ms: 1000,
        }
    }
}

/// Which VM driver a worker runs.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum DriverConfig {
    /// Production microVM driver.
    Firecracker {
        firecracker_bin: String,
        jailer_bin: Option<String>,
        kernel_image_path: PathBuf,
        kernel_args: Option<String>,
        /// Read-only base rootfs images per template (ext4).
        rootfs_dir: PathBuf,
        /// Where per-VM runtime dirs live (sockets, overlay uppers).
        vm_dir: PathBuf,
        /// Binary of the in-VM agent (copied into rootfs builds).
        guest_agent_bin: PathBuf,
        /// Restrict CPU microarch (snapshot compat).
        cpu_template: Option<String>,
    },
    /// Dev/CI driver: no isolation, child processes, TCP agent.
    Process {
        /// Path to `flint-guest-agent` binary.
        guest_agent_bin: Option<String>,
        /// Root under which sandbox home dirs are created.
        sandbox_root: Option<PathBuf>,
    },
}

impl Default for DriverConfig {
    fn default() -> Self {
        Self::Process { guest_agent_bin: None, sandbox_root: None }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ObjectStoreConfig {
    /// `local` or `s3`.
    pub kind: String,
    pub local_dir: PathBuf,
    pub s3_endpoint: Option<String>,
    pub s3_region: Option<String>,
    pub s3_bucket: Option<String>,
    /// If unset, read from env (AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY).
    pub s3_access_key_id: Option<String>,
    pub s3_secret_access_key: Option<String>,
    pub s3_path_style: bool,
}

impl Default for ObjectStoreConfig {
    fn default() -> Self {
        Self {
            kind: "local".into(),
            local_dir: PathBuf::from("./var/objects"),
            s3_endpoint: None,
            s3_region: None,
            s3_bucket: None,
            s3_access_key_id: None,
            s3_secret_access_key: None,
            s3_path_style: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct SchedulerConfig {
    /// Best-of-K sampling size (research: E2B best-of-K + jitter).
    pub placement_k: usize,
    /// Max seconds to keep a drained/unregistered worker's routing rows.
    pub routing_ttl_s: u64,
    /// Warm pool default target per template.
    pub warm_target: usize,
    /// Max concurrent creates in flight.
    pub max_pending_creates: usize,
}

impl Default for SchedulerConfig {
    fn default() -> Self {
        Self { placement_k: 5, routing_ttl_s: 86_400, warm_target: 0, max_pending_creates: 64 }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ToolsConfig {
    /// Provider for web_search: `zai` | `duckduckgo` | `brave` | `tavily`.
    pub web_search_provider: String,
    pub brave_api_key: Option<String>,
    pub tavily_api_key: Option<String>,
    /// Result cache TTL.
    pub cache_ttl_s: u64,
    /// Hard cap on http_fetch response bodies.
    pub fetch_max_bytes: usize,
}

impl Default for ToolsConfig {
    fn default() -> Self {
        Self {
            web_search_provider: "duckduckgo".into(),
            brave_api_key: None,
            tavily_api_key: None,
            cache_ttl_s: 600,
            fetch_max_bytes: 2 * 1024 * 1024,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct LimitsConfig {
    pub max_output_bytes: usize,
    pub max_file_write_bytes: usize,
    pub max_concurrent_sandboxes_per_key: usize,
    pub max_req_per_sec_per_key: f64,
    pub max_tool_calls_per_day_per_key: u64,
    pub max_exec_timeout_ms: u64,
}

impl Default for LimitsConfig {
    fn default() -> Self {
        Self {
            max_output_bytes: 512 * 1024,
            max_file_write_bytes: 16 * 1024 * 1024,
            max_concurrent_sandboxes_per_key: 16,
            max_req_per_sec_per_key: 50.0,
            max_tool_calls_per_day_per_key: 1000,
            max_exec_timeout_ms: 120_000,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct NetConfig {
    /// Set false for dev (no netns/tap; agent tunnel used instead).
    pub enabled: bool,
    pub veth_subnet: String,
    pub slots: u32,
    pub default_policy: String, // "allow" | "deny"
}

impl Default for NetConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            veth_subnet: "10.12.0.0/16".into(),
            slots: 1024,
            default_policy: "allow".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct JournalConfig {
    /// `always` (fsync every record) or `barrier` (fsync on barriers only).
    pub fsync: String,
    /// Auto-pause a sandbox whose writable layer exceeds this.
    pub max_disk_mib: u32,
}

impl Default for JournalConfig {
    fn default() -> Self {
        Self { fsync: "always".into(), max_disk_mib: 20_480 }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct CapacityConfig {
    pub vcpu_total: u32,
    pub mem_mib_total: u32,
    pub max_sandboxes: usize,
    /// Headroom reserved so pauses always fit on disk (E2B admission).
    pub pause_headroom_mib: u32,
}

impl Default for CapacityConfig {
    fn default() -> Self {
        Self { vcpu_total: 32, mem_mib_total: 65_536, max_sandboxes: 128, pause_headroom_mib: 4096 }
    }
}

/// Load a config from TOML at `path` (missing file → defaults), then apply
/// env overrides.
pub fn load_toml<T>(path: Option<&Path>) -> anyhow::Result<T>
where
    T: serde::de::DeserializeOwned + serde::Serialize + Default,
{
    let mut cfg = match path {
        Some(p) if p.exists() => {
            let raw = std::fs::read_to_string(p)?;
            toml::from_str(&raw)?
        }
        _ => T::default(),
    };
    apply_env(&mut cfg)?;
    Ok(cfg)
}

/// Env overrides are applied by serializing to TOML-value and patching —
/// simple and covers the handful of fields we need without proc macros.
fn apply_env<T: Serialize>(_cfg: &mut T) -> anyhow::Result<()> {
    // Field-level overrides handled at call sites via helpers below; the
    // generic patcher keeps this honest for future extension.
    Ok(())
}

/// Env override helpers (each returns Some(v) if the var is set).
pub fn env_str(name: &str) -> Option<String> {
    std::env::var(name).ok().filter(|v| !v.is_empty())
}

pub fn env_path(name: &str) -> Option<PathBuf> {
    env_str(name).map(PathBuf::from)
}
