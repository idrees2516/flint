//! Per-sandbox networking (ARCHITECTURE §9).
//!
//! Every sandbox gets a **slot**: a dedicated network namespace with a
//! veth pair to the host (management + ingress proxy path) and a TAP
//! device for the microVM NIC. The guest NIC sits at `169.254.0.21/30`
//! (set via kernel cmdline — no DHCP), the TAP at `169.254.0.22/30`;
//! one shared host-side MAC keeps snapshot-restored guests' ARP caches
//! valid (E2B trick). Egress is default-allow or default-deny with
//! IP/domain (SNI) allowlists enforced by nftables.
//!
//! All provisioning shells out to `ip`/`nft` and is idempotent + re-drivable
//! (the worker reconciler can call `ensure*` again safely). In dev mode
//! (`net.enabled = false`) everything is a no-op and ingress goes through
//! the agent-channel port tunnel instead.

use flint_core::{FlintError, Result};
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

pub const GUEST_IP: &str = "169.254.0.21";
pub const TAP_IP: &str = "169.254.0.22";
pub const TAP_MASK: &str = "255.255.255.252";
pub const GUEST_MAC: &str = "02:FC:00:00:00:05";
/// Shared host-side TAP MAC — see module docs (snapshot/ARP stability).
pub const HOST_TAP_MAC: &str = "02:FC:00:00:00:06";

// ---------------------------------------------------------------------------
// IPAM: /31 veth pairs out of a /16
// ---------------------------------------------------------------------------

/// Allocates veth `/31` pair addresses out of a `/16` pool:
/// pair `i` = `<base + 2i>` (host end) / `<base + 2i + 1>` (netns end).
pub struct IpamSlotPool {
    base: u32,
    #[allow(dead_code)]
    total: u32,
    used: std::sync::Mutex<Vec<bool>>,
}

impl IpamSlotPool {
    /// `subnet` like `10.12.0.0/16`.
    pub fn new(subnet: &str, total: u32) -> Result<Self> {
        let (net, prefix) = subnet
            .split_once('/')
            .ok_or_else(|| FlintError::InvalidParam { msg: format!("bad subnet {subnet}") })?;
        let prefix: u32 = prefix.parse().map_err(|_| FlintError::InvalidParam { msg: format!("bad prefix in {subnet}") })?;
        if prefix != 16 {
            return Err(FlintError::InvalidParam { msg: "only /16 slot pools supported in v1".into() });
        }
        let octets: Vec<u32> = net.split('.').map(|o| o.parse().unwrap_or(0)).collect();
        if octets.len() != 4 {
            return Err(FlintError::InvalidParam { msg: format!("bad subnet {subnet}") });
        }
        let base = (octets[0] << 24) | (octets[1] << 16) | (octets[2] << 8) | octets[3];
        let total = total.min(32 * 1024).max(1);
        Ok(Self { base, total, used: std::sync::Mutex::new(vec![false; total as usize]) })
    }

    pub fn allocate(&self) -> Result<Slot> {
        let mut used = self.used.lock().unwrap();
        let idx = used
            .iter()
            .position(|u| !*u)
            .ok_or(FlintError::ResourceExhausted { msg: "network slots exhausted".into() })?;
        used[idx] = true;
        let pair_base = self.base + (idx as u32) * 2;
        Ok(Slot { idx: idx as u32, host_ip: ip_to_string(pair_base), netns_ip: ip_to_string(pair_base + 1) })
    }

    pub fn release(&self, idx: u32) {
        let mut used = self.used.lock().unwrap();
        if (idx as usize) < used.len() {
            used[idx as usize] = false;
        }
    }

    pub fn free_count(&self) -> u32 {
        self.used.lock().unwrap().iter().filter(|u| !**u).count() as u32
    }
}

fn ip_to_string(v: u32) -> String {
    format!("{}.{}.{}.{}", (v >> 24) & 0xFF, (v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF)
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Slot {
    pub idx: u32,
    /// Host veth end IP (/31).
    pub host_ip: String,
    /// Netns veth end IP (/31).
    pub netns_ip: String,
}

// ---------------------------------------------------------------------------
// Egress policy
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct EgressPolicy {
    /// "allow" | "deny" — the default verdict (default-deny is one flag,
    /// Freestyle semantics).
    pub default: String,
    #[serde(default)]
    pub ip_allow: Vec<String>,
    #[serde(default)]
    pub ip_deny: Vec<String>,
    /// Domain allowlist enforced by the SNI-inspecting proxy path.
    #[serde(default)]
    pub domain_allow: Vec<String>,
}

impl EgressPolicy {
    pub fn allow_all() -> Self {
        Self { default: "allow".into(), ..Default::default() }
    }
}

// ---------------------------------------------------------------------------
// Provisioner
// ---------------------------------------------------------------------------

/// Statistics shared with metrics/heartbeats.
#[derive(Default)]
pub struct NetStats {
    pub slots_allocated: AtomicU64,
}

pub struct NetProvisioner {
    pub enabled: bool,
    pub pool: IpamSlotPool,
    pub policy: EgressPolicy,
    pub stats: Arc<NetStats>,
}

impl NetProvisioner {
    pub fn new(enabled: bool, subnet: &str, slots: u32, default_policy: &str) -> Result<Self> {
        let policy = EgressPolicy {
            default: default_policy.to_string(),
            ..Default::default()
        };
        Ok(Self { enabled, pool: IpamSlotPool::new(subnet, slots)?, policy, stats: Arc::new(NetStats::default()) })
    }

    /// Provision a slot. In dev mode returns a virtual slot with no
    /// host side effects.
    pub async fn provision(&self, sandbox_id: &str) -> Result<SlotHandle> {
        let slot = self.pool.allocate()?;
        self.stats.slots_allocated.fetch_add(1, Ordering::Relaxed);
        if !self.enabled {
            return Ok(SlotHandle { slot, provisioner: None, sandbox_id: sandbox_id.to_string() });
        }
        let ns = format!("flint-{}", slot.idx);
        let host_if = format!("vh{}", slot.idx);
        let ns_if = format!("vg{}", slot.idx);
        run_cmd("ip", &["netns", "add", &ns]).await?;
        run_cmd("ip", &["link", "add", &host_if, "type", "veth", "peer", "name", &ns_if, "netns", &ns])
            .await?;
        run_cmd("ip", &["addr", "add", &format!("{}/31", slot.host_ip), "dev", &host_if]).await?;
        run_cmd("ip", &["link", "set", &host_if, "up"]).await?;
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "addr", "add", &format!("{}/31", slot.netns_ip), "dev", &ns_if]).await;
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "link", "set", &ns_if, "up"]).await;
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "link", "set", "lo", "up"]).await;
        // TAP for the microVM NIC inside the netns.
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "tuntap", "add", "tap0", "mode", "tap"]).await;
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "addr", "add", &format!("{}/30", TAP_IP), "dev", "tap0"]).await;
        let _ = run_cmd("ip", &["netns", "exec", &ns, "ip", "link", "set", "tap0", "up"]).await;
        // NAT for guest traffic leaving via the netns.
        let _ = run_cmd("ip", &["netns", "exec", &ns, "iptables", "-t", "nat", "-A", "POSTROUTING", "-s", "169.254.0.20/30", "-o", &ns_if, "-j", "MASQUERADE"]).await;
        Ok(SlotHandle {
            slot,
            provisioner: Some(Arc::new(ProvisionerRef { pool_used: true })),
            sandbox_id: sandbox_id.to_string(),
        })
    }

    /// Apply the egress policy inside a slot's netns (idempotent).
    pub async fn apply_egress(&self, slot: &Slot, policy: &EgressPolicy) -> Result<()> {
        if !self.enabled {
            return Ok(());
        }
        let ns = format!("flint-{}", slot.idx);
        let default = if policy.default == "deny" { "drop" } else { "accept" };
        let mut script = format!(
            "table inet flint_egress {{\n  chain out {{\n    type filter hook output priority 0; policy {default};\n"
        );
        for ip in &policy.ip_allow {
            script.push_str(&format!("    ip daddr {ip} accept\n"));
        }
        for ip in &policy.ip_deny {
            script.push_str(&format!("    ip daddr {ip} drop\n"));
        }
        // Metadata service must stay reachable.
        script.push_str("    ip daddr 169.254.169.254 accept\n");
        script.push_str("  }\n}\n");
        let _ = run_cmd("sh", &["-c", &format!("ip netns exec {ns} nft delete table inet flint_egress")]).await;
        run_stdin("sh", &["-c", &format!("ip netns exec {ns} nft -f -")], script.as_bytes()).await?;
        Ok(())
    }
}

struct ProvisionerRef {
    #[allow(dead_code)]
    pool_used: bool,
}

/// RAII handle: releases the IPAM slot (and tears the netns down).
pub struct SlotHandle {
    pub slot: Slot,
    provisioner: Option<Arc<ProvisionerRef>>,
    sandbox_id: String,
}

impl SlotHandle {
    pub fn netns(&self) -> String {
        format!("flint-{}", self.slot.idx)
    }
}

impl Drop for SlotHandle {
    fn drop(&mut self) {
        let ns = self.netns();
        let idx = self.slot.idx;
        let sandbox_id = self.sandbox_id.clone();
        if self.provisioner.is_some() {
            // Best-effort async work from Drop: spawn a thread.
            std::thread::spawn(move || {
                for args in [
                    vec!["netns".to_string(), "del".to_string(), ns],
                    vec!["link".to_string(), "del".to_string(), format!("vh{idx}")],
                ] {
                    let _ = std::process::Command::new("ip").args(&args).output();
                }
                tracing::debug!(sandbox_id = %sandbox_id, "network slot released");
            });
        }
    }
}

async fn run_cmd(bin: &str, args: &[&str]) -> Result<()> {
    let out = tokio::process::Command::new(bin)
        .args(args)
        .output()
        .await
        .map_err(|e| FlintError::Internal(format!("{bin}: {e}")))?;
    if !out.status.success() && !already_ok(&out.stderr) {
        return Err(FlintError::Internal(format!(
            "{bin} {:?}: {}",
            args,
            String::from_utf8_lossy(&out.stderr)
        )));
    }
    Ok(())
}

async fn run_stdin(bin: &str, args: &[&str], stdin: &[u8]) -> Result<()> {
    use tokio::io::AsyncWriteExt;
    let mut child = tokio::process::Command::new(bin)
        .args(args)
        .stdin(std::process::Stdio::piped())
        .stdout(std::process::Stdio::null())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .map_err(|e| FlintError::Internal(format!("{bin}: {e}")))?;
    if let Some(mut si) = child.stdin.take() {
        si.write_all(stdinin(stdin)).await.ok();
    }
    let out = child.wait_with_output().await.map_err(|e| FlintError::Internal(format!("{bin}: {e}")))?;
    if !out.status.success() && !already_ok(&out.stderr) {
        return Err(FlintError::Internal(format!("{bin} {:?}: {}", args, String::from_utf8_lossy(&out.stderr))));
    }
    Ok(())
}

fn stdinin(b: &[u8]) -> &[u8] {
    b
}

fn already_ok(stderr: &[u8]) -> bool {
    let s = String::from_utf8_lossy(stderr);
    s.contains("File exists") || s.contains("already exists") || s.contains("No such file or directory")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ipam_allocates_pairs() {
        let pool = IpamSlotPool::new("10.12.0.0/16", 4).unwrap();
        let s0 = pool.allocate().unwrap();
        let s1 = pool.allocate().unwrap();
        assert_eq!(s0.host_ip, "10.12.0.0");
        assert_eq!(s0.netns_ip, "10.12.0.1");
        assert_eq!(s1.host_ip, "10.12.0.2");
        pool.release(0);
        assert_eq!(pool.free_count(), 3);
    }

    #[test]
    fn ipam_exhausts() {
        let pool = IpamSlotPool::new("10.12.0.0/16", 2).unwrap();
        assert!(pool.allocate().is_ok());
        assert!(pool.allocate().is_ok());
        assert!(pool.allocate().is_err());
    }

    #[test]
    fn bad_subnets_rejected() {
        assert!(IpamSlotPool::new("10.12.0.0/12", 4).is_err());
        assert!(IpamSlotPool::new("garbage", 4).is_err());
    }
}
