# Tensorlake (tensorlake.ai) — Deep Research

*Researched by task R2, October 2025. Sources: tensorlake.ai, docs.tensorlake.ai, github.com/tensorlakeai.*

## Overview
Tensorlake provides "a stateful execution environment for agents": isolated **MicroVM sandboxes that boot in hundreds of milliseconds with memory and filesystem preserved across suspend/resume**, plus **durable Orchestration for long-running, crash-resumable agent workflows**. The company began as **Indexify** (open-source, layout- and schema-aware document ingestion / structured extraction with a durable extraction state machine — "each step is durable, failures are recoverable") and has pivoted/rebranded into the agent-sandbox + orchestration platform, with the Indexify extraction lineage visible in its versioned filesystem and Graph workflow model. Pitch: "Sandbox and Orchestration Infrastructure for Agents" — works with any LLM provider and framework (LangChain, OpenAI Agents SDK, Claude Agent SDK), HIPAA & SOC 2 Type II, EU data residency, zero data retention, and **BYOC** (sandboxes scheduled into your AWS account, >24,000 sandboxes/sec claimed scheduling rate).

## Isolation & Architecture
- Sandboxes are **MicroVMs backed by Firecracker and Cloud Hypervisor** (docs: "MicroVMs backed by Firecracker and CloudHypervisor"). Default image `tensorlake/ubuntu-minimal` boots in a few hundred ms; `tensorlake/ubuntu-systemd` (full init, Docker support) ~1s.
- Documented control-plane/dataplane split (Application Runtime architecture page): a **Server (control plane)** exposing an HTTP API and running two schedulers — an **Application Scheduler** (builds execution graph per request, creates allocations, checkpoints outputs, handles replay) and a **Container Scheduler** (tracks resources, places containers, **manages warm pools**, scales up/down); **Dataplanes** are regional clusters of worker nodes, each holding a persistent bidirectional **gRPC stream** to the server, reporting state and receiving assignments.
- Egress control: allowlist/denylist egress from sandboxes; inbound via `*.sandbox.tensorlake.ai` ingress; local TCP tunnels over authenticated WebSocket; SSH and PTY (WebSocket) sessions into live sandboxes.

## API Surface
- Python SDK (`pip install tensorlake`), TypeScript SDK (`@tensorlakeai/tensorlake`), CLI (`tl sbx create|checkpoint|…`, contexts for multi-org), and a documented **v2 HTTP API** (create sandboxes, inspect state, update ingress, snapshot, suspend, resume).
- `Sandbox.create(image=, cpus=, memory_mb=, disk_mb=)`, `sandbox.run(cmd, args)`, background process management, file ops, PTY sessions, computer-use (ubuntu-vnc desktop) driven from Python/JS.
- Orchestration: `@application()` + `@function(image=, timeout=, memory=, ephemeral_disk=)` decorators; two canonical agent patterns documented — **agent-in-sandbox** (`@function` *is* a sandbox) and **sandbox-as-tool** (agent outside, sandbox as an exec workspace). Futures for parallelism, map-reduce, parallel sub-agents.
- **Sandbox Pools**: `client.create_pool(image=…, warm_containers=N, max_containers=M)` — creating a sandbox from a pool "claims a warm container instead of cold-booting one"; the pool boots a replacement after each claim to restore the warm buffer; `max_containers` caps warm+claimed with queueing in `pending`.
- Versioned **Cloud Volumes / filesystems**: mounts (at boot, on warm-pool claims, or on a *running* sandbox), read-only mounts, autosave checkpoints, permanent snapshots, time-travel, git repository mounts with commit graphs, concurrent-write reconciliation (disjoint paths merge, same-path last-writer-wins), plus an HTTP file API without SDK.

## Persistence & Checkpointing
- **Lifecycle model** (explicit state machine): `Pending → Running → (Snapshotting → Running) → (Suspending → Suspended → resume → Running) → Terminated` (restartable within **48 hours**). **Ephemeral** sandboxes (unnamed) can't suspend; **Named** sandboxes support suspend/resume "under the same ID… consume no compute" while suspended.
- **Suspend vs Snapshot** is a first-class API distinction: *suspend* pauses *this* sandbox in place (resume later, same ID); *snapshot* produces a **reusable artifact** (`filesystem` or `memory` type) that survives source termination and can be restored into *new* sandboxes — `sandbox.checkpoint(checkpoint_type=CheckpointType.MEMORY|FILESYSTEM)`; memory checkpoints restore "VM memory + processes" for a warm start, filesystem checkpoints cold-boot from a tarball. Snapshot CLI: `tl sbx checkpoint <id> --checkpoint-type memory`.
- **Durable execution (technical preview)**: every `@function` call's output is auto-persisted per request; **replay** (`POST /applications/{name}/requests/{id}/replay`) restarts a failed request *from where it failed*, skipping succeeded calls; automatic retries reuse saved outputs. This is Temporal-style durability applied to agent workflows.

## Agent & Long-Running Features
- Long sessions: sandboxes "sleep on inactivity and wake instantly… sessions can run for hours or days"; named sandboxes + suspend/resume = persistent environments across tasks; computer-use sandboxes for browser agents; skills pre-loaded into images so coding agents self-configure at startup; Harbor/OpenCode/Claude Managed Agents/Devin Outposts/Cursor Cloud integrations.
- Workflows: parallel execution, retries & rate-limit-aware backoff, structured-output-validation-driven retries, crash recovery docs ("agents survive failures and resume without losing work"), no-24h-timeout positioning on Pro.
- GitHub Actions runners on Tensorlake with persistent caches.

## Pricing & Limits (docs.tensorlake.ai/platform/billing)
- Plans: **Free** ($0, 1 concurrent sandbox, 1 vCPU/1GB/10GB, 2h max session); **Usage Credits** (prepaid $5/$10/$20 packs, 1 CU = $0.01; up to 100 concurrent, 4 vCPU/16GB, 24h sessions); **Pro** ($250/mo + usage, 1,000 concurrent, 16 vCPU/64GB, unlimited session); Enterprise custom.
- Metered (measured **by the second**, quoted hourly): Active CPU $0.07/core-hr (Usage) / $0.042 (Pro); RAM $0.015/GB-hr ($0.009 Pro); root disk $0.0002/GB-hr; snapshot storage $0.07/GB-month while suspended. CPU bills **active runtime execution, not allocated vCPU**; RAM/disk are allocation-based while running. Resource ratio 1–8GB RAM per vCPU. Zero balance = stop (no postpaid overage).

## Open-Source & Engineering Notes
- **github.com/tensorlakeai/tensorlake** ("serverless runtime for sandboxes and [durable workflows]") and org repos (tensorlake-skills, legacy Indexify at github.com/tensorlakeai/indexify — Rust-based document extraction pipelines). PyPI: `tensorlake`. Docs served with llms.txt index at docs.tensorlake.ai/llms.txt.
- Engineering-relevant docs: /sandboxes/introduction (Firecracker+CloudHypervisor statement), /sandboxes/lifecycle (state machine), /sandboxes/snapshots, /sandboxes/pools, /applications/architecture (two-scheduler gRPC design), /applications/durability (durable execution + replay), /platform/billing.
- Blog: BYOC announcement ("schedule more than 24,000 sandboxes per second"), citations feature (field-level provenance from its extraction heritage).

## Lessons for a Rust Implementation
1. **Suspend ≠ Snapshot.** Encode both as distinct primitives: in-place pause/resume (same ID, no compute charge) vs reusable artifact (restore into N new sandboxes; separate `filesystem` and `memory` checkpoint types). A 48h restart window on terminated sandboxes is a nice safety net.
2. **Warm pools as an explicit resource** (template + `warm_containers` + `max_containers`, claim-and-replace semantics) — more declarative than Modal's queue-based example.
3. **Durable execution at the workflow layer, not just infra**: persist every function output, expose a replay API, let retries hit the memoized outputs. Cheap to build on an append-only log; transforms agent reliability.
4. **Two-scheduler architecture** (application/graph scheduler + container/warm-pool scheduler) over persistent gRPC streams per dataplane is a clean Rust control-plane decomposition.
5. **Versioned, mountable filesystems** (autosave checkpoints, pinned read-only snapshots, time-travel, concurrent-write reconciliation) turn agent state into a first-class object — port the git-like mental model to sandbox storage.
6. **Billing that users trust**: charge *active* CPU by the second, RAM/disk by allocation while running, snapshots while suspended — and hard-stop rather than surprise-bill.
