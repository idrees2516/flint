//! Token-bucket rate limiting (per API key / per connection).

use std::collections::HashMap;
use std::sync::Mutex;
use std::time::Instant;

/// A single token bucket. `capacity` tokens burst, refilled at
/// `refill_per_sec`.
#[derive(Debug)]
pub struct TokenBucket {
    capacity: f64,
    refill_per_sec: f64,
    state: Mutex<(f64, Instant)>,
}

impl TokenBucket {
    pub fn new(capacity: f64, refill_per_sec: f64) -> Self {
        Self {
            capacity,
            refill_per_sec,
            state: Mutex::new((capacity, Instant::now())),
        }
    }

    pub fn allow(&self) -> bool {
        self.allow_n(1.0)
    }

    pub fn allow_n(&self, n: f64) -> bool {
        let mut st = self.state.lock().unwrap();
        let (mut tokens, last) = *st;
        let now = Instant::now();
        let elapsed = now.duration_since(last).as_secs_f64();
        tokens = (tokens + elapsed * self.refill_per_sec).min(self.capacity);
        if tokens >= n {
            tokens -= n;
            *st = (tokens, now);
            true
        } else {
            *st = (tokens, now);
            false
        }
    }

    /// Milliseconds until `n` tokens are available (for Retry-After).
    pub fn retry_after_ms(&self, n: f64) -> u64 {
        let st = self.state.lock().unwrap();
        let (tokens, _) = *st;
        if tokens >= n {
            0
        } else {
            let deficit = n - tokens;
            (deficit / self.refill_per_sec * 1000.0).ceil() as u64
        }
    }
}

/// Keyed buckets with idle eviction (bounded memory under many keys).
pub struct KeyedBuckets<K: std::hash::Hash + Eq + Clone> {
    capacity: f64,
    refill_per_sec: f64,
    buckets: Mutex<HashMap<K, (TokenBucket, Instant)>>,
    max_keys: usize,
}

impl<K: std::hash::Hash + Eq + Clone> KeyedBuckets<K> {
    pub fn new(capacity: f64, refill_per_sec: f64, max_keys: usize) -> Self {
        Self {
            capacity,
            refill_per_sec,
            buckets: Mutex::new(HashMap::new()),
            max_keys,
        }
    }

    pub fn allow(&self, key: &K) -> bool {
        let mut m = self.buckets.lock().unwrap();
        if !m.contains_key(key) {
            if m.len() >= self.max_keys {
                // Evict the oldest idle bucket.
                if let Some(oldest) = m
                    .iter()
                    .min_by_key(|(_, (_, seen))| *seen)
                    .map(|(k, _)| k.clone())
                {
                    m.remove(&oldest);
                }
            }
            m.insert(key.clone(), (TokenBucket::new(self.capacity, self.refill_per_sec), Instant::now()));
        }
        let (b, seen) = m.get_mut(key).unwrap();
        *seen = Instant::now();
        b.allow()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bucket_bursts_then_limits() {
        let b = TokenBucket::new(2.0, 10.0);
        assert!(b.allow());
        assert!(b.allow());
        assert!(!b.allow());
        std::thread::sleep(std::time::Duration::from_millis(150));
        assert!(b.allow());
    }
}
