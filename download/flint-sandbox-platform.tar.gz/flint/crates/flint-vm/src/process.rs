//! ProcessDriver: the development / CI sandbox backend.
//!
//! **NOT an isolation boundary** — the sandbox is a process group plus a
//! home directory on the host, with a real `flint-guest-agent` speaking
//! the same wire protocol as production. It exists so the entire platform
//! (lifecycle, journaling, snapshots, APIs, replay) runs end-to-end on
//! machines without KVM. Never expose it to untrusted code.
//!
//! Semantics:
//! - `spawn`: creates `<root>/<sbx_id>/home`, restores the fs layer if
//!   given, then launches the guest agent (`--port 0`), parses its
//!   `READY <port>` line and connects over localhost TCP.
//! - `pause`: agent barrier → SIGSTOP the process group → tar.gz the home
//!   dir into staging → SIGKILL. (Frozen-then-dead pause: crash-consistent
//!   FS state, processes lost — matching our Journal+FS tier.)
//! - `resume`: respawn the agent; restartable processes are re-spawned by
//!   the worker from the journal.

use crate::agent_client::GuestAgentClient;
use crate::driver::{resolve_guest_agent_bin, RestoredLayers, SpawnRequest, StagedLayer, VmDriver, VmInstance};
use flint_core::{DriverKind, FlintError, Result};
use flint_journal::LayerKind;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use tokio::io::{AsyncBufReadExt, BufReader};

pub struct ProcessDriver {
    root: PathBuf,
    guest_agent_bin: PathBuf,
}

impl ProcessDriver {
    pub fn new(root: PathBuf, guest_agent_bin: Option<String>) -> Result<Self> {
        let bin = resolve_guest_agent_bin(guest_agent_bin.as_deref())?;
        Ok(Self { root, guest_agent_bin: bin })
    }

    fn sandbox_dir(&self, sandbox_id: &str) -> PathBuf {
        self.root.join(sandbox_id)
    }
}

#[async_trait::async_trait]
impl VmDriver for ProcessDriver {
    fn kind(&self) -> DriverKind {
        DriverKind::Process
    }

    async fn init(&self) -> Result<()> {
        tokio::fs::create_dir_all(&self.root).await?;
        Ok(())
    }

    async fn spawn(&self, req: SpawnRequest) -> Result<Box<dyn VmInstance>> {
        let sdir = self.sandbox_dir(&req.sandbox_id);
        let home = sdir.join("home");
        tokio::fs::create_dir_all(&home).await?;

        // Restore the fs layer if provided.
        if let Some(restored) = &req.restore {
            if let Some(fs_tar) = &restored.fs_tar {
                if fs_tar.exists() {
                    tracing::info!(sandbox = %req.sandbox_id, tar = %fs_tar.display(), "restoring fs layer");
                    tokio::task::spawn_blocking({
                        let tar = fs_tar.clone();
                        let home = home.clone();
                        move || flint_journal::packer::unpack_dir(&tar, &home)
                    })
                    .await
                    .map_err(|e| FlintError::Internal(format!("join: {e}")))??;
                }
            }
        }

        // Launch the guest agent.
        let mut cmd = tokio::process::Command::new(&self.guest_agent_bin);
        cmd.args(["serve", "--port", "0", "--home"])
            .arg(&home)
            .arg("--sandbox-id")
            .arg(&req.sandbox_id)
            .arg("--token")
            .arg(&req.agent_token)
            .env("FLINT_SANDBOX_ID", &req.sandbox_id)
            .env("FLINT_HOME", &home)
            // Dev-mode path semantics: exec'd commands run with the
            // sandbox home as cwd (sandbox-absolute paths in commands are
            // NOT remapped — only fs.* APIs map them under the home).
            .current_dir(&home)
            .stdin(Stdio::null())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .kill_on_drop(true);
        for (k, v) in &req.env {
            cmd.env(k, v);
        }
        #[cfg(unix)]
        {
            cmd.process_group(0);
        }
        let mut child = cmd
            .spawn()
            .map_err(|e| FlintError::Internal(format!("guest agent spawn: {e}")))?;

        // Parse "READY <port>" from stdout.
        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| FlintError::Internal("no guest agent stdout".into()))?;
        let mut reader = BufReader::new(stdout);
        let mut ready_line = String::new();
        let port = tokio::time::timeout(std::time::Duration::from_secs(10), async {
            loop {
                ready_line.clear();
                if reader.read_line(&mut ready_line).await? == 0 {
                    return Err(std::io::Error::new(std::io::ErrorKind::BrokenPipe, "agent exited before READY"));
                }
                if let Some(rest) = ready_line.strip_prefix("READY ") {
                    let port: u16 = rest.trim().parse().map_err(|_| {
                        std::io::Error::new(std::io::ErrorKind::InvalidData, "bad READY line")
                    })?;
                    return Ok(port);
                }
            }
        })
        .await
        .map_err(|_| FlintError::Timeout { op: "guest agent ready".into(), ms: 10_000 })?
        .map_err(|e| FlintError::Internal(format!("guest agent handshake: {e}")))?;

        // Keep draining stdout in the background so the pipe never fills.
        tokio::spawn(async move {
            let mut line = String::new();
            loop {
                line.clear();
                match reader.read_line(&mut line).await {
                    Ok(0) | Err(_) => break,
                    Ok(_) => {
                        let l = line.trim();
                        if !l.is_empty() && l.starts_with("FLINT_AGENT ") {
                            tracing::debug!(target: "flint::guest", "{}", l);
                        }
                    }
                }
            }
        });

        // Connect.
        let stream = tokio::net::TcpStream::connect(("127.0.0.1", port))
            .await
            .map_err(|e| {
                let _ = child.start_kill();
                FlintError::Internal(format!("agent connect: {e}"))
            })?;
        let agent = GuestAgentClient::connect(stream);
        let mut tries = 0;
        loop {
            match agent.ping().await {
                Ok(_) => break,
                Err(_) if tries < 10 => {
                    tries += 1;
                    tokio::time::sleep(std::time::Duration::from_millis(100)).await;
                }
                Err(e) => return Err(e),
            }
        }

        Ok(Box::new(ProcessInstance {
            sandbox_id: req.sandbox_id,
            agent,
            home,
            child: tokio::sync::Mutex::new(Some(child)),
            paused: Arc::new(AtomicBool::new(false)),
        }))
    }

    async fn prepare_restore(&self, sandbox_id: &str, layers: &mut RestoredLayers) -> Result<()> {
        // Nothing host-side to prepare for the process driver; tar is used
        // directly. But sanity check existence.
        if let Some(t) = &layers.fs_tar {
            if !t.exists() {
                return Err(FlintError::NotFound { resource: "fs layer", id: t.display().to_string() });
            }
        }
        let _ = sandbox_id;
        Ok(())
    }
}

pub struct ProcessInstance {
    sandbox_id: String,
    agent: Arc<GuestAgentClient>,
    home: PathBuf,
    child: tokio::sync::Mutex<Option<tokio::process::Child>>,
    paused: Arc<AtomicBool>,
}

impl ProcessInstance {
    fn pgid(&self) -> Option<i32> {
        self.child
            .try_lock()
            .ok()
            .and_then(|g| g.as_ref().and_then(|c| c.id()).map(|id| id as i32))
    }

    async fn kill_group(&self, sig: nix::sys::signal::Signal) {
        if let Some(pgid) = self.pgid() {
            use nix::sys::signal::killpg;
            let _ = killpg(nix::unistd::Pid::from_raw(-pgid), sig);
        } else {
            let mut guard = self.child.lock().await;
            if let Some(c) = guard.as_mut() {
                let _ = c.start_kill();
            }
        }
    }
}

#[async_trait::async_trait]
impl VmInstance for ProcessInstance {
    fn sandbox_id(&self) -> &str {
        &self.sandbox_id
    }

    fn kind(&self) -> DriverKind {
        DriverKind::Process
    }

    fn agent(&self) -> &Arc<GuestAgentClient> {
        &self.agent
    }

    fn home_dir(&self) -> Option<&Path> {
        Some(&self.home)
    }

    async fn pause(&self, staging: &Path) -> Result<Vec<StagedLayer>> {
        // 1) Durability barrier inside the sandbox.
        let _ = self.agent.barrier().await;

        // 2) Freeze the whole process group so the tar is consistent.
        self.kill_group(nix::sys::signal::Signal::SIGSTOP).await;
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;

        // 3) Pack.
        tokio::fs::create_dir_all(staging).await?;
        let tar_path = staging.join("fs.tar.gz");
        let home = self.home.clone();
        let tar = tar_path.clone();
        let (sha, size) = tokio::task::spawn_blocking(move || flint_journal::packer::pack_dir(&home, &tar))
            .await
            .map_err(|e| FlintError::Internal(format!("join: {e}")))??;

        // 4) Terminate (sandbox becomes paused; processes lost).
        self.kill_group(nix::sys::signal::Signal::SIGKILL).await;
        *self.child.lock().await = None;
        self.paused.store(true, Ordering::Relaxed);

        tracing::info!(sandbox = %self.sandbox_id, sha = %sha, size, "process sandbox paused + packed");
        Ok(vec![StagedLayer { kind: LayerKind::FsTarGz, path: tar_path }])
    }

    async fn resume(&self) -> Result<()> {
        // The worker respawns through the driver; a paused process instance
        // cannot resume itself. Report that honestly.
        Err(FlintError::InvalidState {
            from: "paused".into(),
            to: "running".into(),
        })
    }

    async fn stop(&self) -> Result<()> {
        self.kill_group(nix::sys::signal::Signal::SIGTERM).await;
        tokio::time::sleep(std::time::Duration::from_millis(300)).await;
        self.kill_group(nix::sys::signal::Signal::SIGKILL).await;
        *self.child.lock().await = None;
        Ok(())
    }

    async fn is_alive(&self) -> bool {
        if self.paused.load(Ordering::Relaxed) {
            return false;
        }
        let exited = self
            .child
            .try_lock()
            .ok()
            .and_then(|mut g| match g.as_mut() {
                Some(c) => c.try_wait().ok().flatten().map(|_| true),
                None => Some(false),
            })
            .unwrap_or(false);
        if exited {
            return false;
        }
        self.agent.ping().await.is_ok()
    }
}
