# Runloop (runloop.ai) — Research Report

*Researched: Task R1. Sources: runloop.ai, docs.runloop.ai (incl. their /llms.txt index, fetched directly), PR Newswire / VentureBeat coverage.*

## Overview

Runloop is a San Francisco startup (founded by ex-Stripe engineers led by CEO Jonathan Wall, with veterans of Google and Scale AI; **$7M seed July 2025** led by The General Partnership + Blank Ventures) positioning itself as **"Your AI Agent Accelerator"** — an enterprise-grade infrastructure platform for developing, **evaluating**, and deploying AI **coding** agents. The product: **Devboxes** ("secure sandboxed development environments… the fastest path to production-ready AI agents"), plus **Axons** (agent event streams), **Blueprints** (image templates), snapshots, network policies, and credential-proxied integrations. Their wedge vs E2B/Daytona is *coding-agent-specific* ergonomics: direct GitHub repo mounts, agent gateways so agents never see LLM API keys, MCP hub, public SWE-bench-style **benchmarks**, and SOC2 compliance. Marketing emphasizes "from zero to production in a few lines of code," PR claims cutting agent deployment timelines "up to six months faster."

## Isolation & Architecture

- Devboxes are **isolated, ephemeral virtual machines** — Runloop's own materials call them **microVMs** ("run your first agent in an isolated microVM in minutes"; third-party profiles: "Runloop's Devboxes are likewise microVM-based"). Hypervisor not formally documented (industry-standard inference: Firecracker-class), with VM isolation protecting "your API keys, code, secrets, sensitive data, and internal systems."
- Devbox states: **Provisioning → Initializing → Running → Suspending → Suspended → Resuming → Shutdown / Failure**. `Initializing` runs "Runloop defined boot scripts" to enable interaction.
- Startup "to running your first command takes a few seconds" (slower than E2B/Daytona's ~150/90ms claims — Runloop optimizes for full-featured agent workstations rather than raw cold-start speed).
- Architecture layers visible from the API: devbox service + snapshot service + storage-object service + blueprint builder + network-policy service + agent/mcp/gateway services + Axon event-stream service + Broker. Starter image ships Python 3.12/uv, Node 22.15, gh, jq, vim, rsync, etc. Sizes: predefined (small…XL, optional GPU; arm64/x86_64 architecture selectable); Docker-in-Docker supported.
- **SOC2 compliant**; enterprise security posture is a headline (the "Enterprise-Grade Sandboxes for AI Coding Agents" launch, Nov 2024).

## API Surface

- **REST API** (OpenAPI spec published; Stainless-generated SDKs: **Python `runloop-api-client`** + **TypeScript `@runloop/api-client`**, plus **`rl-cli`** CLI, Dashboard, and an **MCP server** exposing Runloop operations as AI-tool calls, plus Cursor `.mdc` rules). Auth: `Authorization: Bearer $RUNLOOP_API_KEY`.
- Exec model (best-documented of the four): `devbox.cmd.exec()` — **blocking**, returns `ExecutionResult` with exit_code/stdout/stderr; `exec_async()` — returns immediately with an **Execution handle** to poll/stream/kill — designed for servers & watchers; both support **streaming callbacks** (stdout/stderr/output) and **execution logs** (real-time + historical retrieval).
- **Named Shells**: `devbox.shell("name")` creates a *stateful* shell session — same name reconnects to the live session, preserving env vars, CWD, running processes; commands queue sequentially. (Plain `exec` spawns an isolated shell each time — env/CWD don't persist.)
- **PTY sessions**: `pty.connect(session_name)` returns a **WebSocket connect_url**; `pty.control()` supports resize (cols/rows), signals (SIGINT, SIGWINCH), close; idle retention `idle_ttl_seconds`; single-WebSocket attach (second attach → HTTP 400); disconnect does not kill the session.
- Files read/write API; **mounts** at creation only: `code_mount` (clone GitHub repo + optional `install_command`; private-repo token doubles as `GH_TOKEN` for gh CLI PRs), `object_mount` (storage objects; archives auto-extract), `file_mount` (inline file content), `agent_mount` (pre-packaged agent).
- **Tunnels**: `enable_tunnel(port)` → HTTPS URL on `*.tunnel.runloop.ai` (HTTP/WS/SSE; `auth_mode: open|authenticated`; **`wake_on_http`** auto-resumes a suspended devbox on traffic; service must bind `0.0.0.0`).
- **SSH**: `rli devbox ssh/scp/rsync`; `--config-only` emits SSH config for VS Code Remote-SSH/JetBrains; programmatic `create_ssh_key()` returns url+key+user; 15-min inactivity timeout.
- Axon API: `axon.create/publish/subscribeSse` — events carry `source, event_type, origin, payload`, monotonic `sequence`, SSE delivery.

## Persistence & Lifecycle

- **Suspend/resume saves DISK ONLY — in-memory state is lost.** (Explicit doc warning; processes must be restarted after resume.) This is the key architectural contrast with E2B/Morph memory snapshots. Suspend/resume "typically takes seconds, depending on the amount of modified data"; devbox ID and SSH keys survive suspend/resume cycles.
- **Snapshots** (`snapshot_disk()` sync or async+`await_completion()`): saved **disk state**; create *new* devboxes from a snapshot (branching/reuse); snapshots persist and **accrue storage charges until explicitly deleted**. Devboxes are "by definition ephemeral — consistently snapshot your devboxes to maintain disk state."
- **Lifetime management**: `keep_alive_time_seconds` (max lifetime / TTL) **OR** `lifecycle.after_idle` = `{idle_time_seconds, on_idle: "shutdown" | "suspend"}` — mutually exclusive (mixed config = undefined behavior). Compute billed only in states `[initializing, running, suspending, resuming]`; suspended devboxes pay storage only.
- **Blueprints**: container image templates (Dockerfile-based or prebuilt `runloop/universal-ubuntu-24.04-x86_64`, `runloop/starter-x86_64`); `launch_commands` pre-install tools at build time (must redirect output of background processes or the devbox hangs in `Initializing` forever); composable blueprints; network policies can apply to builds too. Blueprints are their "template" analogue.

## Agent-Specific Features

- **Agent Gateways** (standout): proxy AI API calls through Runloop so **agents never see raw credentials** — gateway configs (`endpoint`, auth `bearer|header|basic`, up to 8 custom headers backed by account secrets or literals) attach at devbox create; auto-inject `$<PREFIX>_URL`/`$<PREFIX>` env vars (e.g. `$ANTHROPIC_URL`, `$ANTHROPIC`); **gateway tokens are bound to the devbox — leaking them is useless elsewhere**. Supports Anthropic/OpenAI SDKs, Claude Code, Codex, OpenCode, Gemini CLI.
- **MCP Hub**: same credential-proxy pattern for MCP tool servers — configs with `endpoint`, `allowed_tools` glob patterns, auth mechanism, custom headers; per-server opaque tokens env-injected, all sharing `$RL_MCP_URL`.
- **Account secrets**: stored encrypted at account level, injected at create as env vars via `{"ENV_VAR_NAME": "SECRET_NAME"}` mapping.
- **Axons + Broker** (most differentiating): persistent **append-only event streams** with monotonic sequence numbers, SSE subscribe, an **embedded SQLite** per Axon for structured state, and a **Broker** that bridges the stream to an agent process in a devbox, forwarding events **one turn at a time** (turn-based interaction; agent updates a GitHub PR, sleeps, wakes on PR comments). Protocol adapters: **ACP (Agent Client Protocol)** for OpenCode/Goose, **Claude JSON protocol** for Claude Code. Enables suspend-when-idle / wake-on-demand / state recovery / agent handoff "without building the plumbing."
- **Agents API**: registered, versioned agent definitions (from Git, npm, pip, or storage object) mountable into devboxes for reproducible installs; deploy via GitHub Action.
- **Network Policies**: egress control with `allow_all`, `allowed_hostnames` (wildcards), `allow_devbox_to_devbox` (tunnel-based inter-sandbox comms), `allow_agent_gateway`/`allow_mcp_gateway`; up to 100/account.
- Public **Benchmarks** product for evaluating coding agents; tutorials for OpenAI Agents SDK/API, OpenCode, Browserbase/Kernel (browser agents over CDP without installing Chromium in-box).
- Docs include honest **transition guides** (Runloop → Tensorlake/Modal migration plans) — unusual portability stance.

## Pricing & Limits

Per-second metered compute: **$0.108/CPU-hr, $0.0252/GB-hr memory, $0.00034236/GB-hr storage** (among the pricier sandboxes — ~2× E2B/Daytona per vCPU; third parties compute ~$231/mo for 1 vCPU + 1GB baseline, ~$1,110 for 1 CPU + 1GB full-runtime). Plans: Basic free (with **$50 starter credits**; 8 active-hour caps for trials), **Pro $250/mo** (pause-to-zero, larger quotas). Compute billed only while initializing/running/suspending/resuming; suspended = storage only; snapshots/storage objects accrue charges until deleted. 100 network policies/account.

## Open-Source & Engineering Notes

- SDK repos: **github.com/runloopai/api-client-python**, **github.com/runloopai/api-client-ts** (Stainless-generated). No open-source infrastructure repo — closed platform, unlike E2B (Apache-2.0 runtime) and old Daytona.
- Docs (exemplary, LLM-optimized with `/llms.txt` + gotchas section): https://docs.runloop.ai — devboxes/lifecycle, execute-commands, named-shells, pty, snapshots, start-stop, ai-gateways, mcp-hub, tunnels, ssh, mounts, blueprints, network-policies, axons/*.
- Press: https://runloop.ai/media/runloop-raises-7m-seed-round... ; VentureBeat coverage of the seed round.

## Lessons for a Rust Implementation

1. **Two-tier exec API is the right shape**: blocking `exec` (returns exit code + stdout/stderr) + async `exec_async` (handle: poll/stream/kill) + **named stateful shells** for env/CWD persistence + **PTY over WebSocket** with resize/signals/idle-TTL. This covers 95% of agent needs cleanly.
2. **Credential-proxy gateways** (LLM API + MCP) with per-devbox-bound tokens should be platform primitives — the "agent never sees the real key" pattern is a genuine enterprise differentiator.
3. **Separate TTL from idle policy** (`keep_alive_time_seconds` vs `after_idle{shutdown|suspend}`) but *forbid mixing*; bill only in active states.
4. **Disk-only suspend** is a legitimate cheaper alternative to memory snapshots (seconds to suspend, no RAM restore complexity) — but document the lossiness loudly and pair with snapshots for durability.
5. **Mount-time composition** (repos, files, objects, agents) makes devboxes reproducible; mounts must be create-time-only to keep the model simple.
6. **Event-stream + turn-based broker** (Axon) is a novel layer worth studying: an append-only sequence-numbered stream + embedded SQLite + one-turn-at-a-time forwarding gives agents durable state, wake-on-event, and human/agent handoff without custom plumbing.

**Most differentiating idea:** **Axons + Broker** — a managed persistent event-stream/turn-taking layer *on top of* sandboxes purpose-built for coding-agent lifecycles (idle suspend, wake-on-event, PR-driven turns, state recovery), plus credential-proxying Agent Gateways/MCP Hub.
