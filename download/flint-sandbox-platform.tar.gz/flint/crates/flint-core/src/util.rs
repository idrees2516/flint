//! Small shared helpers.

use base64::engine::general_purpose::STANDARD;
use base64::Engine;
use std::time::{SystemTime, UNIX_EPOCH};

/// Current unix time in milliseconds.
pub fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

/// RFC3339 timestamp for a unix-millis value.
pub fn iso8601(ms: i64) -> String {
    chrono::DateTime::from_timestamp_millis(ms)
        .map(|d| d.to_rfc3339())
        .unwrap_or_else(|| "invalid".into())
}

pub fn b64_encode(data: &[u8]) -> String {
    STANDARD.encode(data)
}

pub fn b64_decode(s: &str) -> crate::Result<Vec<u8>> {
    STANDARD
        .decode(s.trim())
        .map_err(|e| crate::FlintError::InvalidParam { msg: format!("bad base64: {e}") })
}

/// Read a file to string, `None` if missing.
pub async fn read_opt(path: &std::path::Path) -> std::io::Result<Option<String>> {
    match tokio::fs::read_to_string(path).await {
        Ok(s) => Ok(Some(s)),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Err(e) => Err(e),
    }
}

/// SHA-256 of a byte slice (hex).
pub fn sha256_hex(data: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    let mut h = Sha256::new();
    h.update(data);
    hex::encode(h.finalize())
}

/// Truncate a byte slice for display.
pub fn preview(bytes: &[u8], max: usize) -> &[u8] {
    &bytes[..bytes.len().min(max)]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn b64_roundtrip() {
        let data = b"hello flint";
        assert_eq!(b64_decode(&b64_encode(data)).unwrap(), data);
    }

    #[test]
    fn iso8601_valid() {
        assert!(iso8601(1_700_000_000_000).starts_with("2023-11-14T"));
    }
}
