//! `SandboxSupervisor` — one actor per sandbox (ARCHITECTURE §5).
//!
//! Owns the VmInstance, the WAL, timers and the lifecycle state machine.
//! Every mutating op is journaled *before* dispatch (write-ahead), every
//! pause cuts a snapshot (layers uploaded to the object store + manifest
//! + `SnapshotRef` in the WAL), and the reconciler tick drives:
//! liveness → **crash recovery** (restore last snapshot + WAL replay +
//! restart `restartable` processes), idle auto-pause, and TTL expiry.

use crate::WorkerRuntime;
use flint_core::agent_proto::methods as M;
use flint_core::{ExecSpec, FlintError, Result, SandboxState, TimeoutPolicy, VmSpec};
use flint_journal::ops::Op;
use flint_journal::{Layer, LayerKind, SnapshotKind, SnapshotManifest, Wal, WalRecord, FsyncPolicy};
use flint_vm::{RestoredLayers, SpawnRequest, VmInstance};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::{mpsc, oneshot, RwLock};

#[derive(Debug)]
pub enum SupCmd {
    Op { kind: String, payload: String, resp: oneshot::Sender<Result<Value>> },
    OpStream {
        kind: String,
        payload: String,
        events: mpsc::Sender<SupEvent>,
        resp: oneshot::Sender<Result<Value>>,
    },
    Pause { resp: oneshot::Sender<Result<String>> },
    Resume { resp: oneshot::Sender<Result<()>> },
    Stop { keep_state: bool, resp: oneshot::Sender<Result<String>> },
    Snapshot { kind: String, resp: oneshot::Sender<Result<String>> },
    Tick,
}

#[derive(Debug, Clone)]
pub struct SupEvent {
    pub kind: String,
    pub payload: String,
    pub final_: bool,
    pub error: Option<String>,
}

#[derive(Clone)]
pub struct SupHandle {
    pub sandbox_id: String,
    pub vm: VmSpec,
    tx: mpsc::Sender<SupCmd>,
    state: Arc<RwLock<SandboxState>>,
}

impl SupHandle {
    pub async fn send(&self, cmd: SupCmd) -> Result<()> {
        self.tx
            .send(cmd)
            .await
            .map_err(|_| FlintError::Unavailable { msg: format!("supervisor {} gone", self.sandbox_id) })
    }

    pub async fn state(&self) -> SandboxState {
        *self.state.read().await
    }

    pub fn vm_spec(&self) -> VmSpec {
        self.vm
    }

    async fn op_raw(&self, kind: &str, payload: &str) -> Result<Value> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::Op { kind: kind.to_string(), payload: payload.to_string(), resp: tx })
            .await?;
        rx.await
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped call".into() })?
    }

    pub async fn op(&self, kind: &str, payload: &Value) -> Result<Value> {
        self.op_raw(kind, &payload.to_string()).await
    }

    pub async fn op_stream(
        &self,
        kind: &str,
        payload: &Value,
        events: mpsc::Sender<SupEvent>,
    ) -> Result<Value> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::OpStream {
            kind: kind.to_string(),
            payload: payload.to_string(),
            events,
            resp: tx,
        })
        .await?;
        rx.await
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped stream call".into() })?
    }

    pub async fn pause(&self, timeout: Duration) -> Result<String> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::Pause { resp: tx }).await?;
        tokio::time::timeout(timeout, rx)
            .await
            .map_err(|_| FlintError::Timeout { op: "pause".into(), ms: timeout.as_millis() as u64 })?
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped pause".into() })?
    }

    pub async fn resume(&self) -> Result<()> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::Resume { resp: tx }).await?;
        rx.await
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped resume".into() })?
    }

    pub async fn stop(&self, keep_state: bool) -> Result<String> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::Stop { keep_state, resp: tx }).await?;
        tokio::time::timeout(Duration::from_secs(120), rx)
            .await
            .map_err(|_| FlintError::Timeout { op: "stop".into(), ms: 120_000 })?
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped stop".into() })?
    }

    pub async fn snapshot(&self, kind: &str) -> Result<String> {
        let (tx, rx) = oneshot::channel();
        self.send(SupCmd::Snapshot { kind: kind.to_string(), resp: tx }).await?;
        tokio::time::timeout(Duration::from_secs(180), rx)
            .await
            .map_err(|_| FlintError::Timeout { op: "snapshot".into(), ms: 180_000 })?
            .map_err(|_| FlintError::Unavailable { msg: "supervisor dropped snapshot".into() })?
    }
}

// ---------------------------------------------------------------------------
// Start request (parsed)
// ---------------------------------------------------------------------------

pub struct StartInfo {
    pub sandbox_id: String,
    pub vm: VmSpec,
    pub env: BTreeMap<String, String>,
    pub timeouts: TimeoutPolicy,
    pub agent_token: String,
    pub template_snapshot_id: Option<String>,
    pub restore_manifest: Option<SnapshotManifest>,
    pub restore_snapshot_id: Option<String>,
}

pub fn parse_start(req: &flint_proto::fleet::StartSandboxRequest) -> Result<StartInfo> {
    let vm = VmSpec {
        vcpu_count: req.vcpu_count,
        mem_mib: req.mem_mib,
        disk_mib: req.disk_mib,
    };
    let env: BTreeMap<String, String> = serde_json::from_str(
        &serde_json::to_string(&serde_json::Map::from_iter(
            req.env.iter().map(|(k, v)| (k.clone(), Value::String(v.clone()))),
        ))
        .unwrap_or_default(),
    )
    .unwrap_or_default();
    let timeouts: TimeoutPolicy = serde_json::from_str(&req.timeouts_json).unwrap_or_default();
    let restore_manifest = if req.restore_manifest_json.is_empty() {
        None
    } else {
        Some(serde_json::from_str(&req.restore_manifest_json)?)
    };
    Ok(StartInfo {
        sandbox_id: req.sandbox_id.clone(),
        vm,
        env,
        timeouts,
        agent_token: req.agent_token.clone(),
        template_snapshot_id: if req.template_snapshot_id.is_empty() { None } else { Some(req.template_snapshot_id.clone()) },
        restore_manifest,
        restore_snapshot_id: if req.restore_snapshot_id.is_empty() { None } else { Some(req.restore_snapshot_id.clone()) },
    })
}

// ---------------------------------------------------------------------------
// Supervisor
// ---------------------------------------------------------------------------

impl WorkerRuntime {
    pub async fn spawn_from_start(self: &Arc<Self>, info: StartInfo) -> Result<SupHandle> {
        let sdir = self.cfg.work_dir.join("sandboxes").join(&info.sandbox_id);
        tokio::fs::create_dir_all(&sdir).await?;

        // Stage restore layers from the object store.
        let restore = match (&info.restore_manifest, &info.restore_snapshot_id) {
            (Some(manifest), Some(snap_id)) => {
                Some(self.stage_layers(snap_id, manifest, &sdir).await?)
            }
            _ => None,
        };

        let spawn_req = SpawnRequest {
            sandbox_id: info.sandbox_id.clone(),
            vm: info.vm,
            env: info.env.clone(),
            agent_token: info.agent_token.clone(),
            restore,
            netns: None,
            template_drive: None,
            cid: None,
        };
        let instance = self.driver.spawn(spawn_req).await?;

        let wal_path = sdir.join("wal.log");
        let wal = Wal::open(&wal_path, FsyncPolicy::from_str(&self.cfg.journal.fsync))?;

        let (tx, rx) = mpsc::channel(1024);
        let state = Arc::new(RwLock::new(SandboxState::Running));
        let handle = SupHandle {
            sandbox_id: info.sandbox_id.clone(),
            vm: info.vm,
            tx,
            state: state.clone(),
        };

        let sup = Supervisor {
            rt: self.clone(),
            info,
            instance: Some(instance),
            wal,
            sdir,
            state,
            last_activity_ms: flint_core::util::now_ms(),
            created_at_ms: flint_core::util::now_ms(),
            current_snapshot_id: None,
            tick_seq: 0,
        };
        tokio::spawn(sup.run(rx));
        Ok(handle)
    }

    /// Download snapshot layers into `<sdir>/restore/<snap_id>/`.
    pub async fn stage_layers(
        self: &Arc<Self>,
        snap_id: &str,
        manifest: &SnapshotManifest,
        sdir: &Path,
    ) -> Result<RestoredLayers> {
        let base = sdir.join("restore").join(snap_id);
        tokio::fs::create_dir_all(&base).await?;
        let mut out = RestoredLayers { wal_seq: manifest.wal_seq, ..Default::default() };
        for layer in &manifest.layers {
            let dest = base.join(layer_file_name(&layer.kind));
            if !dest.exists() {
                let objects = self.objects.clone();
                let key = layer.key.clone();
                let key2 = key.clone();
                let bytes = tokio::task::spawn_blocking(move || objects.get(&key))
                    .await
                    .map_err(|e| FlintError::Internal(format!("join: {e}")))?
                    .map_err(|e| FlintError::Internal(format!("fetch layer {key2}: {e}")))?;
                tokio::fs::write(&dest, &bytes).await?;
            }
            match layer.kind {
                LayerKind::FsTarGz => out.fs_tar = Some(dest),
                LayerKind::Memory => out.memory = Some(dest),
                LayerKind::DeviceState => out.snapfile = Some(dest),
            }
        }
        Ok(out)
    }
}

fn layer_file_name(kind: &LayerKind) -> &'static str {
    match kind {
        LayerKind::FsTarGz => "fs.tar.gz",
        LayerKind::Memory => "memfile",
        LayerKind::DeviceState => "snapfile",
    }
}

fn sha256_file(path: &Path) -> Result<(String, u64)> {
    let mut f = std::fs::File::open(path)?;
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 64 * 1024];
    let mut total: u64 = 0;
    use std::io::Read;
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
        total += n as u64;
    }
    Ok((hex::encode(hasher.finalize()), total))
}

pub struct Supervisor {
    /// Worker runtime (shared).
    rt: Arc<WorkerRuntime>,
    info: StartInfo,
    instance: Option<Box<dyn VmInstance>>,
    wal: Wal,
    sdir: PathBuf,
    state: Arc<RwLock<SandboxState>>,
    last_activity_ms: i64,
    created_at_ms: i64,
    current_snapshot_id: Option<String>,
    tick_seq: u64,
}

impl Supervisor {
    async fn run(
        mut self,
        mut rx: mpsc::Receiver<SupCmd>,
    ) {
        // Reconciler ticker.
        let tick_ms = self.rt.cfg.reconcile_interval_ms.max(250);
        let mut ticker = tokio::time::interval(Duration::from_millis(tick_ms));
        ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);

        loop {
            tokio::select! {
                cmd = rx.recv() => {
                    match cmd {
                        Some(cmd) => self.handle(cmd).await,
                        None => break,
                    }
                }
                _ = ticker.tick() => {
                    self.tick_seq += 1;
                    self.handle(SupCmd::Tick).await;
                }
            }
        }
        tracing::info!(sandbox = %self.info.sandbox_id, "supervisor exiting");
    }

    fn agent(&self) -> Result<&Arc<flint_vm::GuestAgentClient>> {
        self.instance
            .as_ref()
            .map(|i| i.agent())
            .ok_or(FlintError::InvalidState { from: "paused/stopped".into(), to: "exec".into() })
    }

    async fn set_state(&self, to: SandboxState) {
        *self.state.write().await = to;
        let snap = self.current_snapshot_id.clone().unwrap_or_default();
        self.rt.send_report(&self.info.sandbox_id, to.as_str(), &snap, "").await;
    }

    async fn handle(&mut self, cmd: SupCmd) {
        match cmd {
            SupCmd::Tick => self.on_tick().await,
            SupCmd::Op { kind, payload, resp } => {
                let res = self.on_op(&kind, &payload).await;
                let _ = resp.send(res);
            }
            SupCmd::OpStream { kind, payload, events, resp } => {
                let res = self.on_op_stream(&kind, &payload, events).await;
                let _ = resp.send(res);
            }
            SupCmd::Pause { resp } => {
                let res = self.do_pause(SnapshotKind::Pause).await;
                let _ = resp.send(res);
            }
            SupCmd::Stop { keep_state, resp } => {
                let res = if keep_state {
                    self.do_pause(SnapshotKind::Pause).await
                } else {
                    self.do_stop().await.map(|_| String::new())
                };
                let _ = resp.send(res);
            }
            SupCmd::Resume { resp } => {
                let res = self.do_resume().await;
                let _ = resp.send(res.map(|_| ()));
            }
            SupCmd::Snapshot { kind, resp } => {
                let k = if kind == "template_base" { SnapshotKind::TemplateBase } else { SnapshotKind::Explicit };
                let res = self.do_snapshot(k).await;
                let _ = resp.send(res);
            }
        }
    }

    // ----- ops -----

    async fn on_op(&mut self, kind: &str, payload: &str) -> Result<Value> {
        let params: Value = serde_json::from_str(payload)
            .map_err(|e| FlintError::InvalidParam { msg: format!("bad payload: {e}") })?;
        let now = flint_core::util::now_ms();
        let agent = self.agent()?.clone();
        let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();

        // Journaled ops: record BEFORE dispatch (write-ahead).
        match kind {
            "fs.write" | "fs.mkdir" | "fs.remove" | "fs.move" => {
                if let Some(op) = params_to_op(kind, &params, &op_id) {
                    self.wal
                        .append(WalRecord::OpApplied { op_id: op_id.clone(), op })
                        .map_err(|e| FlintError::Internal(format!("wal: {e}")))?;
                }
            }
            "process.spawn" => {
                let spec: ExecSpec = serde_json::from_value(params.get("spec").cloned().unwrap_or(Value::Null))
                    .unwrap_or_else(|_| ExecSpec::shell("true"));
                self.wal
                    .append(WalRecord::OpApplied {
                        op_id: op_id.clone(),
                        op: Op::ProcessSpawn { spec, proc_id: String::new() },
                    })
                    .map_err(|e| FlintError::Internal(format!("wal: {e}")))?;
            }
            "exec" => {
                let spec: ExecSpec = serde_json::from_value(params.get("spec").cloned().unwrap_or(Value::Null))
                    .unwrap_or_else(|_| ExecSpec::shell("true"));
                self.wal
                    .append(WalRecord::OpApplied { op_id: op_id.clone(), op: Op::Exec { spec } })
                    .map_err(|e| FlintError::Internal(format!("wal: {e}")))?;
            }
            _ => {}
        }

        // Dispatch to the agent.
        match kind {
            "exec" => {
                let spec: ExecSpec = serde_json::from_value(params.get("spec").cloned().unwrap_or(Value::Null))?;
                let started = std::time::Instant::now();
                let max_out = 512 * 1024;
                let (code, stdout, stderr, timed_out) =
                    agent.exec(&spec, &op_id, max_out).await?;
                flint_core::metrics::observe_duration_ms(
                    flint_core::metrics::names::EXEC_DURATION_MS,
                    &[("driver", format!("{:?}", self.instance_kind()))],
                    started.elapsed(),
                );
                flint_core::metrics::counter_inc(
                    flint_core::metrics::names::OPS_TOTAL,
                    &[("op", "exec".into()), ("result", if timed_out { "timeout".into() } else { "ok".into() })],
                );
                self.last_activity_ms = now;
                return Ok(json!({
                    "exit_code": code,
                    "stdout_b64": flint_core::util::b64_encode(&stdout),
                    "stderr_b64": flint_core::util::b64_encode(&stderr),
                    "timed_out": timed_out,
                }));
            }
            "term.input" | "term.resize" | "term.close" | "port.data" | "port.close" => {
                // Push frames to an open agent stream (kind forwarded as-is;
                // the agent expects e.g. `term.input` with data_b64 at the
                // top level of `data`).
                let id = params.get("stream_id").and_then(|v| v.as_u64()).unwrap_or(0);
                agent.push(id, kind, params).await?;
                self.last_activity_ms = now;
                return Ok(json!({ "ok": true }));
            }
            _ => {}
        }

        let agent_method = match kind {
            "fs.write" => M::FS_WRITE,
            "fs.read" => M::FS_READ,
            "fs.list" => M::FS_LIST,
            "fs.mkdir" => M::FS_MKDIR,
            "fs.remove" => M::FS_REMOVE,
            "fs.move" => M::FS_MOVE,
            "fs.stat" => M::FS_STAT,
            "process.spawn" => M::PROCESS_SPAWN,
            "process.list" => M::PROCESS_LIST,
            "process.kill" => M::PROCESS_KILL,
            "process.signal" => M::PROCESS_SIGNAL,
            "process.input" => M::PROCESS_INPUT,
            "process.wait" => M::PROCESS_WAIT,
            "barrier" => M::BARRIER,
            "ping" => M::PING,
            other => {
                return Err(FlintError::InvalidParam { msg: format!("unknown op kind: {other}") });
            }
        };
        self.last_activity_ms = now;
        agent.call(agent_method, params).await
    }

    async fn on_op_stream(
        &mut self,
        kind: &str,
        payload: &str,
        events: mpsc::Sender<SupEvent>,
    ) -> Result<Value> {
        let params: Value = serde_json::from_str(payload)
            .map_err(|e| FlintError::InvalidParam { msg: format!("bad payload: {e}") })?;
        let agent = self.agent()?.clone();
        self.last_activity_ms = flint_core::util::now_ms();

        match kind {
            "exec.stream" => {
                let spec: ExecSpec = serde_json::from_value(params.get("spec").cloned().unwrap_or(Value::Null))?;
                let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
                self.wal
                    .append(WalRecord::OpApplied { op_id, op: Op::Exec { spec: spec.clone() } })
                    .map_err(|e| FlintError::Internal(format!("wal: {e}")))?;
                let (id, mut rx) = agent
                    .call_stream_tagged(M::EXEC, flint_core::agent_proto::params_exec(&spec, ""))
                    .await?;
                while let Some(msg) = agent_client_event(&mut rx).await {
                    let final_ = matches!(msg.kind.as_str(), "closed");
                    let _ = events.send(msg.clone()).await;
                    if final_ {
                        break;
                    }
                }
                Ok(json!({ "stream_id": id }))
            }
            "term.open" => {
                let (id, mut rx) = agent.call_stream_tagged(M::TERM_OPEN, params).await?;
                tokio::spawn(async move {
                    while let Some(msg) = agent_client_event(&mut rx).await {
                        let final_ = matches!(msg.kind.as_str(), "closed");
                        let _ = events.send(msg.clone()).await;
                        if final_ {
                            break;
                        }
                    }
                });
                Ok(json!({ "stream_id": id }))
            }
            "port.connect" => {
                let (id, mut rx) = agent.call_stream_tagged(M::PORT_CONNECT, params).await?;
                tokio::spawn(async move {
                    while let Some(msg) = agent_client_event(&mut rx).await {
                        let final_ = matches!(msg.kind.as_str(), "closed");
                        let _ = events.send(msg.clone()).await;
                        if final_ {
                            break;
                        }
                    }
                });
                Ok(json!({ "stream_id": id }))
            }
            other => Err(FlintError::InvalidParam { msg: format!("unknown stream kind: {other}") }),
        }
    }

    fn instance_kind(&self) -> flint_core::DriverKind {
        self.instance.as_ref().map(|i| i.kind()).unwrap_or(flint_core::DriverKind::Process)
    }

    // ----- lifecycle -----

    async fn do_pause(&mut self, kind: SnapshotKind) -> Result<String> {
        self.set_state(SandboxState::Pausing).await;
        let result = self.cut_snapshot(kind).await;
        match result {
            Ok(snap_id) => {
                self.set_state(SandboxState::Paused).await;
                Ok(snap_id)
            }
            Err(e) => {
                tracing::error!(sandbox = %self.info.sandbox_id, error = %e, "pause failed");
                self.set_state(SandboxState::Error).await;
                Err(e)
            }
        }
    }

    async fn do_stop(&mut self) -> Result<()> {
        self.set_state(SandboxState::Stopping).await;
        if let Some(instance) = self.instance.take() {
            let _ = instance.stop().await;
        }
        self.set_state(SandboxState::Stopped).await;
        Ok(())
    }

    async fn do_snapshot(&mut self, kind: SnapshotKind) -> Result<String> {
        self.set_state(SandboxState::Snapshotting).await;
        let result = self.cut_snapshot(kind).await;
        self.set_state(SandboxState::Running).await;
        result
    }

    async fn cut_snapshot(&mut self, kind: SnapshotKind) -> Result<String> {
        let snap_id = flint_core::ids::new_id(flint_core::ids::prefixes::SNAPSHOT);
        let staging = self.sdir.join("snapshots").join(&snap_id);
        tokio::fs::create_dir_all(&staging).await?;

        // Barrier the journal, then quiesce + stage layers.
        self.wal
            .append(WalRecord::Barrier)
            .map_err(|e| FlintError::Internal(format!("wal barrier: {e}")))?;

        let staged = match self.instance.as_ref() {
            Some(instance) => instance.pause(&staging).await?,
            None => {
                // Already stopped/paused: pack the home dir if we have one.
                let home = self.sdir.join("home");
                if home.exists() {
                    let tar = staging.join("fs.tar.gz");
                    let (sha, size) = tokio::task::spawn_blocking({
                        let home = home.clone();
                        let tar = tar.clone();
                        move || flint_journal::packer::pack_dir(&home, &tar)
                    })
                    .await
                    .map_err(|e| FlintError::Internal(format!("join: {e}")))??;
                    tracing::info!(sha, size, "packed home dir without live instance");
                    vec![flint_vm::StagedLayer { kind: LayerKind::FsTarGz, path: tar }]
                } else {
                    Vec::new()
                }
            }
        };

        // Upload layers + build manifest.
        let mut layers = Vec::new();
        for l in staged {
            let name = layer_file_name(&l.kind);
            let bytes = tokio::fs::read(&l.path).await?;
            flint_core::metrics::counter_add(
                flint_core::metrics::names::WAL_BYTES,
                &[("kind", "snapshot_upload".into())],
                bytes.len() as u64,
            );
            let objects = self.rt.objects.clone();
            let key = format!("snapshots/{}/{}/{}", self.info.sandbox_id, snap_id, name);
            let upload_key = key.clone();
            tokio::task::spawn_blocking(move || objects.put(&upload_key, &bytes))
                .await
                .map_err(|e| FlintError::Internal(format!("join: {e}")))??;
            let (sha, size) = sha256_file(&l.path)?;
            layers.push(Layer { key, kind: l.kind, sha256: sha, size_b: size });
        }

        // Collect restartables from the WAL (best-effort).
        let restartable = collect_restartables(self.wal.path());

        let wal_seq = self.wal.len();
        let manifest = SnapshotManifest {
            snap_id: snap_id.clone(),
            sandbox_id: self.info.sandbox_id.clone(),
            kind,
            created_at_ms: flint_core::util::now_ms(),
            wal_seq,
            layers,
            vm: self.info.vm,
            template_id: self.info.template_snapshot_id.clone(),
            env: self.info.env.clone(),
            metadata: BTreeMap::new(),
            restartable,
        };
        let manifest_json = serde_json::to_string(&manifest)?;
        {
            let objects = self.rt.objects.clone();
            let key = format!("snapshots/{}/{}/manifest.json", self.info.sandbox_id, snap_id);
            let body = manifest_json.clone().into_bytes();
            tokio::task::spawn_blocking(move || objects.put(&key, &body))
                .await
                .map_err(|e| FlintError::Internal(format!("join: {e}")))??;
        }
        self.wal
            .append(WalRecord::SnapshotRef {
                snap_id: snap_id.clone(),
                wal_seq,
                manifest_json: manifest_json.clone(),
            })
            .map_err(|e| FlintError::Internal(format!("wal snapref: {e}")))?;

        self.current_snapshot_id = Some(snap_id.clone());
        flint_core::metrics::counter_inc(flint_core::metrics::names::OPS_TOTAL, &[("op", "snapshot".into()), ("result", "ok".into())]);
        Ok(snap_id)
    }

    async fn do_resume(&mut self) -> Result<()> {
        if matches!(self.instance_kind(), flint_core::DriverKind::Firecracker) && self.instance.is_some() {
            // Frozen VM: resume in place.
            self.set_state(SandboxState::Resuming).await;
            let instance = self.instance.as_ref().unwrap();
            instance.resume().await?;
            self.set_state(SandboxState::Running).await;
            return Ok(());
        }
        // No live instance (process driver / crash): respawn + replay.
        self.set_state(SandboxState::Resuming).await;
        self.respawn_with_recovery().await?;
        self.set_state(SandboxState::Running).await;
        Ok(())
    }

    async fn respawn_with_recovery(&mut self) -> Result<()> {
        // Find the newest SnapshotRef in the WAL (or use current).
        let manifest = self.latest_manifest();
        let restore = match &manifest {
            Some(m) => Some(self.rt.stage_layers(&m.snap_id, m, &self.sdir).await?),
            None => None,
        };
        let spawn_req = SpawnRequest {
            sandbox_id: self.info.sandbox_id.clone(),
            vm: self.info.vm,
            env: self.info.env.clone(),
            agent_token: self.info.agent_token.clone(),
            restore,
            netns: None,
            template_drive: None,
            cid: None,
        };
        let instance = self.rt.driver.spawn(spawn_req).await?;
        self.instance = Some(instance);

        // Replay WAL ops past the snapshot boundary.
        let from_seq = manifest.as_ref().map(|m| m.wal_seq).unwrap_or(0);
        self.replay_wal(from_seq).await?;
        Ok(())
    }

    fn latest_manifest(&self) -> Option<SnapshotManifest> {
        let (records, _) = flint_journal::wal::recover_records(self.wal.path());
        records
            .iter()
            .rev()
            .find_map(|(_, r)| match r {
                WalRecord::SnapshotRef { manifest_json, .. } => {
                    serde_json::from_str(manifest_json).ok()
                }
                _ => None,
            })
    }

    async fn replay_wal(&mut self, from_seq: u64) -> Result<()> {
        let (records, _) = flint_journal::wal::recover_records(self.wal.path());
        let mut applied: std::collections::HashSet<String> = Default::default();
        let home = self
            .instance
            .as_ref()
            .and_then(|i| i.home_dir().map(|h| h.to_path_buf()));
        let agent = self.agent()?.clone();
        let mut replayed = 0usize;
        let mut restartables: Vec<ExecSpec> = Vec::new();

        for (seq, rec) in records {
            if seq <= from_seq {
                // Still collect restartables from before the boundary.
                if let WalRecord::OpApplied { op: Op::ProcessSpawn { spec, .. }, .. } = rec {
                    restartables.push(spec);
                }
                continue;
            }
            match rec {
                WalRecord::OpApplied { op_id, op } => {
                    if !applied.insert(op_id.clone()) {
                        continue;
                    }
                    match &op {
                        Op::FileWrite { .. } | Op::FileRemove { .. } | Op::Mkdir { .. } | Op::FileMove { .. } => {
                            if let Some(home) = &home {
                                // ProcessDriver: apply directly on the host.
                                let _ = op.apply_fs(home);
                            } else {
                                // Firecracker: apply through the agent.
                                if let Some(params) = op_to_agent_params(&op, &op_id) {
                                    let method = match &op {
                                        Op::FileWrite { .. } => M::FS_WRITE,
                                        Op::FileRemove { .. } => M::FS_REMOVE,
                                        Op::Mkdir { .. } => M::FS_MKDIR,
                                        _ => M::FS_MOVE,
                                    };
                                    let _ = agent.call(method, params).await;
                                }
                            }
                            replayed += 1;
                        }
                        Op::EnvSet { key, value } => {
                            let _ = agent.call(M::ENV_SET, json!({ "key": key, "value": value })).await;
                        }
                        Op::ProcessSpawn { spec, .. } => restartables.push(spec.clone()),
                        Op::Exec { .. } | Op::ProcessKill { .. } => {}
                    }
                }
                _ => {}
            }
        }

        // Re-spawn restartable processes (Journal+FS tier: processes are
        // restarted from recorded specs, not restored from memory).
        for spec in restartables.into_iter().take(16) {
            let mut s = spec;
            s.pty = None;
            let _ = agent
                .call(
                    M::PROCESS_SPAWN,
                    json!({ "spec": s, "op_id": flint_core::ids::new_id("op") }),
                )
                .await;
        }
        if replayed > 0 {
            tracing::info!(sandbox = %self.info.sandbox_id, replayed, "journal replay complete");
        }
        Ok(())
    }

    // ----- reconciler -----

    async fn on_tick(&mut self) {
        let state = *self.state.read().await;
        match state {
            SandboxState::Running => {
                // Liveness.
                let alive = match self.instance.as_ref() {
                    Some(i) => i.is_alive().await,
                    None => false,
                };
                if !alive {
                    tracing::warn!(sandbox = %self.info.sandbox_id, "instance died — crash recovery");
                    self.set_state(SandboxState::Error).await;
                    match self.respawn_with_recovery().await {
                        Ok(()) => {
                            tracing::info!(sandbox = %self.info.sandbox_id, "crash recovery succeeded");
                            self.set_state(SandboxState::Running).await;
                        }
                        Err(e) => {
                            tracing::error!(sandbox = %self.info.sandbox_id, error = %e, "crash recovery failed");
                            self.set_state(SandboxState::Error).await;
                        }
                    }
                    return;
                }
                // Idle auto-pause.
                let now = flint_core::util::now_ms();
                if let Some(idle_ms) = self.info.timeouts.auto_pause_after_idle_ms {
                    if now - self.last_activity_ms > idle_ms as i64 {
                        tracing::info!(sandbox = %self.info.sandbox_id, "idle timeout → auto-pause");
                        let _ = self.do_pause(SnapshotKind::Pause).await;
                        return;
                    }
                }
                // Wall-clock TTL.
                if let Some(ttl) = self.info.timeouts.max_ttl_ms {
                    if now - self.created_at_ms > ttl as i64 {
                        tracing::info!(sandbox = %self.info.sandbox_id, "ttl expiry");
                        use flint_core::state::ExpiryAction;
                        match self.info.timeouts.expiry_action {
                            ExpiryAction::Pause => {
                                let _ = self.do_pause(SnapshotKind::Pause).await;
                            }
                            ExpiryAction::Stop => {
                                let _ = self.do_stop().await;
                            }
                            ExpiryAction::Delete => {
                                self.rt
                                    .send_report(&self.info.sandbox_id, "deleted", "", "ttl_expiry")
                                    .await;
                                let _ = self.do_stop().await;
                            }
                        }
                    }
                }
            }
            SandboxState::Error => {
                // Periodic retry of recovery.
                if self.tick_seq % 30 == 0 {
                    if self.respawn_with_recovery().await.is_ok() {
                        self.set_state(SandboxState::Running).await;
                    }
                }
            }
            _ => {}
        }
    }
}

fn collect_restartables(wal_path: &Path) -> Vec<ExecSpec> {
    let (records, _) = flint_journal::wal::recover_records(wal_path);
    let mut seen = std::collections::HashSet::new();
    let mut out = Vec::new();
    for (_, rec) in records {
        if let WalRecord::OpApplied { op: Op::ProcessSpawn { spec, proc_id }, .. } = rec {
            if seen.insert(proc_id) {
                out.push(spec);
            }
        }
    }
    out
}

fn params_to_op(kind: &str, params: &Value, op_id: &str) -> Option<Op> {
    let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("").to_string();
    match kind {
        "fs.write" => Some(Op::FileWrite {
            path,
            content_b64: params.get("content_b64").and_then(|v| v.as_str()).unwrap_or("").to_string(),
            mode: params.get("mode").and_then(|v| v.as_u64()).map(|m| m as u32),
        }),
        "fs.mkdir" => Some(Op::Mkdir {
            path,
            recursive: params.get("recursive").and_then(|v| v.as_bool()).unwrap_or(false),
        }),
        "fs.remove" => Some(Op::FileRemove {
            path,
            recursive: params.get("recursive").and_then(|v| v.as_bool()).unwrap_or(false),
        }),
        "fs.move" => Some(Op::FileMove {
            from: params.get("from").and_then(|v| v.as_str()).unwrap_or("").to_string(),
            to: params.get("to").and_then(|v| v.as_str()).unwrap_or("").to_string(),
        }),
        _ => {
            let _ = op_id;
            None
        }
    }
}

fn op_to_agent_params(op: &Op, op_id: &str) -> Option<Value> {
    match op {
        Op::FileWrite { path, content_b64, mode } => Some(json!({
            "path": path, "content_b64": content_b64, "mode": mode, "op_id": op_id
        })),
        Op::Mkdir { path, recursive } => Some(json!({ "path": path, "recursive": recursive, "op_id": op_id })),
        Op::FileRemove { path, recursive } => Some(json!({ "path": path, "recursive": recursive, "op_id": op_id })),
        Op::FileMove { from, to } => Some(json!({ "from": from, "to": to, "op_id": op_id })),
        _ => None,
    }
}

async fn agent_client_event(rx: &mut tokio::sync::mpsc::Receiver<flint_vm::StreamMsg>) -> Option<SupEvent> {
    use flint_vm::StreamMsg;
    match rx.recv().await {
        Some(StreamMsg::Event { kind, data, .. }) => Some(SupEvent {
            kind,
            payload: data.to_string(),
            final_: false,
            error: None,
        }),
        Some(StreamMsg::End { ok, result, error }) => Some(SupEvent {
            kind: if ok { "closed".into() } else { "error".into() },
            payload: result.to_string(),
            final_: true,
            error,
        }),
        None => Some(SupEvent { kind: "closed".into(), payload: String::new(), final_: true, error: None }),
    }
}
