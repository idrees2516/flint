# Flint

**Firecracker microVM sandboxes for AI agents — control plane, worker fleet, in-sandbox agent, and tooling, all in Rust.**

Flint is a production-shaped implementation of the "sandbox platform for AI agents"
category (E2B, Daytona, Morph, Modal, Runloop, Cloudflare, CodeSandbox, Vercel,
Freestyle, Beam, Blaxel, Boat.dev, Tensorlake). Every design decision is traced to
research on those systems — see `research/` (17 notes) and `ARCHITECTURE.md`.

```
     ┌──────────────────────────────────────────────────────────────┐
     │                     flint-gateway (control plane)             │
     │  REST /v1/* ── WS terminal+exec+events ── gRPC :7473         │
     │  auth (API keys) · quotas · rate limits · scheduling          │
     └───────────────┬──────────────────────────────┬───────────────┘
                     │ gRPC fleet protocol          │ snapshots (local/S3)
      ┌──────────────┴──────────────┐   ┌───────────▼───────────────┐
      │      flint-worker (node)    │   │   object store + templates│
      │  SandboxSupervisor actor    │   └───────────▲───────────────┘
      │   ├─ VmDriver (firecracker/ │               │
      │   │   process-dev)          │   ┌───────────┴───────────────┐
      │   ├─ WAL journal + snapshots┼──►│  WAL → tar.gz/memfile      │
      │   ├─ crash recovery (replay)│   └───────────────────────────┘
      │   └─ net slot + egress nft  │
      └──────────────┬──────────────┘
                     │ vsock UDS "CONNECT 5252\n" (prod) / TCP (dev)
      ┌──────────────▼──────────────┐
      │   flint-guest-agent (in VM) │  exec · PTY · files · processes
      │   + flint-tools broker      │  web_search / http_fetch (proxied)
      └─────────────────────────────┘
```

## Quick start (dev mode — one binary, no KVM)

```bash
cargo build --workspace
FLINT_GUEST_AGENT_BIN=target/debug/flint-guest-agent \
FLINT_BOOTSTRAP_API_KEY=dev-key \
target/debug/flint-gateway --dev
# FLINT_BOOTSTRAP_API_KEY=dev-key is printed once on first boot otherwise.

export FLINT_URL=http://127.0.0.1:8080 FLINT_API_KEY=dev-key
flint() { target/debug/flint "$@"; }

flint create                                # sandbox (process driver — dev only)
flint exec <id> "echo hello"                # run AI-written code
flint upload <id> app.py /app/app.py        # files
flint exec <id> "python3 app.py"
flint pause <id>                            # snapshot (tar.gz layer + manifest)
flint resume <id>                           # restore + WAL replay — state preserved
flint fork <id> 2                           # branch into 2 clones
flint search "rust json parsers"            # brokered web-search tool
```

Dev mode uses the **ProcessDriver**: real guest agent, real journaling, real
snapshots, real gRPC fleet protocol — but the "VM" is a process group.
**It is not an isolation boundary.** Production runs `flint-worker` with the
Firecracker driver on KVM nodes.

## What's implemented

| Capability | Details |
|---|---|
| **Isolation (prod)** | Firecracker microVMs via jailer (chroot, cgroups, seccomp), vsock agent channel, per-sandbox netns + veth + TAP, nftables egress policy (default-deny capable, IP/SNI allowlists) |
| **Isolation (dev/CI)** | Process driver — full protocol parity, zero isolation |
| **Lifecycle** | Typed state machine: `Creating → Running ⇄ Paused ⇄ Stopped`, `Snapshotting/Forking/Error/Deleted`; reconciler drives drift |
| **Durability** | CRC-framed WAL (write-ahead, fsync'd), journaled FS ops replayable by idempotency key, guest-side journal, tar.gz layer snapshots + manifests in the object store (local FS or S3-compatible w/ SigV4) |
| **Crash recovery** | Liveness probe → restore last snapshot → deterministic WAL replay of FS ops → restart `restartable` processes |
| **Pause tiers** | Pause = memory-preserving snapshot in prod (FC memfile+snapfile+drive layers); Stop = disk-only |
| **Fork/branch** | `POST /fork {count}` — snapshot base + N parallel restores (same artifact shape as create) |
| **Timeouts** | `auto_pause_after_idle`, `auto_stop_after_idle`, `max_ttl` + `expiry_action` (pause/stop/delete), `wake_on_request` (auto-resume on traffic) |
| **APIs** | REST (`/v1/...`), WebSocket (terminal PTY, events, exec stream), gRPC (Sandbox/Exec/File/Tool/Template services + fleet protocol) |
| **Agent tools** | `web_search` (DuckDuckGo keyless / Brave / Tavily), `http_fetch` (SSRF-guarded), quota-enforced per key |
| **Exec** | Any binary/script (exec-any incl. Rust via toolchain in the image), optional PTY, timeouts, env overlays, background processes w/ signals, stdin |
| **Templates** | Snapshot a sandbox → reusable base (`/v1/templates/from-sandbox/:id`); create = snapshot restore, never a cold boot |
| **Scheduling** | Best-of-K placement, max-pressure + jitter scoring, drain, stale eviction, warm pools |
| **Auth/metering** | API keys (hashed), token-bucket rate limits, concurrent-sandbox + tool-call quotas, usage endpoint, Prometheus `/metrics` |

## Layout

```
crates/
  flint-core          ids, errors, state machine, config, metrics, ratelimit,
                      HMAC tokens, agent wire protocol, minhttp (HTTP/1.1 over
                      any async stream), guest-agent protocol framing
  flint-journal       WAL (CRC frames, torn-tail truncation), replayable ops,
                      snapshot manifests, tar.gz packer (escape-proof unpack)
  flint-store         SQLite metadata catalog, local + S3 (SigV4) object stores
  flint-net           IPAM (/31 slot pool), netns+veth+TAP provisioning, egress policy
  flint-vm            VmDriver trait, Firecracker driver (typed UDS API payloads,
                      vsock CONNECT handshake, snapshot create/load, jailer),
                      Process driver, multiplexed GuestAgentClient
  flint-proto         protobuf + tonic codegen (api.proto, fleet.proto)
  flint-scheduler     best-of-K placement, worker registry, warm pools
  flint-tools         web search providers + http_fetch + quotas
  flint-guest-agent   in-sandbox binary: exec/PTY/processes/files/journal/env,
                      terminals, port tunnels; vsock + TCP transports
  flint-worker        node daemon: SandboxSupervisor actor per sandbox,
                      journaling, snapshot upload, crash recovery (WAL replay),
                      fleet client (register/heartbeat) + WorkerService gRPC
  flint-gateway       control plane: REST + WS + gRPC, auth, quotas, routing,
                      preview proxy (HTTP into sandbox via port tunnels)
  flint-cli           `flint` — human CLI
  flint-e2e           end-to-end tests (boot the real binaries)
deploy/               systemd units, config examples, Dockerfile, guest rootfs build
docs/                 API reference, operations, security
research/             17 vendor + technology research notes backing the design
```

## Running the real thing (microVMs)

1. Build a guest rootfs with `deploy/guest-rootfs/build.sh` (Debian + guest-agent +
   python3/node/gcc/rustup) and a Firecracker-compatible kernel.
2. Configure a worker with `driver.kind = "firecracker"` (see
   `deploy/flint-worker.toml.example`): firecracker + jailer binaries, kernel
   image, rootfs dir, netns-enabled networking.
3. Point workers at the gateway's gRPC address; sandboxes land via the scheduler
   and speak to the agent over vsock.

Requires: Linux, /dev/kvm, root for jailer/netns/nft (see docs/OPERATIONS.md).

## Tests

```bash
cargo test --workspace        # 52 unit + integration tests
cargo test -p flint-e2e --test e2e -- --nocapture   # full-stack lifecycle
```

The e2e suite boots the actual `flint-gateway --dev` binary and drives:
create → exec → journaled file writes → pause + snapshot (manifest + layers
verified on disk) → resume with state preservation → explicit snapshot →
fork into 2 clones (state inherited) → background process lifecycle →
usage → delete, plus auth enforcement.

## Honest limitations (v1)

- No live migration (nobody has it — pause/snapshot/restore is the path).
- Memory-state crash recovery: clean pause only; a crash resumes from the last
  snapshot + WAL replay (process state is restarted from recorded specs, per
  the chosen Journal+FS durability tier).
- gRPC exec streaming returns aggregated events (WS/SSE are the streaming paths).
- S3 snapshots are full layers (no diff-layer compaction daemon yet).
- Diff (dirty-page) FC snapshots plumbed but full snapshots shipped first.

License: Apache-2.0.
