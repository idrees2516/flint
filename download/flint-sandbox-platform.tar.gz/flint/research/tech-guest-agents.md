# Guest Agents & Guest Tooling for microVM Sandboxes (R4 research)

Sources: E2B `packages/envd` source (spec/process/process.proto, spec/filesystem, internal/host/mmds.go, main.go), E2B ARCHITECTURE.md, devcontainer spec (containers.dev), Vercel/Tensorlake sandbox docs.

## 1. What the guest agent must provide

A sandbox platform's in-VM agent (E2B calls it **envd**; GCP/E2B template docs; CodeSandbox historically used a custom "control" agent) is the SDK's hands inside the VM. Required surface:

- **Process service**: `Start` (cmd, args, envs, cwd, optional PTY w/ cols/rows, tag, stdin flag), `List` (pid, config, tag), `Connect` (stream of events for an existing process), `SendInput` / `StreamInput` (bidirectional stdin), `SendSignal` (by PID/tag), `CloseStdin`, `Update` (resize PTY). Events: `StartEvent` (pid, tag), `DataEvent` (stdout/stderr, base64), `EndEvent` (exit code, timestamped), `KeepAlive`. This is **Connect RPC** (protobuf over HTTP/2) in E2B, served by chi + connect on **port 49983**.
- **Filesystem service**: `Stat`, `MakeDir`, `Move`, `ListDir`, `Remove`, `WatchDir`/`CreateWatcher`/`GetWatcherEvents`/`RemoveWatcher` (inotify-based), plus REST `/files` upload/download (signed URLs) and `/envs`.
- **Supervision/reaping**: envd runs as PID>1 daemon under systemd **very early in boot**, runs a subreaper (`internal/reaper`) to adopt orphans, per-process **cgroups** (cgroup2) for isolation + accounting, CPU limits per process, `cpu` + `memory` services.
- **Env & metadata**: `POST /init` — orchestrator pushes env vars, access token, metadata after boot/resume (retried until envd ready; this is the last step of Create). Token can also be pulled from **MMDS** (169.254.169.254, IMDSv2-style `PUT /latest/api/token`, TTL 60s, `X-metadata-token` header, timeout 10s) — E2B passes "sandbox ID + envd access token hash" through MMDS so nothing secret rides the API socket path.
- **Auth**: `X-Access-Token` header validated against the token delivered by MMDS//init. Control routes (`/init`, `/upgrade`, freeze/thaw hooks) are marked `x-internal: true` in `spec/envd.yaml` and rejected (404) at the public proxy.
- **Port forwarding**: envd scans guest ports every **1000 ms** (`portScannerInterval`), opens forwarded listeners, so any port a user process binds becomes reachable at `https://<port>-<sandboxID>.<domain>`.
- **Heartbeats / liveness**: version endpoint + health (`/health`), metrics (`/metrics`), log exporter (HTTP push to collector), `X-Envd-Handover` header reporting upgrade outcomes.
- **Freeze/thaw hooks** used during pause (quiesce userspace before snapshot) — e.g. envd coordinates `cgroups` freeze of workload before FC pause, thaws after resume.

## 2. Agent transport & channel design

- E2B (current, 2025-2026): envd is a **plain HTTP/2 + REST server on the guest's eth0 IP:49983**, reached by the orchestrator from the host netns at the slot IP (10.11.x.y). SDKs talk to it **through** client-proxy → orchestrator proxy (:5007) with access tokens. Idle timeouts 640 s; port 49983; version handshake gates features (`pkg/version.go` bumped on every behavioral change).
- Why not vsock for envd: ingress (browser → sandbox URL) must traverse real networking anyway; TCP lets the same server serve both control and data. vsock would add a second transport + a host-side proxy hop without removing the TAP.
- What vsock is still for (in general platforms): out-of-band rescue channel when guest networking is broken, bootstrap before IP config, metadata without MMDS NIC requirement. MicroCloud/microsandbox/libkrun, Kata use AF_VSOCK with the host listening on `uds_path` UDS (see tech-networking.md for the CONNECT/`_PORT` protocol).
- **Live agent upgrade without killing the workload** (E2B `internal/services/process/upgrade.go`): orchestrator streams a new envd binary to `POST /upgrade`; new envd `syscall.Exec`s **with the same PID**, carrying: workload stdio/PTY FDs, process table (re-adopted via subreaper), recently-retained exit codes, FS watchers — through a **tmpfs handover blob**. Workload cgroups stay frozen until post-upgrade `/init` re-delivers the access token. For too-old agents, **offline swap**: rewrite `/usr/bin/envd` in the rootfs image pre-boot via jailed `debugfs` (no host mount of tenant image). Lesson for us: agent must be self-contained (static binary), field-upgradable, and PID/parent-of-all-processes aware.

## 3. Templates & devcontainers

- E2B templates = pre-booted VM snapshots built from a **recipe**: `POST /v3/templates` (cpu, ram, free-disk) + `POST /v2/templates/{id}/builds/{buildID}` (steps, start/ready commands). Build phases (template-manager): pull Docker image → inject envd + provisioning → extract ext4 rootfs → boot real FC VMs per phase (provision → user steps → resize disk → finalize → **optimize**: records which memory pages a fresh resume touches → prefetch hints). **Layered**: each step a hashed, cached layer; rebuilds only re-run changed steps. Artifacts in object storage: `{buildID}/memfile`, `{buildID}/rootfs.ext4`, `{buildID}/snapfile`, `{buildID}/metadata.json` + `.header` index files.
- **devcontainer.json** (containers.dev spec) as template input: `image` or `build.dockerfile`/`buildArgs` (OCI base), `features` (id@version:options — tarballs installing tools, merged into image layers), `containerEnv`/`remoteEnv`, `forwardPorts`, `postCreateCommand`, `customizations`. Mapping to microVM sandboxes: `image`+`features`+`build` → rootfs layer; `containerEnv` → MMDS//init env vars; `forwardPorts` → envd port-forward registry; `postCreateCommand` → first-boot phase before snapshot optimize. Third parties (devsandboxes.com, GKE sandbox "warm pools") already implement devcontainer-on-microVM loops, so devcontainer.json is a reasonable template-format choice for UX familiarity, while the build pipeline stays Docker-in-Firecracker.

## 4. Guest OS & kernel requirements

- Minimal kernel: ~5 MB compressed; recommended configs from FC repo `resources/guest_configs/` (CI kernels: 5.10/6.1 microvm kernels). Must-haves: `CONFIG_VIRTIO_PCI` off (MMIO), `CONFIG_VIRTIO_BLK/NET/VSOCKETS`, `CONFIG_KVM_GUEST`, `CONFIG_SERIAL_8250` console, `CONFIG_MEMCG` etc. in guest for per-process accounting; disable legacy hardware probing (`pci=off`, `reboot=k`, `panic=1`, `random.trust_cpu=on` in boot_args; E2B reserves `init/root/ip/clocksource/console/panic/reboot/loglevel/quiet/selinux` params, disallows user overrides).
- Init: E2B uses a custom init → systemd unit `envd.service` (Wants network). For fastest boots: custom static init + static IP from kernel cmdline, no udev, no DHCP. For usability: systemd with `systemd.unit=...` trimmed targets. Root on overlay: `overlay-init` mounts overlayfs then switch_root.
- Clock: `clocksource=kvm-clock` (x86) + timesyncd/chrony; `clock_realtime: true` on resume for kvm-clock (host ≥ 5.16).
- Observability: envd pushes logs to a collector via HTTP (10s batches); host stats via cgroup v2 (`memory.current`, `cpu.stat`) read by orchestrator → ClickHouse (`sandbox_host_stats`).

## 5. Agent design checklist for our Rust implementation

1. Static musl Rust agent (`/usr/bin/flint-agent`), systemd unit, one HTTP/2 server (h2c) on a well-known port; also listen on AF_VSOCK port 5252 for bootstrap (net-config push, token delivery) before eth0 is up.
2. gRPC/Connect schema: Process (start/list/input/signal/pty resize/exit-events streaming), FS (stat/list/mkdir/mv/rm/watch), plus `/init`, `/healthz`, `/v1/metadata` (MMDS token flow), `/pause` freeze hooks.
3. Process supervision: `PR_SET_CHILD_SUBREAPER`, per-proc cgroup2 dirs (`process-<pid>`) with pids.max/memory.max/cpu.max; PTY via `openpty` + epoll; OOM notification via cgroup events.
4. Security: constant-time token check, auth-fail metrics, control routes blocked at proxy, agent upgrade path with fd handover (mimic E2B's tmpfs handover).
5. Snapshot-awareness: on VMGenID change (poll `/sys/devices/virtual/misc/vmgenid/id`), reseed userspace RNG, re-register identity with control plane, refresh ARP (guest may flush `ip neigh`), re-sync clock.
