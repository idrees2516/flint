//! Replayable sandbox operations.
//!
//! `Op` is the unit of durable state change. File ops are *replayable*
//! (payloads are complete); exec/process ops are *audit + restart* ops.

use flint_core::{ExecSpec, Result};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::{Component, Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Op {
    FileWrite {
        /// Sandbox-absolute path, e.g. `/home/user/main.py`.
        path: String,
        content_b64: String,
        #[serde(default)]
        mode: Option<u32>,
    },
    FileRemove {
        path: String,
        #[serde(default)]
        recursive: bool,
    },
    Mkdir {
        path: String,
        #[serde(default)]
        recursive: bool,
    },
    FileMove {
        from: String,
        to: String,
    },
    EnvSet {
        key: String,
        value: String,
    },
    /// Audit-only: a blocking exec that ran (never replayed).
    Exec { spec: ExecSpec },
    /// A background process spawn; replayable as a *restart* after crash.
    ProcessSpawn { spec: ExecSpec, proc_id: String },
    /// Recorded process kill (audit; replay kills are no-ops).
    ProcessKill { proc_id: String, signal: i32 },
}

#[derive(Debug, thiserror::Error)]
pub enum OpError {
    #[error("path escapes sandbox root: {0}")]
    Escape(String),
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("bad base64 payload: {0}")]
    BadPayload(String),
}

/// Resolve a sandbox-absolute path against a host root, rejecting escapes.
/// Sandbox paths always start with `/`; `..` components are rejected
/// unless they stay inside the root.
pub fn safe_join(root: &Path, sandbox_path: &str) -> std::result::Result<PathBuf, OpError> {
    let rel = sandbox_path.trim_start_matches('/');
    if sandbox_path.contains('\0') {
        return Err(OpError::Escape(sandbox_path.to_string()));
    }
    let mut out = root.to_path_buf();
    let mut depth: i32 = 0;
    for comp in Path::new(rel).components() {
        match comp {
            Component::Normal(c) => {
                out.push(c);
                depth += 1;
            }
            Component::CurDir => {}
            Component::ParentDir => {
                if depth == 0 {
                    return Err(OpError::Escape(sandbox_path.to_string()));
                }
                out.pop();
                depth -= 1;
            }
            _ => return Err(OpError::Escape(sandbox_path.to_string())),
        }
    }
    Ok(out)
}

impl Op {
    /// Is this op replayable onto a filesystem after crash recovery?
    pub fn is_replayable(&self) -> bool {
        matches!(self, Op::FileWrite { .. } | Op::FileRemove { .. } | Op::Mkdir { .. } | Op::FileMove { .. })
    }

    /// Apply a file op to `root` (idempotent by nature of the payload).
    pub fn apply_fs(&self, root: &Path) -> std::result::Result<(), OpError> {
        match self {
            Op::FileWrite { path, content_b64, mode } => {
                let target = safe_join(root, path)?;
                if let Some(parent) = target.parent() {
                    std::fs::create_dir_all(parent)?;
                }
                let bytes = base64_decode(content_b64)
                    .map_err(|e| OpError::BadPayload(e.to_string()))?;
                std::fs::write(&target, &bytes)?;
                if let Some(m) = mode {
                    use std::os::unix::fs::PermissionsExt;
                    let _ = std::fs::set_permissions(&target, std::fs::Permissions::from_mode(*m));
                }
                Ok(())
            }
            Op::FileRemove { path, recursive } => {
                let target = safe_join(root, path)?;
                if *recursive {
                    if target.exists() {
                        std::fs::remove_dir_all(&target)?;
                    }
                } else if target.is_dir() {
                    std::fs::remove_dir(&target).map_err(OpError::from)?;
                } else if target.exists() {
                    std::fs::remove_file(&target)?;
                }
                Ok(())
            }
            Op::Mkdir { path, recursive } => {
                let target = safe_join(root, path)?;
                if *recursive {
                    std::fs::create_dir_all(&target)?;
                } else {
                    std::fs::create_dir(&target).map_err(OpError::from)?;
                }
                Ok(())
            }
            Op::FileMove { from, to } => {
                let src = safe_join(root, from)?;
                let dst = safe_join(root, to)?;
                if let Some(parent) = dst.parent() {
                    std::fs::create_dir_all(parent)?;
                }
                if src.exists() {
                    std::fs::rename(&src, &dst)?;
                }
                Ok(())
            }
            Op::EnvSet { .. } | Op::Exec { .. } | Op::ProcessSpawn { .. } | Op::ProcessKill { .. } => {
                Ok(()) // not a filesystem op
            }
        }
    }
}

fn base64_decode(s: &str) -> Result<Vec<u8>> {
    flint_core::util::b64_decode(s)
}

/// Replay a sequence of ops (post-snapshot ones) into a sandbox root and
/// an env map. Deduplicates by `op_id`; returns the set of applied ids.
pub fn replay(
    root: &Path,
    env: &mut BTreeMap<String, String>,
    ops: &[(String, Op)],
) -> std::result::Result<std::collections::HashSet<String>, OpError> {
    let mut applied = std::collections::HashSet::new();
    for (op_id, op) in ops {
        if !applied.insert(op_id.clone()) {
            continue;
        }
        if let Op::EnvSet { key, value } = op {
            env.insert(key.clone(), value.clone());
        } else if let Err(e) = op.apply_fs(root) {
            tracing::warn!(op_id = %op_id, error = %e, "replay: op failed (continuing)");
        }
    }
    Ok(applied)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn safe_join_blocks_escapes() {
        let root = Path::new("/srv/sbx");
        assert!(safe_join(root, "/home/user/a.py").is_ok());
        assert!(safe_join(root, "/a/../../etc/passwd").is_err());
        assert!(safe_join(root, "../../etc/passwd").is_err());
        assert!(safe_join(root, "/a/b/../c.txt").is_ok());
    }

    #[test]
    fn file_ops_replay_idempotently() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        let write = Op::FileWrite {
            path: "/home/u/x.txt".into(),
            content_b64: flint_core::util::b64_encode(b"hello"),
            mode: Some(0o644),
        };
        write.apply_fs(root).unwrap();
        write.apply_fs(root).unwrap(); // idempotent
        assert_eq!(std::fs::read(root.join("home/u/x.txt")).unwrap(), b"hello");

        let mkdir = Op::Mkdir { path: "/work".into(), recursive: true };
        mkdir.apply_fs(root).unwrap();

        let mv = Op::FileMove { from: "/home/u/x.txt".into(), to: "/work/y.txt".into() };
        mv.apply_fs(root).unwrap();
        assert!(root.join("work/y.txt").exists());

        let rm = Op::FileRemove { path: "/work".into(), recursive: true };
        rm.apply_fs(root).unwrap();
        assert!(!root.join("work").exists());
    }

    #[test]
    fn replay_applies_env_and_dedupes() {
        let tmp = tempfile::tempdir().unwrap();
        let mut env = BTreeMap::new();
        let ops = vec![
            ("op_1".to_string(), Op::EnvSet { key: "K".into(), value: "V".into() }),
            ("op_1".to_string(), Op::EnvSet { key: "K".into(), value: "IGNORED".into() }),
            ("op_2".to_string(), Op::FileWrite {
                path: "/f".into(),
                content_b64: flint_core::util::b64_encode(b"1"),
                mode: None,
            }),
        ];
        let applied = replay(tmp.path(), &mut env, &ops).unwrap();
        assert_eq!(applied.len(), 2);
        assert_eq!(env.get("K").unwrap(), "V");
    }
}
