# Blaxel (blaxel.ai) — Deep Research

*Researched by task R2, October 2025. Sources: blaxel.ai, docs.blaxel.ai, github.com/blaxel-ai.*

## Overview
Blaxel (formerly **Beamlit**) is "infrastructure for autonomous agents": a managed cloud where **perpetual sandboxes** — microVMs that "boot in milliseconds and resume in ~25ms" — are the flagship, surrounded by an agent-native platform: Agents Hosting (serverless auto-scaling endpoints), Batch Jobs, MCP Servers Hosting, Model Gateway, Volumes, **Agent Drive** (shared distributed filesystem), and an egress proxy with secrets injection. Its differentiating bet: sandboxes *suspend to zero* after ~5–15s idle and resume in ~25ms **with full memory, processes, and filesystem** — "close the lid, open it months later, and pick up exactly where you left off" — so standby is unlimited and idle time is (nearly) free. Blaxel is MCP-first: "all products are accessible through MCP servers, allowing agents to create and manage resources via tool calls." SOC 2, HIPAA, ISO 27001; US + EU regions; claims scale to 100,000+ concurrent sandboxes.

## Isolation & Architecture
- Every sandbox is a **hardware-isolated microVM ("no shared kernel")** with root filesystem **in RAM** ("RAM-speed filesystem"), giving Zero Data Retention when destroyed (memory-only rootfs = data wiped on delete).
- Runs on the "**Global Agentics Network**": a natively serverless, multi-region execution layer decoupled from a federated data layer, optimizing placement for latency; workloads co-locate (agent API + MCP servers + batch tasks alongside sandboxes) "to eliminate network hops."
- Standby mechanics (docs): active mode persists while there's an active connection; after ~15s without one (or 15min idle WebSocket/TCP), Blaxel **automatically snapshots the entire state** (files + running processes) and scales to zero; reconnect resumes in ~25ms "even after weeks." Snapshots preserve processes/filesystem but **not external network connections** (DBs, queues, HTTP pools die on standby). Each sandbox embeds a **custom API binary** enabling process management and file ops; a built-in MCP server per sandbox exposes those as tool calls.

## API Surface
- SDKs (TypeScript/Python/Go), CLI (`bl`, with `bl skills install` giving Cursor/Claude Code/Codex the ability to operate the platform), REST API for every resource, web console, and MCP servers; `blaxel.toml` deployment config.
- Sandbox resource model: memory allocation implies CPU (e.g., 8GB → 4 cores, 16GB → 6 cores); CPU not billed separately.
- Sandbox features: process exec & lifecycle with log streaming (batch + real-time), filesystem CRUD, codegen-optimized tools (edit/format/search), **snapshots & forking** (checkpoint, roll back, fork into parallel sandboxes), **archive/unarchive** (persist filesystem over image, processes restarted with new PIDs — cheaper than standby), ports, preview URLs with custom domains/CORS/auth, client-side session tokens (frontend operates sandboxes directly, no proxy), standby control (WebSocket ping/pong, activity timeouts), cron/future/delay schedules per sandbox, Dockerfile-built reusable images, non-root users.
- Networking: managed egress **proxy with MITM header/body injection**, **secrets injection** ("credentials never live in the sandbox"), per-domain/method/path firewalls, static egress IPs.

## Persistence & Checkpointing
- **Standby snapshots** are the core mechanism: automatic full-state capture on idle, memory+processes+filesystem restored in ~25ms; charged only $0.20/GB-month snapshot storage while suspended.
- **Named snapshots** ("workspace-level") outlive the source sandbox and can be restored or forked later; **fork** = branch a snapshot into new parallel sandboxes.
- **Three-tier storage taxonomy** (docs decision table): sandbox filesystem (in-memory, fastest, survives standby/resume but not deletion, ~half of RAM capacity, not replicated) → **Volumes** (durable block storage surviving sandbox deletion; single-writer lineage, e.g. databases; mounts at creation, re-attach costs a few-hundred-ms cold boot) → **Agent Drive** (shared distributed POSIX+S3 filesystem, multiple sandboxes read/write concurrently, attach/detach on running sandboxes at any path with fine-grained permissions; free during beta).
- **Agent Runtime** (coming soon): "session-first, fully stateful runtime" — keeps the whole agent session (process memory, filesystem, open work) as one unit that suspends/resumes at ~25ms, supports multi-hour sessions with no 24h timeout, and enables **clean handoffs** (pass a session between agents with full state, no serialization code).

## Agent & Long-Running Features
- Purpose-built for long-lived agent sessions: unlimited standby, hours-long sessions, event-driven automation on file/directory changes, scheduled background commands, human-in-the-loop preview URLs, MCP tool-call-native access.
- Product matrix: Sandboxes (seconds–hours, ~25ms boot-from-standby); Agents Hosting sync (≤100s requests) / async (≤10min); Batch Jobs (minutes–hours, ≤24h, ~30s boot); MCP Servers Hosting (≤10min); plus Model Gateway (LLM routing, token cost control, fallbacks) and observability (logs/traces/metrics) built in.
- Migration guides exist specifically for moving sandbox code off other providers.

## Pricing & Limits
- Usage-based: **$0.0000115 / GB RAM·second** for active sandbox compute (memory-billed; CPU auto-scaled and not billed separately); **$0.20/GB-month** snapshot storage on standby; images $0.045/GB-month. Batch Jobs $0.000006/GB·s; MCP hosting $0.000007/GB·s; Agent Drive free (beta). Up to **$200 free credits**; tier-based quotas to 100,000+ concurrent sandboxes / 512TB storage; enterprise tier up to 256GB RAM per sandbox, BYO compute, private deployments, custom SLAs. Claim: up to 70% cheaper in practice via scale-to-zero.
- Limits/gotchas: external connections die on standby (must reconnect DBs/queues on resume); sandbox fs capacity ≈ half of allocated RAM; archived sandboxes lose memory (processes restart with new PIDs).

## Open-Source & Engineering Notes
- GitHub org **blaxel-ai**: `toolkit` (CLI + Go SDK), `sdk-python`, `sdk-typescript`, `sdk-go`, `blaxel-mcp-server` (Go; manages agents, model APIs, MCP servers, sandboxes, jobs, integrations, users), `sandbox` repo ("Sandbox Hub — collection of dev-environment templates for secure, isolated microVM environments"); marketing says "Blaxel's sandbox API is fully open-source." (Platform core is closed; enterprise private deployment available.)
- Docs (Mintlify, llms.txt at docs.blaxel.ai/llms.txt): /Sandboxes/Overview (lifecycle, standby, archive), /Sandboxes/Fork, /Sandboxes/Archive, /Sandboxes/Proxy*, /Overview (product matrix, storage decision table). Blog: blaxel.ai/blog/blaxel-vs-modal, /blog/understand-the-lifecycle-of-a-blaxel-sandbox, /blog/choose-the-right-storage-for-your-blaxel-agents.
- Relatively little deep engineering detail published about the snapshot mechanism itself (vs Modal's CRIU tell-all) — the 25ms resume implies memory-snapshot restore onto pre-provisioned microVMs with RAM-backed rootfs.

## Lessons for a Rust Implementation
1. **Make standby the default lifecycle, not warm pools.** Auto-suspend after seconds of idle with automatic full-state snapshot; resume in ~25ms; charge only snapshot storage while parked. This collapses the "warm pool vs cold start vs cost" trilemma — it's the most agent-native cold-start answer of the four companies.
2. **Bill by memory-second for active time only** (CPU derived from RAM tier) — a simpler meter than core-seconds and it matches how agents actually behave (idle-heavy, bursty).
3. **RAM-backed root filesystem** doubles as: fast fs, ZDR story ("memory wiped on destroy"), and fast snapshot/restore (no disk sync on suspend). Capacity bound ≈ half of RAM must be documented.
4. **Snapshot taxonomy users understand**: standby snapshot (in-place), named snapshot (outlives source, forkable), archive (filesystem-only, cold restore, cheap). Add per-tier TTL/expiration policies to control storage costs.
5. **MCP everything**: expose every platform resource (including sandbox lifecycle) as MCP tools so *agents* are first-class platform operators — plus a per-sandbox MCP server for exec/files.
6. **Proxy as a security feature**: MITM egress with secrets injection means credentials never enter the sandbox; domain/method/path firewalls and static egress IPs round out the story.
