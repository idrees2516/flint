# Flint API Reference

All routes require `Authorization: Bearer <api-key>` (or `x-api-key`).
Base URL: `http://<gateway>:8080`. gRPC: `<gateway>:7473` (services
`flint.api.v1.{Sandbox,Exec,File,Tool,Template}Service`, plus the internal
`flint.fleet.v1` spoken by workers).

Error shape (all surfaces):

```json
{"error": {"code": "not_found", "message": "resource not found: sandbox sbx_..."}}
```

Codes → HTTP: `not_found` 404, `invalid_state` 409, `invalid_param` 400,
`unauthenticated` 401, `forbidden` 403, `rate_limited` 429,
`quota_exceeded` 429, `resource_exhausted` 503, `timeout` 504,
`conflict` 409, `unavailable` 503, `internal` 500.

## Sandboxes

| Method | Path | Body / Notes |
|---|---|---|
| POST | `/v1/sandboxes` | `{template_id?, project?, vm{vcpu_count,mem_mib,disk_mib}, env{}, metadata{}, timeouts{...}}` → sandbox JSON |
| GET | `/v1/sandboxes?state=&limit=` | list |
| GET | `/v1/sandboxes/{id}` | get |
| DELETE | `/v1/sandboxes/{id}` | delete (stops worker side, marks deleted) |
| POST | `/v1/sandboxes/{id}/pause` | memory-preserving snapshot (prod) + layers upload |
| POST | `/v1/sandboxes/{id}/resume` | restore + WAL replay |
| POST | `/v1/sandboxes/{id}/stop` | disk-preserving stop |
| POST | `/v1/sandboxes/{id}/start` | restart from stopped |
| POST | `/v1/sandboxes/{id}/snapshot` | explicit snapshot → `{snapshot_id}` |
| POST | `/v1/sandboxes/{id}/fork` | `{count: 1..16, keep_paused?}` → `{forks[], snapshot_id}` |
| POST | `/v1/sandboxes/{id}/keepalive` | bump idle timer |
| PATCH | `/v1/sandboxes/{id}/timeouts` | full `TimeoutPolicy` object |

`TimeoutPolicy`:

```json
{
  "auto_pause_after_idle_ms": 900000,
  "auto_stop_after_idle_ms": null,
  "max_ttl_ms": 86400000,
  "expiry_action": "pause",      // pause | stop | delete
  "wake_on_request": true
}
```

## Exec + processes

| Method | Path | Body |
|---|---|---|
| POST | `/v1/sandboxes/{id}/exec` | `{spec: {cmd: ["sh","-c","..."], env{}, cwd?, timeout_ms?, pty?{cols,rows}, user?, restartable?}}` → `{exit_code, stdout, stderr, timed_out}` |
| POST | `/v1/sandboxes/{id}/exec/stream` | same spec; response is SSE (`data: {...}` events: `stdout`, `stderr`, `exit`) |
| POST | `/v1/sandboxes/{id}/processes` | `{cmd:[], env{}, cwd?, user?, restartable}` → `{proc_id}` |
| GET | `/v1/sandboxes/{id}/processes` | list w/ status + exit codes |
| POST | `/v1/sandboxes/{id}/processes/{proc}/input` | `{data_b64, close_stdin?}` |
| POST | `/v1/sandboxes/{id}/processes/{proc}/signal` | `{signal: 15}` |
| POST | `/v1/sandboxes/{id}/processes/{proc}/wait?timeout_ms=` | `{status, exit_code}` |
| DELETE | `/v1/sandboxes/{id}/processes/{proc}` | kill (process group) |

`restartable: true` processes are recorded in the WAL and **re-spawned
from their specs after crash recovery** (process memory is never restored —
Journal+FS tier).

## Files

| Method | Path | Notes |
|---|---|---|
| GET | `/v1/sandboxes/{id}/files?path=/a/b.txt&raw=1` | raw bytes or `{content_b64, size_b, mode}` |
| PUT | `/v1/sandboxes/{id}/files?path=/a/b.txt&mode=0644` | body = raw bytes (journaled, replayable) |
| GET | `/v1/sandboxes/{id}/files/list?path=/` | entries |
| GET | `/v1/sandboxes/{id}/files/stat?path=` | `{exists, is_dir, size_b, mode, mtime_ms}` |
| POST | `/v1/sandboxes/{id}/files/mkdir` | `{path, recursive}` |
| POST | `/v1/sandboxes/{id}/files/move` | `{from, to}` |
| POST | `/v1/sandboxes/{id}/files/remove` | `{path, recursive}` |

Paths are sandbox-absolute (`/...`). Escapes (`..` out of root) are
rejected on both sides (agent + host replay).

## Streaming surfaces

- **Terminal**: `GET /v1/sandboxes/{id}/terminal?cols=80&rows=24&cmd=bash`
  → WebSocket. Server→client: binary frames = PTY output; text frames =
  JSON control (`{"type":"closed"}`). Client→server: binary = input;
  text = `{"type":"resize","cols":N,"rows":N}` / `{"type":"close"}`.
- **Events**: `GET /v1/sandboxes/{id}/events` → WebSocket of
  `{"type":"state","state":"paused"}`-style events.
- **Preview proxy**: `GET /v1/sandboxes/{id}/preview/{port}/{path}` —
  proxies HTTP into the sandbox through the agent's port tunnel.

## Templates + tools + usage

| Method | Path | Notes |
|---|---|---|
| GET | `/v1/templates` | list |
| POST | `/v1/templates/from-sandbox/{id}` | `{name}` — snapshot → reusable template base |
| POST | `/v1/tools/web_search` | `{query, num<=20}` → results (provider: ddg/brave/tavily) |
| POST | `/v1/tools/http_fetch` | `{url}` → `{status, content_type, body_b64}` (SSRF-guarded) |
| GET | `/v1/usage` | per-key counters |
| GET | `/v1/keys` · POST `/v1/keys` | key management (`{name}`) |
| GET | `/metrics` | Prometheus text |
| GET | `/healthz`, `/readyz` | liveness |

## gRPC

`proto/api.proto` mirrors the REST surface with typed messages
(`SandboxService`, `ExecService` (streaming `RunExec`), `FileService`,
`ToolService`, `TemplateService`). Auth via `x-api-key` metadata.
`proto/fleet.proto` is the worker↔gateway protocol: `FleetService`
(register + heartbeats), `FleetReport` (state reports, restore info) and
`WorkerService` (lifecycle RPCs + the bidirectional `Operate` op pipe that
carries every agent operation as JSON envelopes).
