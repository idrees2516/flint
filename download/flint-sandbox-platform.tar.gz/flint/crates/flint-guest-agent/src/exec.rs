//! Exec engine: spawn, stream, supervise, kill — with optional PTY.

use flint_core::agent_proto::events;
use flint_core::{ExecSpec, PtySize};
use nix::sys::signal::{kill, killpg, Signal};
use nix::unistd::Pid;
use serde_json::json;
use std::collections::HashMap;
use std::os::fd::{AsRawFd, FromRawFd};
use std::process::Stdio;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use tokio::io::AsyncReadExt;
use tokio::process::{Child, Command};
use tokio::sync::mpsc;

static PROC_COUNTER: AtomicU64 = AtomicU64::new(1);

pub fn next_proc_id() -> String {
    format!("prc_{:08x}", PROC_COUNTER.fetch_add(1, Ordering::Relaxed))
}

#[derive(Debug, Clone, PartialEq, serde::Serialize)]
#[serde(rename_all = "snake_case")]
#[allow(dead_code)]
pub enum ProcStatus {
    Running,
    Exited,
    Failed,
}

#[derive(Clone)]
pub struct ProcHandle {
    pub proc_id: String,
    pub spec: ExecSpec,
    pub pid: Option<i32>,
    pub started_at_ms: i64,
    pub status: Arc<Mutex<ProcStatus>>,
    pub exit_code: Arc<Mutex<Option<i32>>>,
    pub stdin_tx: Option<mpsc::Sender<Vec<u8>>>,
}

#[derive(Default)]
pub struct ProcTable {
    procs: Mutex<HashMap<String, ProcHandle>>,
}

impl ProcTable {
    pub fn insert(&self, h: ProcHandle) {
        self.procs.lock().unwrap().insert(h.proc_id.clone(), h);
    }

    pub fn get(&self, id: &str) -> Option<ProcHandle> {
        self.procs.lock().unwrap().get(id).cloned()
    }

    pub fn remove(&self, id: &str) {
        self.procs.lock().unwrap().remove(id);
    }

    pub fn list(&self) -> Vec<ProcHandle> {
        self.procs.lock().unwrap().values().cloned().collect()
    }

    pub fn kill(&self, id: &str, signal: i32) -> bool {
        let Some(p) = self.get(id) else { return false };
        if let Some(pid) = p.pid {
            let sig = signal_from_int(signal);
            // Prefer the process group (spawns use process_group(0)).
            let _ = killpg(Pid::from_raw(-pid), sig);
            let _ = kill(Pid::from_raw(pid), sig);
            true
        } else {
            false
        }
    }
}

pub fn signal_from_int(s: i32) -> Signal {
    match s {
        1 => Signal::SIGHUP,
        2 => Signal::SIGINT,
        3 => Signal::SIGQUIT,
        6 => Signal::SIGABRT,
        9 => Signal::SIGKILL,
        15 => Signal::SIGTERM,
        19 => Signal::SIGSTOP,
        28 => Signal::SIGWINCH,
        _ => Signal::SIGTERM,
    }
}

/// Build the spawn command. `home` resolves sandbox-absolute cwds.
pub fn build_command(spec: &ExecSpec, env_overlay: &HashMap<String, String>, home: &std::path::Path) -> Result<(Command, Option<i32>), String> {
    if spec.cmd.is_empty() {
        return Err("cmd must not be empty".into());
    }
    let mut cmd = Command::new(&spec.cmd[0]);
    cmd.args(&spec.cmd[1..]);
    cmd.env_clear();
    // Minimal base env + overlay + spec env.
    cmd.env("PATH", std::env::var("PATH").unwrap_or_else(|_| "/usr/local/bin:/usr/bin:/bin".into()));
    cmd.env("HOME", home.display().to_string());
    if let Ok(lang) = std::env::var("LANG") {
        cmd.env("LANG", lang);
    }
    for (k, v) in env_overlay {
        cmd.env(k, v);
    }
    for (k, v) in &spec.env {
        cmd.env(k, v);
    }
    if let Some(cwd) = &spec.cwd {
        let resolved = flint_journal::ops::safe_join(home, cwd).map_err(|e| e.to_string())?;
        cmd.current_dir(resolved);
    }
    // Own process group so we can kill the whole tree.
    #[cfg(unix)]
    cmd.process_group(0);
    Ok((cmd, None))
}

/// Spawn a non-PTY process with piped stdio. Returns the handle plus the
/// raw child for the runner to drive.
pub fn spawn_pipes(
    spec: &ExecSpec,
    env_overlay: &HashMap<String, String>,
    home: &std::path::Path,
) -> Result<(Command, Child), String> {
    let (mut cmd, _) = build_command(spec, env_overlay, home)?;
    cmd.stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .kill_on_drop(false);
    let child = cmd.spawn().map_err(|e| format!("spawn {}: {e}", spec.cmd[0]))?;
    Ok((cmd, child))
}

/// Spawn a PTY-backed process. Returns (command-config, master fd, slave
/// fd, child). The caller owns the fds for I/O.
pub fn spawn_pty(
    spec: &ExecSpec,
    env_overlay: &HashMap<String, String>,
    home: &std::path::Path,
    size: &PtySize,
) -> Result<(Child, std::os::fd::OwnedFd, std::os::fd::OwnedFd), String> {
    use nix::pty::openpty;
    use nix::sys::termios::{tcgetattr, tcsetattr, SetArg};
    let winsize = nix::pty::Winsize {
        ws_row: size.rows,
        ws_col: size.cols,
        ws_xpixel: 0,
        ws_ypixel: 0,
    };
    let pty = openpty(Some(&winsize), None).map_err(|e| format!("openpty: {e}"))?;
    let (master, slave) = (pty.master, pty.slave);

    let (mut cmd, _) = build_command(spec, env_overlay, home)?;
    let slave_fd = slave.as_raw_fd();
    let slave_out = nix::unistd::dup(slave_fd).map_err(|e| format!("dup: {e}"))?;
    let slave_err = nix::unistd::dup(slave_fd).map_err(|e| format!("dup: {e}"))?;
    unsafe {
        cmd.stdin(std::process::Stdio::from_raw_fd(slave_fd));
        cmd.stdout(std::process::Stdio::from_raw_fd(slave_out));
        cmd.stderr(std::process::Stdio::from_raw_fd(slave_err));
        // New session + slave as controlling terminal (TIOCSCTTY).
        cmd.pre_exec(move || {
            nix::unistd::setsid()?;
            if libc::ioctl(slave_fd, 0x540E as libc::c_ulong, 0 as libc::c_int) < 0 {
                // Non-fatal on kernels that set it implicitly.
            }
            Ok(())
        });
    }

    // Raw-ish mode on master for pass-through (ICANON/ECHO are local
    // flags — c_lflag — not input flags).
    if let Ok(mut tio) = tcgetattr(&master) {
        tio.local_flags.remove(nix::sys::termios::LocalFlags::ICANON | nix::sys::termios::LocalFlags::ECHO);
        let _ = tcsetattr(&master, SetArg::TCSANOW, &tio);
    }

    cmd.kill_on_drop(false);
    let child = cmd.spawn().map_err(|e| format!("pty spawn: {e}"))?;
    Ok((child, master, slave))
}

/// Pump a reader end into `stdout`/`stderr` event frames.
pub async fn pump_reader<R: tokio::io::AsyncRead + Unpin + Send + 'static>(
    mut r: R,
    stream_id: u64,
    kind: &'static str,
    out: mpsc::Sender<flint_core::agent_proto::WireMsg>,
    max_total: usize,
) {
    let mut buf = [0u8; 8192];
    let mut total = 0usize;
    loop {
        match r.read(&mut buf).await {
            Ok(0) | Err(_) => break,
            Ok(n) => {
                if total < max_total {
                    let take = n.min(max_total - total);
                    let _ = out
                        .send(flint_core::agent_proto::WireMsg::Ev {
                            id: stream_id,
                            seq: 0,
                            kind: kind.into(),
                            data: json!({ "data_b64": flint_core::util::b64_encode(&buf[..take]) }),
                        })
                        .await;
                    total += take;
                }
            }
        }
    }
}


/// Kill a whole process group by pid.
#[allow(dead_code)]
pub fn kill_tree(pid: i32, sig: Signal) {
    let _ = killpg(Pid::from_raw(-pid), sig);
    let _ = kill(Pid::from_raw(pid), sig);
}

pub fn exit_event(stream_id: u64, code: i32, signal: Option<i32>, timed_out: bool) -> flint_core::agent_proto::WireMsg {
    flint_core::agent_proto::WireMsg::Ev {
        id: stream_id,
        seq: 0,
        kind: events::EXIT.into(),
        data: json!({ "exit_code": code, "signal": signal, "timed_out": timed_out }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;
    use tokio::io::AsyncBufReadExt as _;

    #[tokio::test]
    async fn spawns_and_reaps() {
        let tmp = tempfile::tempdir().unwrap();
        let spec = ExecSpec::shell("echo hello");
        let (_cmd, mut child) = spawn_pipes(&spec, &HashMap::new(), tmp.path()).unwrap();
        let out = child.stdout.take().unwrap();
        let mut buf = String::new();
        let mut r = tokio::io::BufReader::new(out);
        use tokio::io::AsyncBufReadExt;
        r.read_line(&mut buf).await.unwrap();
        assert_eq!(buf.trim(), "hello");
        let status = child.wait().await.unwrap();
        assert!(status.success());
    }

    #[tokio::test]
    async fn env_overlay_applied() {
        let tmp = tempfile::tempdir().unwrap();
        let spec = ExecSpec::shell("echo $FLINT_TEST_VAR");
        let mut overlay = HashMap::new();
        overlay.insert("FLINT_TEST_VAR".to_string(), "overlay-works".to_string());
        let (_cmd, mut child) = spawn_pipes(&spec, &overlay, tmp.path()).unwrap();
        let out = child.stdout.take().unwrap();
        let mut buf = String::new();
        let mut r = tokio::io::BufReader::new(out);
        r.read_line(&mut buf).await.unwrap();
        assert_eq!(buf.trim(), "overlay-works");
        child.wait().await.unwrap();
    }

    #[tokio::test]
    async fn missing_binary_is_an_error() {
        let tmp = tempfile::tempdir().unwrap();
        let spec = ExecSpec {
            cmd: vec!["/nonexistent/binary".into()],
            ..ExecSpec::shell("true")
        };
        assert!(spawn_pipes(&spec, &HashMap::new(), tmp.path()).is_err());
    }
}
