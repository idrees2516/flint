/**
 * Flint TypeScript example (fetch-based, zero SDK needed).
 *
 *   FLINT_URL=http://127.0.0.1:8080 FLINT_API_KEY=... npx tsx flint_agent.ts
 */
const BASE = process.env.FLINT_URL ?? "http://127.0.0.1:8080";
const KEY = process.env.FLINT_API_KEY!;

async function call(method: string, path: string, body?: unknown, raw?: Uint8Array) {
  const resp = await fetch(BASE + path, {
    method,
    headers: {
      Authorization: `Bearer ${KEY}`,
      ...(raw ? { "Content-Type": "application/octet-stream" } : { "Content-Type": "application/json" }),
    },
    body: raw ? raw : body ? JSON.stringify(body) : undefined,
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`);
  return resp.json();
}

async function main() {
  const sbx = await call("POST", "/v1/sandboxes", { vm: { vcpu_count: 2, mem_mib: 2048 } });
  const id: string = sbx.id;
  console.log("sandbox:", id);
  try {
    // Write + run AI-generated code.
    const src = new TextEncoder().encode(
      "const names = ['ada', 'grace', 'linus'];\nconsole.log(names.map(n => n.toUpperCase()).join(','));\n",
    );
    await call("PUT", `/v1/sandboxes/${id}/files?path=/app/main.mjs`, undefined, src);

    const run = await call("POST", `/v1/sandboxes/${id}/exec`, {
      spec: { cmd: ["node", "/app/main.mjs"], timeout_ms: 30000 },
    });
    console.log(run.stdout.trim());

    // Long-lived background process with logs.
    const proc = await call("POST", `/v1/sandboxes/${id}/processes`, {
      cmd: ["sh", "-c", "for i in $(seq 1 100); do echo tick-$i; sleep 1; done > /app/ticks.log"],
    });
    console.log("spawned:", proc.proc_id);
    await new Promise((r) => setTimeout(r, 2500));
    const peek = await call("POST", `/v1/sandboxes/${id}/exec`, {
      spec: { cmd: ["sh", "-c", "cat /app/ticks.log"], timeout_ms: 10000 },
    });
    console.log(peek.stdout.trim());
    await call("DELETE", `/v1/sandboxes/${id}/processes/${proc.proc_id}`);
  } finally {
    await call("DELETE", `/v1/sandboxes/${id}`);
    console.log("cleaned up");
  }
}

main();
