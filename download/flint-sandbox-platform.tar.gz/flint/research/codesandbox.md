# CodeSandbox (codesandbox.io) — microVM fleet for AI, now part of Together AI

## Overview
CodeSandbox began as "sandboxes you share as links" and matured into a Cloud Development Environment (CDE) platform: every sandbox/branch gets its own Firecracker microVM, with an SDK (`@codesandbox/sdk`) to spawn those VMs programmatically for AI agents, code interpretation, CI and education. Landing page (as of late 2026): "Our microVM infrastructure allows us to spin up entire VMs, clone them and restore snapshots within 2 seconds." **Acquired by Together AI (Dec 2024)** — the infra now powers Together's "Code Sandbox" (custom deployments of VM sandboxes, $0.0446/vCPU-hr + per-GiB RAM on together.ai/pricing) and its built-in code interpreter. Heritage: the fully in-browser open-source stack (Sandpack bundler, Nodebox) before the microVM pivot.

## Isolation & Architecture
- **Firecracker microVM per sandbox** ("Sandboxes are isolated virtual machines (powered by Firecracker)"), ~300ms fresh boot.
- Their signature engineering (blog: *How we clone a running VM in 2 seconds*, Sep 2022, dev.to mirror):
  - Firecracker `create_snapshot` → `snapshot.snap` + `memory.snap` (raw guest RAM, ~1 GB/GB). Naively ~1s/GB to write *and* to copy.
  - Optimization 1: **`mmap` the memory file `MAP_SHARED`** so the kernel writebacks dirty pages continuously → snapshot saves drop from **8–12s to 30–100ms**.
  - Optimization 2: **copy-on-write clones** of memory *and* disk via **Ceph RBD snapshots** → clone copy ~50–800ms, whole fork **< 2s** (published benchmark average **921ms** — cited in Vercel's own KB comparison). Earlier prototypes used **userfaultfd** so children read memory directly from the parent's file (HN 43622514).
  - Resume faults in only ~300–400 MB (mmap-backed demand paging).
- Fleet orchestration: **Nomad** scheduling with **Ceph RBD** as the snapshotting block layer and a custom **CSI driver**; disks are xfs (fragmentation called out as a hard problem, along with clone network/IP duplication and Dockerfile→rootfs conversion). Their architecture is documented in the open **github.com/CodeSandbox/docs** repo.

## API Surface
`@codesandbox/sdk` (TypeScript): `sandboxes.create({ id, vmTier, hibernationTimeoutSeconds, wakeupConfig })`, `.get/.list/.hibernate/.resume/.delete/.update`; after `sandbox.connect()`: `client.commands.run()` (one-shot), `client.terminals` (interactive shell: create/open/run/kill + `onOutput`, xterm + local-echo friendly), `client.fs` (read/write/move, streaming uploads), `client.tasks` (declarative named tasks with `waitForPort()`, status RUNNING/FINISHED/ERROR/KILLED/RESTARTING/IDLE), `client.interpreters` (JS/Python returning last expression), `client.ports` (auto-exposed `https://<sandbox-id>-<port>.csb.app`), `client.hosts` (signed URL/header/cookie tokens), sessions with per-session env+cwd, and **live tier changes without reboot** (`VMTier.fromSpecs({cpu, memGiB})`, `sandbox.updateTier`).

## Persistence & Lifecycle
Three-tier hibernation ladder: **Memory+Disk** (resume 0.5–2s), **Disk-only** (5–20s, re-runs setup tasks), **Archived** to cold storage (20–60s). Hibernated VMs live on disk up to 7 days before archiving. Sandboxes auto-wake when a port/preview URL is hit. **Templates are pre-baked hibernated golden VMs** (deps and dev servers pre-started) — forking one is a 1–3s "fast fork" vs 20–60s from an archived parent. Git-native: workspace versioned per branch; "a unique database for every PR" is a flagship use case.

## Agent-Specific Features
"One sandbox per agent" documented; fast forks enable cheap parallel agent branches/best-of-N; terminals + tasks + ports power agent UIs and live previews; Together's Code Interpreter is the flagship consumer; editor-side "Boxy" AI agent.

## Pricing & Limits
VM credits at **$0.01486/credit**, billed per minute (rounded up): Pico (2c/1GB) **$0.0743/hr** → XLarge (64c/128GB) $4.7552/hr; recommended Nano (2c/4GB) $0.1486/hr. Free tier: ~400 monthly credits (apis.io profile); Build plans ~10 concurrent VMs, Scale ~250, Enterprise custom. Default storage 20 GB. Together AI's hosted Code Sandbox: **$0.0446/vCPU-hr** + per-GiB RAM.

## Open-Source & Engineering Notes (URLs)
- github.com/CodeSandbox/firecracker (their Firecracker fork), **/ceph-rbd** (Rust Ceph RBD bindings — the CoW snapshot layer), **/userfaultfd-rs** (Rust userfaultfd bindings), /cloud-storage-rs, /sandpack (~13k stars, in-browser bundler), /nodebox, /dependency-packager, /devcontainer-images, and the open **/docs** repo describing the microVM fleet.
- Blog: codesandbox.io/blog/how-we-clone-a-running-vm-in-2-seconds (mirror: dev.to/codesandboxio/...) — credits Firecracker and Fly.io teams. HN: 43622514 (2025 revisit), 32683834.
- Third-party: vercel.com/kb/guide/vercel-sandbox-vs-codesandbox (adverse benchmark: 921ms average clone); modal.com/blog/top-code-agent-sandbox-products.

## Lessons for a Rust implementation
1. **MAP_SHARED mmap of guest memory makes snapshotting nearly free** — schedule writeback continuously, flush only deltas at snapshot time. The single highest-leverage trick in this survey, and directly implementable in Rust over Firecracker's memory files.
2. **CoW fork of memory + disk turns VMs into cheap immutable objects** — via a block layer (Ceph RBD today; alternatives: dm-thin/ZFS/btrfs reflinks). Fork becomes O(dirty data), enabling per-PR/per-agent branching.
3. **Templates = hibernated golden VMs** (deps *and* running dev servers pre-warmed) — strictly better UX than image+boot.
4. **Rust is the native language of this stack**: Firecracker itself plus ceph-rbd/userfaultfd bindings — a Rust platform can link all three directly.
5. **Tiered hibernation with explicit resume-time budgets** (mem+disk / disk / archived) is easy for users to reason about and maps cleanly onto storage cost.
