//! REST API + WebSocket routes (axum).

use crate::ops::Gateway;
use crate::worker_rpc::OpPipe;
use axum::extract::ws::{Message, WebSocket, WebSocketUpgrade};
use axum::extract::{Path, Query, State};
use axum::http::HeaderMap;
use axum::response::{IntoResponse, Response};
use axum::routing::{delete, get, patch, post};
use axum::{Json, Router};
use flint_core::{ExecSpec, FlintError, Result, SandboxCreateSpec, SandboxState, TimeoutPolicy};
use flint_proto::fleet::OpEnvelope;
use serde::Deserialize;
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::Arc;

pub fn router(gw: Arc<Gateway>) -> Router {
    Router::new()
        .route("/healthz", get(|| async { "ok" }))
        .route("/readyz", get(|| async { "ok" }))
        .route("/metrics", get(metrics))
        .route("/v1/keys", post(create_key).get(list_keys))
        .route("/v1/sandboxes", post(create_sandbox).get(list_sandboxes))
        .route("/v1/sandboxes/{id}", get(get_sandbox).delete(delete_sandbox))
        .route("/v1/sandboxes/{id}/pause", post(pause))
        .route("/v1/sandboxes/{id}/resume", post(resume))
        .route("/v1/sandboxes/{id}/stop", post(stop))
        .route("/v1/sandboxes/{id}/start", post(start))
        .route("/v1/sandboxes/{id}/snapshot", post(snapshot))
        .route("/v1/sandboxes/{id}/fork", post(fork))
        .route("/v1/sandboxes/{id}/keepalive", post(keepalive))
        .route("/v1/sandboxes/{id}/timeouts", patch(patch_timeouts))
        .route("/v1/sandboxes/{id}/exec", post(exec))
        .route("/v1/sandboxes/{id}/processes", post(spawn_process).get(list_processes))
        .route("/v1/sandboxes/{id}/processes/{proc_id}/input", post(process_input))
        .route("/v1/sandboxes/{id}/processes/{proc_id}/signal", post(process_signal))
        .route("/v1/sandboxes/{id}/processes/{proc_id}/wait", post(process_wait))
        .route("/v1/sandboxes/{id}/processes/{proc_id}", delete(kill_process))
        .route("/v1/sandboxes/{id}/files", get(read_file).put(write_file))
        .route("/v1/sandboxes/{id}/files/list", get(list_files))
        .route("/v1/sandboxes/{id}/files/stat", get(stat_file))
        .route("/v1/sandboxes/{id}/files/mkdir", post(mkdir))
        .route("/v1/sandboxes/{id}/files/move", post(move_file))
        .route("/v1/sandboxes/{id}/files/remove", post(remove_file))
        .route("/v1/sandboxes/{id}/terminal", get(ws_terminal))
        .route("/v1/sandboxes/{id}/events", get(ws_events))
        .route("/v1/sandboxes/{id}/exec/stream", post(exec_stream_http))
        .route("/v1/sandboxes/{id}/preview/{port}/{*rest}", get(preview))
        .route("/v1/templates", get(list_templates))
        .route("/v1/templates/from-sandbox/{id}", post(create_template))
        .route("/v1/tools/web_search", post(web_search))
        .route("/v1/tools/http_fetch", post(http_fetch))
        .route("/v1/usage", get(usage))
        .with_state(gw)
}

fn err(e: &FlintError) -> Response {
    crate::auth::error_response(e)
}

async fn metrics() -> Response {
    flint_core::metrics::render().into_response()
}

#[derive(Deserialize)]
struct CreateKeyReq {
    name: Option<String>,
}

async fn create_key(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Json(body): Json<CreateKeyReq>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let (key_id, secret) = match gw.create_key(body.name.as_deref().unwrap_or("unnamed")) {
        Ok(v) => v,
        Err(e) => return err(&e),
    };
    let _ = key;
    Json(json!({ "key_id": key_id, "secret": secret, "note": "store the secret now — it is shown once" })).into_response()
}

async fn list_keys(State(gw): State<Arc<Gateway>>, headers: HeaderMap) -> Response {
    match gw.auth.authenticate(&headers) {
        Ok(_) => {}
        Err(e) => return err(&e),
    }
    let keys: Vec<Value> = gw
        .store
        .list_api_keys()
        .map(|ks| {
            ks.into_iter()
                .map(|k| json!({ "key_id": k.key_id, "name": k.name, "created_at": flint_core::util::iso8601(k.created_at_ms) }))
                .collect()
        })
        .map_err(|e| e)
        .unwrap_or_default();
    Json(json!({ "keys": keys })).into_response()
}

async fn create_sandbox(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    body: Option<Json<Value>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let spec: SandboxCreateSpec = match body {
        Some(Json(v)) => match serde_json::from_value(v) {
            Ok(s) => s,
            Err(e) => return err(&FlintError::InvalidParam { msg: format!("bad create spec: {e}") }),
        },
        None => SandboxCreateSpec::default(),
    };
    match gw.create_sandbox(&key.key_id, spec).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn list_sandboxes(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Query(q): Query<HashMap<String, String>>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let state = q.get("state").and_then(|s| serde_json::from_value::<SandboxState>(json!(s.clone())).ok());
    let limit = q.get("limit").and_then(|l| l.parse().ok()).unwrap_or(100);
    match gw.list_sandboxes_json(&key.key_id, state, limit) {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn get_sandbox(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.get_sandbox_row(&key.key_id, &id) {
        Ok(row) => match gw.sandbox_json(&row).await {
            v => Json(v).into_response(),
        },
        Err(e) => err(&e),
    }
}

async fn delete_sandbox(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.delete_sandbox(&key.key_id, &id).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

macro_rules! lifecycle_route {
    ($name:ident, $method:ident) => {
        async fn $name(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
            let key = match gw.auth.authenticate(&headers) {
                Ok(k) => k,
                Err(e) => return err(&e),
            };
            match gw.$method(&key.key_id, &id).await {
                Ok(v) => Json(v).into_response(),
                Err(e) => err(&e),
            }
        }
    };
}

lifecycle_route!(pause, pause);
lifecycle_route!(resume, resume);
lifecycle_route!(start, start);
lifecycle_route!(stop, stop);

async fn snapshot(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.snapshot(&key.key_id, &id).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

#[derive(Deserialize, Default)]
struct ForkReq {
    count: Option<u32>,
    keep_paused: Option<bool>,
}

async fn fork(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    body: Option<Json<ForkReq>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let body = body.map(|Json(b)| b).unwrap_or_default();
    match gw.fork(&key.key_id, &id, body.count.unwrap_or(1), body.keep_paused.unwrap_or(false)).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn keepalive(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.keepalive(&key.key_id, &id).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn patch_timeouts(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<TimeoutPolicy>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.set_timeouts(&key.key_id, &id, &body).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

// ----- exec + processes -----

async fn exec(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(mut body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let timeout_ms = body
        .get("timeout_ms")
        .and_then(|t| t.as_u64())
        .unwrap_or(gw.cfg.limits.max_exec_timeout_ms)
        .min(gw.cfg.limits.max_exec_timeout_ms);
    if let Some(spec) = body.get_mut("spec") {
        spec["timeout_ms"] = json!(timeout_ms);
    } else {
        body["spec"] = json!({});
        if let Some(cmd) = body.get("cmd").cloned() {
            body["spec"]["cmd"] = cmd;
        }
        body["spec"]["timeout_ms"] = json!(timeout_ms);
    }
    let spec: ExecSpec = match serde_json::from_value(body["spec"].clone()) {
        Ok(s) => s,
        Err(e) => return err(&FlintError::InvalidParam { msg: format!("bad exec spec: {e}") }),
    };
    match gw.exec(&key.key_id, &id, &spec).await {
        Ok(mut v) => {
            // Decode base64 payloads for convenience.
            if let Some(b) = v.get("stdout_b64").and_then(|s| s.as_str()) {
                if let Ok(bytes) = flint_core::util::b64_decode(b) {
                    v["stdout"] = json!(String::from_utf8_lossy(&bytes).into_owned());
                }
            }
            if let Some(b) = v.get("stderr_b64").and_then(|s| s.as_str()) {
                if let Ok(bytes) = flint_core::util::b64_decode(b) {
                    v["stderr"] = json!(String::from_utf8_lossy(&bytes).into_owned());
                }
            }
            Json(v).into_response()
        }
        Err(e) => err(&e),
    }
}

async fn spawn_process(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
    let payload = json!({ "spec": body, "op_id": op_id });
    match gw.op(&key.key_id, &id, "process.spawn", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn list_processes(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(id): Path<String>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.op(&key.key_id, &id, "process.list", &json!({})).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

#[derive(Deserialize)]
struct ProcIdPath {
    id: String,
    proc_id: String,
}

async fn process_input(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(p): Path<ProcIdPath>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let payload = json!({
        "proc_id": p.proc_id,
        "data_b64": body.get("data_b64").cloned().unwrap_or(json!("")),
        "close_stdin": body.get("close_stdin").and_then(|v| v.as_bool()).unwrap_or(false),
    });
    match gw.op(&key.key_id, &p.id, "process.input", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn process_signal(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(p): Path<ProcIdPath>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let payload = json!({ "proc_id": p.proc_id, "signal": body.get("signal").and_then(|v| v.as_i64()).unwrap_or(15) });
    match gw.op(&key.key_id, &p.id, "process.signal", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn process_wait(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(p): Path<ProcIdPath>,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let payload = json!({ "proc_id": p.proc_id, "timeout_ms": q.get("timeout_ms").and_then(|v| v.parse().ok()).unwrap_or(30_000) });
    match gw.op(&key.key_id, &p.id, "process.wait", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn kill_process(State(gw): State<Arc<Gateway>>, headers: HeaderMap, Path(p): Path<ProcIdPath>) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.op(&key.key_id, &p.id, "process.kill", &json!({ "proc_id": p.proc_id })).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

// ----- files -----

async fn read_file(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let path = match q.get("path") {
        Some(p) => p.clone(),
        None => return err(&FlintError::InvalidParam { msg: "path query param required".into() }),
    };
    match gw.op(&key.key_id, &id, "fs.read", &json!({ "path": path, "max_bytes": 8 * 1024 * 1024 })).await {
        Ok(v) => {
            if q.get("raw").map(|r| r == "1" || r == "true").unwrap_or(false) {
                let b64 = v.get("content_b64").and_then(|b| b.as_str()).unwrap_or("");
                match flint_core::util::b64_decode(b64) {
                    Ok(bytes) => bytes.into_response(),
                    Err(_) => err(&FlintError::Internal("bad payload".into())),
                }
            } else {
                Json(v).into_response()
            }
        }
        Err(e) => err(&e),
    }
}

async fn write_file(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Query(q): Query<HashMap<String, String>>,
    body: axum::body::Bytes,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let path = match q.get("path") {
        Some(p) => p.clone(),
        None => return err(&FlintError::InvalidParam { msg: "path query param required".into() }),
    };
    if body.len() > gw.cfg.limits.max_file_write_bytes {
        return err(&FlintError::InvalidParam {
            msg: format!("file exceeds max_file_write_bytes ({})", gw.cfg.limits.max_file_write_bytes),
        });
    }
    let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
    let payload = json!({
        "path": path,
        "content_b64": flint_core::util::b64_encode(&body),
        "mode": q.get("mode").and_then(|m| m.parse::<u32>().ok()),
        "op_id": op_id,
    });
    match gw.op(&key.key_id, &id, "fs.write", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn list_files(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let path = q.get("path").cloned().unwrap_or_else(|| "/".into());
    match gw.op(&key.key_id, &id, "fs.list", &json!({ "path": path })).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn stat_file(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let path = q.get("path").cloned().unwrap_or_else(|| "/".into());
    match gw.op(&key.key_id, &id, "fs.stat", &json!({ "path": path })).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn mkdir(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
    let payload = json!({ "path": body.get("path"), "recursive": body.get("recursive").and_then(|v| v.as_bool()).unwrap_or(true), "op_id": op_id });
    match gw.op(&key.key_id, &id, "fs.mkdir", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn move_file(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
    let payload = json!({ "from": body.get("from"), "to": body.get("to"), "op_id": op_id });
    match gw.op(&key.key_id, &id, "fs.move", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn remove_file(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
    let payload = json!({ "path": body.get("path"), "recursive": body.get("recursive").and_then(|v| v.as_bool()).unwrap_or(false), "op_id": op_id });
    match gw.op(&key.key_id, &id, "fs.remove", &payload).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

// ----- templates / tools / usage -----

async fn list_templates(State(gw): State<Arc<Gateway>>, headers: HeaderMap) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.list_templates(&key.key_id) {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

#[derive(Deserialize)]
struct TemplateReq {
    name: Option<String>,
}

async fn create_template(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    body: Option<Json<TemplateReq>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let name = body.map(|Json(b)| b.name).flatten().unwrap_or_else(|| format!("template-from-{id}"));
    match gw.create_template_from(&key.key_id, &id, &name).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn web_search(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let query = body.get("query").and_then(|q| q.as_str()).unwrap_or("");
    let num = body.get("num").and_then(|n| n.as_u64()).unwrap_or(5).min(20) as u32;
    match gw.web_search(&key, query, num).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn http_fetch(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let url = body.get("url").and_then(|u| u.as_str()).unwrap_or("");
    match gw.http_fetch(&key, url).await {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

async fn usage(State(gw): State<Arc<Gateway>>, headers: HeaderMap) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    match gw.usage(&key.key_id) {
        Ok(v) => Json(v).into_response(),
        Err(e) => err(&e),
    }
}

// ----- streaming: exec (SSE-style), preview proxy -----

async fn exec_stream_http(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    Json(body): Json<Value>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let spec: ExecSpec = match serde_json::from_value(body.get("spec").cloned().unwrap_or(body.clone())) {
        Ok(s) => s,
        Err(e) => return err(&FlintError::InvalidParam { msg: format!("bad spec: {e}") }),
    };
    let (_, addr) = match gw.route(&key.key_id, &id).await {
        Ok(v) => v,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id("ex_");
    let mut pipe = match gw.workers.open_pipe(&addr).await {
        Ok(p) => p,
        Err(e) => return err(&e),
    };
    if pipe
        .tx
        .send(OpEnvelope {
            sandbox_id: id.clone(),
            op_id: op_id.clone(),
            kind: "exec.stream".into(),
            payload_json: json!({ "spec": spec, "op_id": op_id }).to_string(),
        })
        .await
        .is_err()
    {
        return err(&FlintError::Unavailable { msg: "pipe closed".into() });
    }
    let stream = async_stream::stream! {
        while let Some(ev) = pipe.events.recv().await {
            if ev.op_id != op_id { continue; }
            let mut obj = json!({ "op_id": ev.op_id, "kind": ev.kind });
            if let Ok(v) = serde_json::from_str::<Value>(&ev.payload_json) {
                obj["data"] = v;
            }
            if !ev.error.is_empty() {
                obj["error"] = json!(ev.error);
            }
            yield Ok::<String, std::convert::Infallible>(format!("data: {obj}\n\n"));
            if ev.r#final { break; }
        }
    };
    let headers = [
        ("content-type", "text/event-stream"),
        ("cache-control", "no-cache"),
    ];
    (
        headers,
        axum::body::Body::from_stream(stream),
    )
        .into_response()
}

#[derive(Deserialize)]
struct PreviewPath {
    id: String,
    port: u16,
    #[serde(default)]
    rest: String,
}

/// HTTP preview proxy into a sandbox: opens a port tunnel through the
/// agent channel and issues the request over it.
async fn preview(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(p): Path<PreviewPath>,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let (_, addr) = match gw.route(&key.key_id, &p.id).await {
        Ok(v) => v,
        Err(e) => return err(&e),
    };
    let pipe: OpPipe = match gw.workers.open_pipe(&addr).await {
        Ok(pipe) => pipe,
        Err(e) => return err(&e),
    };
    let op_id = flint_core::ids::new_id("prt_");
    if pipe
        .tx
        .send(OpEnvelope {
            sandbox_id: p.id.clone(),
            op_id: op_id.clone(),
            kind: "port.connect".into(),
            payload_json: json!({ "port": p.port }).to_string(),
        })
        .await
        .is_err()
    {
        return err(&FlintError::Unavailable { msg: "pipe closed".into() });
    }
    // Wait for the tunnel ack (stream_id) through events.
    let mut stream_id = 0u64;
    let mut tunnel = Tunnel { pipe, op_id: op_id.clone() };
    // Collect the ack.
    let ack = tunnel.recv().await;
    if let Some(ev) = &ack {
        if !ev.error.is_empty() {
            return err(&FlintError::Unavailable { msg: format!("port tunnel: {}", ev.error) });
        }
        if let Ok(v) = serde_json::from_str::<Value>(&ev.payload_json) {
            stream_id = v.get("stream_id").and_then(|s| s.as_u64()).unwrap_or(0);
        }
    }
    // Build and send the HTTP request over the tunnel, then relay the raw
    // response back. The query string is forwarded.
    let mut path = format!("/{}", p.rest);
    if !q.is_empty() {
        let qs: Vec<String> = q.iter().map(|(k, v)| format!("{k}={v}")).collect();
        path.push('?');
        path.push_str(&qs.join("&"));
    }
    if stream_id == 0 {
        return err(&FlintError::Internal("no tunnel stream id".into()));
    }
    let req = flint_core::minhttp::encode_request_for("GET", &path);
    if tunnel
        .pipe
        .tx
        .send(OpEnvelope {
            sandbox_id: p.id.clone(),
            op_id: op_id.clone(),
            kind: "port.data".into(),
            payload_json: json!({ "stream_id": stream_id, "data_b64": flint_core::util::b64_encode(&req) }).to_string(),
        })
        .await
        .is_err()
    {
        return err(&FlintError::Unavailable { msg: "tunnel write failed".into() });
    }
    // Relay raw bytes from tunnel events until close.
    let (body_tx, body_rx) = tokio::sync::mpsc::channel::<Result<axum::body::Bytes>>(64);
    let _ = &stream_id;
    tokio::spawn(async move {
        while let Some(ev) = tunnel.recv().await {
            if let Ok(v) = serde_json::from_str::<Value>(&ev.payload_json) {
                if let Some(b64) = v.get("data_b64").and_then(|b| b.as_str()) {
                    if let Ok(bytes) = flint_core::util::b64_decode(b64) {
                        let _ = body_tx.send(Ok(axum::body::Bytes::from(bytes))).await;
                    }
                }
            }
            if ev.r#final {
                break;
            }
        }
        let _ = stream_id;
    });
    (
        [("content-type", "application/octet-stream")],
        axum::body::Body::from_stream(tokio_stream::wrappers::ReceiverStream::new(body_rx)),
    )
        .into_response()
}

struct Tunnel {
    pipe: OpPipe,
    op_id: String,
}

impl Tunnel {
    async fn recv(&mut self) -> Option<flint_proto::fleet::OpEvent> {
        loop {
            let ev = self.pipe.events.recv().await?;
            if ev.op_id == self.op_id {
                return Some(ev);
            }
        }
    }
}

// ----- websockets -----

async fn ws_terminal(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    ws: WebSocketUpgrade,
    Query(q): Query<HashMap<String, String>>,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    let cols = q.get("cols").and_then(|v| v.parse().ok()).unwrap_or(80);
    let rows = q.get("rows").and_then(|v| v.parse().ok()).unwrap_or(24);
    let cmd = q.get("cmd").cloned();
    let key_id = key.key_id.clone();
    ws.on_upgrade(move |socket| terminal_session(gw, socket, key_id, id, cols, rows, cmd))
}

async fn terminal_session(
    gw: Arc<Gateway>,
    mut socket: WebSocket,
    key_id: String,
    id: String,
    cols: u16,
    rows: u16,
    cmd: Option<String>,
) {
    use futures::{SinkExt, StreamExt};
    let Ok((_, addr)) = gw.route(&key_id, &id).await else {
        let _ = socket.close().await;
        return;
    };
    let Ok(mut pipe) = gw.workers.open_pipe(&addr).await else {
        let _ = socket.close().await;
        return;
    };
    let op_id = flint_core::ids::new_id("trm_");
    let spec = match cmd {
        Some(c) => ExecSpec::shell(c),
        None => ExecSpec::shell("bash -l 2>/dev/null || sh -l"),
    };
    if pipe
        .tx
        .send(OpEnvelope {
            sandbox_id: id.clone(),
            op_id: op_id.clone(),
            kind: "term.open".into(),
            payload_json: json!({ "spec": spec, "size": { "cols": cols, "rows": rows } }).to_string(),
        })
        .await
        .is_err()
    {
        return;
    }
    let (mut ws_tx, mut ws_rx) = socket.split();
    let mut stream_id: Option<u64> = None;
    flint_core::metrics::gauge_add(flint_core::metrics::names::WS_CONNECTIONS, &[("kind", "terminal".into())], 1);

    loop {
        tokio::select! {
            ev = pipe.events.recv() => {
                match ev {
                    Some(ev) if ev.op_id == op_id => {
                        let data: Value = serde_json::from_str(&ev.payload_json).unwrap_or(Value::Null);
                        match ev.kind.as_str() {
                            "term.out" | "stdout" | "stderr" => {
                                if let Some(b64) = data.get("data_b64").and_then(|b| b.as_str()) {
                                    if let Ok(bytes) = flint_core::util::b64_decode(b64) {
                                        if ws_tx.send(Message::Binary(bytes::Bytes::from(bytes))).await.is_err() {
                                            break;
                                        }
                                    }
                                }
                            }
                            "term.open" => {
                                if let Some(sid) = data.get("stream_id").and_then(|s| s.as_u64()) {
                                    stream_id = Some(sid);
                                }
                            }
                            "error" => {
                                let msg = ev.error.clone();
                                let _ = ws_tx.send(Message::Text(json!({ "type": "error", "message": msg }).to_string().into())).await;
                            }
                            _ => {}
                        }
                        if ev.r#final {
                            let _ = ws_tx.send(Message::Text("{\"type\":\"closed\"}".to_string().into())).await;
                            break;
                        }
                    }
                    Some(_) => continue, // other ops on the shared pipe
                    None => break,
                }
            }
            msg = ws_rx.next() => {
                match msg {
                    Some(Ok(Message::Binary(bytes))) => {
                        if let Some(sid) = stream_id {
                            let _ = pipe.tx.send(OpEnvelope {
                                sandbox_id: id.clone(),
                                op_id: op_id.clone(),
                                kind: "term.input".into(),
                                payload_json: json!({ "stream_id": sid, "data_b64": flint_core::util::b64_encode(&bytes) }).to_string(),
                            }).await;
                        }
                    }
                    Some(Ok(Message::Text(t))) => {
                        // JSON control: {"type":"resize","cols":N,"rows":N}
                        if let Ok(v) = serde_json::from_str::<Value>(&t) {
                            match v.get("type").and_then(|t| t.as_str()).unwrap_or("") {
                                "resize" => {
                                    if let Some(sid) = stream_id {
                                        let _ = pipe.tx.send(OpEnvelope {
                                            sandbox_id: id.clone(),
                                            op_id: op_id.clone(),
                                            kind: "term.resize".into(),
                                            payload_json: json!({ "stream_id": sid, "cols": v.get("cols"), "rows": v.get("rows") }).to_string(),
                                        }).await;
                                    }
                                }
                                "close" => break,
                                _ => {}
                            }
                        }
                    }
                    Some(Ok(Message::Ping(_) | Message::Pong(_))) => {}
                    Some(Ok(Message::Close(_))) | None => break,
                    Some(Err(_)) => break,
                }
            }
        }
    }
    flint_core::metrics::gauge_add(flint_core::metrics::names::WS_CONNECTIONS, &[("kind", "terminal".into())], -1);
}

async fn ws_events(
    State(gw): State<Arc<Gateway>>,
    headers: HeaderMap,
    Path(id): Path<String>,
    ws: WebSocketUpgrade,
) -> Response {
    let key = match gw.auth.authenticate(&headers) {
        Ok(k) => k,
        Err(e) => return err(&e),
    };
    // Authorize: the caller must own the sandbox.
    if let Err(e) = gw.get_sandbox_row(&key.key_id, &id) {
        return err(&e);
    }
    ws.on_upgrade(move |socket| async move {
        use futures::{SinkExt, StreamExt};
        let (mut tx, mut rx) = socket.split();
        let mut events = gw.events.subscribe(&id).await;
        loop {
            tokio::select! {
                ev = events.recv() => {
                    match ev {
                        Some(v) => {
                            if tx.send(Message::Text(v.to_string().into())).await.is_err() {
                                break;
                            }
                        }
                        None => break,
                    }
                }
                msg = rx.next() => {
                    if msg.is_none() {
                        break;
                    }
                }
            }
        }
    })
}
