//! Driver contracts: what a sandbox runtime must provide to the worker.

use crate::agent_client::GuestAgentClient;
use flint_core::{DriverKind, Result, VmSpec};
use flint_journal::LayerKind;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Layers staged on the host filesystem after a pause, ready for the
/// worker to hash + upload to the object store.
#[derive(Debug, Clone)]
pub struct StagedLayer {
    pub kind: LayerKind,
    pub path: PathBuf,
}

/// Restored layers (worker downloads these before spawn).
#[derive(Debug, Clone, Default)]
pub struct RestoredLayers {
    /// tar.gz of the sandbox home (ProcessDriver).
    pub fs_tar: Option<PathBuf>,
    /// Raw writable drive file (Firecracker).
    pub drive: Option<PathBuf>,
    /// Firecracker memory file.
    pub memory: Option<PathBuf>,
    /// Firecracker snapfile (device state).
    pub snapfile: Option<PathBuf>,
    /// WAL seq the snapshot is durable through.
    pub wal_seq: u64,
}

/// Request to spawn a sandbox instance.
#[derive(Debug, Clone)]
pub struct SpawnRequest {
    pub sandbox_id: String,
    pub vm: VmSpec,
    pub env: BTreeMap<String, String>,
    pub agent_token: String,
    /// Layers to restore from (None = fresh).
    pub restore: Option<RestoredLayers>,
    /// Network namespace name (Firecracker prod path).
    pub netns: Option<String>,
    /// Firecracker: template base drive to copy-on-write from.
    pub template_drive: Option<PathBuf>,
    /// Firecracker: guest vsock CID (host-managed, >= 3).
    pub cid: Option<u32>,
}

/// A running (or restorable) sandbox runtime handle.
#[async_trait::async_trait]
pub trait VmInstance: Send + Sync {
    fn sandbox_id(&self) -> &str;
    fn kind(&self) -> DriverKind;
    /// Channel to the in-sandbox agent.
    fn agent(&self) -> &Arc<GuestAgentClient>;
    /// Host-visible home dir (ProcessDriver only; None for microVMs).
    fn home_dir(&self) -> Option<&Path>;
    /// Pause: quiesce + stage all durability layers under `staging`.
    /// After this returns the VM is *frozen or dead* — the caller decides
    /// whether to resume, snapshot-upload, or drop.
    async fn pause(&self, staging: &Path) -> Result<Vec<StagedLayer>>;
    /// Resume a paused instance (drivers that can't resume in place
    /// respawn from the staged layers).
    async fn resume(&self) -> Result<()>;
    /// Graceful stop (SIGTERM + SIGKILL escalation for process groups;
    /// FC shutdown for microVMs). Idempotent.
    async fn stop(&self) -> Result<()>;
    /// Liveness (agent ping + process/VM existence).
    async fn is_alive(&self) -> bool;
}

/// A driver spawns sandbox instances.
#[async_trait::async_trait]
pub trait VmDriver: Send + Sync {
    fn kind(&self) -> DriverKind;
    /// Per-node init (mkdirs, CID counters...).
    async fn init(&self) -> Result<()>;
    async fn spawn(&self, req: SpawnRequest) -> Result<Box<dyn VmInstance>>;
    /// Called by the worker before `spawn(restore=...)` — the driver may
    /// transform staged downloads (e.g. CoW-copy a template drive).
    async fn prepare_restore(&self, sandbox_id: &str, layers: &mut RestoredLayers) -> Result<()>;
}

/// Locate the `flint-guest-agent` binary: explicit config → env →
/// next to the current executable → common target dirs → PATH.
pub fn resolve_guest_agent_bin(explicit: Option<&str>) -> Result<PathBuf> {
    if let Some(p) = explicit {
        let pb = PathBuf::from(p);
        if pb.exists() {
            return Ok(pb);
        }
        return Err(flint_core::FlintError::InvalidParam {
            msg: format!("guest agent binary not found at {p}"),
        });
    }
    let candidates: Vec<PathBuf> = {
        let mut v = Vec::new();
        if let Ok(p) = std::env::var("FLINT_GUEST_AGENT_BIN") {
            v.push(PathBuf::from(p));
        }
        if let Ok(exe) = std::env::current_exe() {
            if let Some(dir) = exe.parent() {
                v.push(dir.join("flint-guest-agent"));
            }
        }
        if let Ok(cwd) = std::env::current_dir() {
            v.push(cwd.join("target/debug/flint-guest-agent"));
            v.push(cwd.join("target/release/flint-guest-agent"));
            v.push(cwd.join("../target/debug/flint-guest-agent"));
        }
        v.push(PathBuf::from("/usr/local/bin/flint-guest-agent"));
        v
    };
    for c in candidates {
        if c.exists() {
            return Ok(c);
        }
    }
    // PATH lookup.
    if let Ok(path) = std::env::var("PATH") {
        for dir in path.split(':') {
            let p = PathBuf::from(dir).join("flint-guest-agent");
            if p.exists() {
                return Ok(p);
            }
        }
    }
    Err(flint_core::FlintError::InvalidParam {
        msg: "flint-guest-agent binary not found; set FLINT_GUEST_AGENT_BIN".into(),
    })
}
