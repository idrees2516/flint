//! Guest-side file operations, journal-mirrored and escape-proof.

use crate::journal::GuestJournal;
use flint_journal::ops::{safe_join, Op, OpError};
use serde_json::{json, Value};
use std::os::unix::fs::MetadataExt as _;
use std::path::PathBuf;

pub struct FsCtx {
    pub home: PathBuf,
    pub journal: GuestJournal,
}

impl FsCtx {
    pub fn new(home: PathBuf, journal: GuestJournal) -> Self {
        Self { home, journal }
    }

    fn resolve(&self, path: &str) -> Result<PathBuf, OpError> {
        safe_join(&self.home, path)
    }

    fn journalled(&self, op_id: &str, op: Op) {
        if !op_id.is_empty() {
            self.journal.append(op_id, &op);
        }
    }

    pub fn write(&self, path: &str, content: &[u8], mode: Option<u32>, op_id: &str) -> Result<(), OpError> {
        let target = self.resolve(path)?;
        if let Some(parent) = target.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(&target, content)?;
        if let Some(m) = mode {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(&target, std::fs::Permissions::from_mode(m));
        }
        self.journalled(
            op_id,
            Op::FileWrite {
                path: path.to_string(),
                content_b64: flint_core::util::b64_encode(content),
                mode,
            },
        );
        Ok(())
    }

    pub fn read(&self, path: &str, max_bytes: usize) -> Result<(Vec<u8>, u32), OpError> {
        let target = self.resolve(path)?;
        let meta = std::fs::metadata(&target).map_err(OpError::Io)?;
        use std::os::unix::fs::MetadataExt;
        let mode = meta.mode() & 0o7777;
        let mut f = std::fs::File::open(&target)?;
        let mut buf = vec![0u8; max_bytes];
        let n = read_up_to(&mut f, &mut buf)?;
        buf.truncate(n);
        Ok((buf, mode))
    }

    pub fn list(&self, path: &str) -> Result<Vec<Value>, OpError> {
        let target = self.resolve(path)?;
        let mut out = Vec::new();
        for entry in std::fs::read_dir(&target)? {
            let entry = entry?;
            let meta = entry.metadata()?;
            out.push(json!({
                "name": entry.file_name().to_string_lossy(),
                "path": format!("{}/{}", path.trim_end_matches('/'), entry.file_name().to_string_lossy()),
                "is_dir": meta.is_dir(),
                "size_b": meta.len(),
                "mode": meta.mode() & 0o7777,
                "mtime_ms": (meta.mtime() * 1000) as i64,
            }));
        }
        out.sort_by(|a, b| a["name"].as_str().cmp(&b["name"].as_str()));
        Ok(out)
    }

    pub fn mkdir(&self, path: &str, recursive: bool, op_id: &str) -> Result<(), OpError> {
        let target = self.resolve(path)?;
        if recursive {
            std::fs::create_dir_all(&target)?;
        } else {
            std::fs::create_dir(&target)?;
        }
        self.journalled(op_id, Op::Mkdir { path: path.to_string(), recursive });
        Ok(())
    }

    pub fn remove(&self, path: &str, recursive: bool, op_id: &str) -> Result<(), OpError> {
        let target = self.resolve(path)?;
        if target == self.home {
            return Err(OpError::Escape("/".into()));
        }
        if target.is_dir() {
            if recursive {
                std::fs::remove_dir_all(&target)?;
            } else {
                std::fs::remove_dir(&target)?;
            }
        } else if target.exists() {
            std::fs::remove_file(&target)?;
        }
        self.journalled(op_id, Op::FileRemove { path: path.to_string(), recursive });
        Ok(())
    }

    pub fn mv(&self, from: &str, to: &str, op_id: &str) -> Result<(), OpError> {
        let src = self.resolve(from)?;
        let dst = self.resolve(to)?;
        if let Some(parent) = dst.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::rename(&src, &dst)?;
        self.journalled(op_id, Op::FileMove { from: from.to_string(), to: to.to_string() });
        Ok(())
    }

    pub fn stat(&self, path: &str) -> Result<Value, OpError> {
        let target = self.resolve(path)?;
        match std::fs::metadata(&target) {
            Ok(meta) => {
                use std::os::unix::fs::MetadataExt;
                Ok(json!({
                    "exists": true,
                    "is_dir": meta.is_dir(),
                    "size_b": meta.len(),
                    "mode": meta.mode() & 0o7777,
                    "mtime_ms": (meta.mtime() * 1000) as i64,
                }))
            }
            Err(_) => Ok(json!({ "exists": false })),
        }
    }
}

fn read_up_to(f: &mut std::fs::File, buf: &mut [u8]) -> std::io::Result<usize> {
    use std::io::Read as _;
    let mut total = 0;
    while total < buf.len() {
        let n = f.read(&mut buf[total..])?;
        if n == 0 {
            break;
        }
        total += n;
    }
    Ok(total)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ctx(tmp: &tempfile::TempDir) -> FsCtx {
        FsCtx::new(tmp.path().to_path_buf(), GuestJournal::open(tmp.path()))
    }

    #[test]
    fn write_read_list_remove() {
        let tmp = tempfile::tempdir().unwrap();
        let c = ctx(&tmp);
        c.write("/a/b.txt", b"hello", Some(0o644), "op_1").unwrap();
        let (data, mode) = c.read("/a/b.txt", 1024).unwrap();
        assert_eq!(data, b"hello");
        assert_eq!(mode, 0o644);

        c.mkdir("/dir", true, "op_2").unwrap();
        c.mv("/a/b.txt", "/dir/c.txt", "op_3").unwrap();
        let entries = c.list("/dir").unwrap();
        assert_eq!(entries.len(), 1);
        assert_eq!(entries[0]["name"], "c.txt");

        c.remove("/dir/c.txt", false, "op_4").unwrap();
        assert!(c.stat("/dir/c.txt").unwrap()["exists"].as_bool().unwrap() == false);

        // Journaled ops land in the guest journal.
        let recs = flint_journal::wal::recover_records(c.journal.path()).0;
        assert!(recs.len() >= 3);
    }

    #[test]
    fn escape_blocked() {
        let tmp = tempfile::tempdir().unwrap();
        let c = ctx(&tmp);
        assert!(c.write("../../etc/evil", b"x", None, "").is_err());
        assert!(c.read("/../etc/passwd", 10).is_err());
    }
}
