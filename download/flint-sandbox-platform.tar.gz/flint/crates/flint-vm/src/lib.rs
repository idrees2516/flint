//! flint-vm: the VM layer — driver contracts, guest-agent client, and the
//! two backends (Firecracker microVMs for production, process groups for
//! dev/CI).

pub mod agent_client;
pub mod driver;
pub mod firecracker;
pub mod process;

pub use agent_client::{connect_vsock_uds, GuestAgentClient, StreamMsg};
pub use driver::{
    resolve_guest_agent_bin, RestoredLayers, SpawnRequest, StagedLayer, VmDriver, VmInstance,
};
pub use firecracker::{FcClient, FirecrackerDriver};
pub use process::{ProcessDriver, ProcessInstance};

use flint_core::config::DriverConfig;
use flint_core::Result;
use std::path::PathBuf;
use std::sync::Arc;

/// Build the configured driver.
pub fn build_driver(cfg: &DriverConfig, work_dir: &std::path::Path) -> Result<Arc<dyn VmDriver>> {
    match cfg {
        DriverConfig::Firecracker {
            firecracker_bin,
            jailer_bin,
            kernel_image_path,
            kernel_args: _,
            rootfs_dir,
            vm_dir,
            guest_agent_bin: _,
            cpu_template,
        } => Ok(Arc::new(FirecrackerDriver::new(
            PathBuf::from(firecracker_bin),
            jailer_bin.clone().map(PathBuf::from),
            kernel_image_path.clone(),
            rootfs_dir.clone(),
            vm_dir.clone(),
            cpu_template.clone(),
        ))),
        DriverConfig::Process { guest_agent_bin, sandbox_root } => {
            let root = sandbox_root.clone().unwrap_or_else(|| work_dir.join("sandboxes"));
            Ok(Arc::new(ProcessDriver::new(root, guest_agent_bin.clone())?))
        }
    }
}
