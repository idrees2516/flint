//! Metadata store: SQLite-backed catalog (api keys, sandboxes, templates,
//! snapshots, workers, routing) + an object-store abstraction (local FS
//! and S3-compatible) for snapshot/template blobs.
//!
//! SQLite behind a `Mutex` is deliberate: metadata ops are small and
//! low-rate; the data plane (exec streams, files) never touches this
//! store. Swapping to Postgres later is a one-crate change.

use flint_core::{FlintError, Result, SandboxCreateSpec, SandboxState, TimeoutPolicy, VmSpec};
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::Path;
use std::sync::Mutex;

// ---------------------------------------------------------------------------
// Row types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiKeyRow {
    pub key_id: String,
    pub name: String,
    pub secret_hash: String,
    #[serde(default)]
    pub quotas: KeyQuotas,
    pub created_at_ms: i64,
    pub revoked: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct KeyQuotas {
    pub max_concurrent_sandboxes: i64,
    pub max_req_per_sec: f64,
    pub max_tool_calls_per_day: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SandboxRow {
    pub id: String,
    pub key_id: String,
    pub project: Option<String>,
    pub template_id: Option<String>,
    pub state: String,
    pub vm: VmSpec,
    pub env: BTreeMap<String, String>,
    pub metadata: BTreeMap<String, String>,
    pub timeouts: TimeoutPolicy,
    pub worker_addr: Option<String>,
    pub worker_node_id: Option<String>,
    pub current_snapshot_id: Option<String>,
    pub created_at_ms: i64,
    pub last_activity_ms: i64,
    pub last_pause_ms: Option<i64>,
    pub usage_active_ms: i64,
    pub usage_paused_ms: i64,
    pub tool_calls_today: i64,
    pub tool_calls_day_start_ms: i64,
    pub deleted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemplateRow {
    pub id: String,
    pub name: String,
    pub key_id: String,
    /// Object-store key prefix of the snapshot stack.
    pub base_snapshot_id: String,
    pub vm: VmSpec,
    pub env: BTreeMap<String, String>,
    pub metadata: BTreeMap<String, String>,
    pub size_b: u64,
    pub created_at_ms: i64,
    pub deleted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotRow {
    pub id: String,
    pub sandbox_id: String,
    pub kind: String,
    pub manifest_json: String,
    pub size_b: u64,
    pub created_at_ms: i64,
    pub deleted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkerRow {
    pub node_id: String,
    /// gRPC addr of the worker's WorkerService.
    pub addr: String,
    pub capacity_json: String,
    pub load_json: String,
    pub drained: bool,
    pub last_heartbeat_ms: i64,
    pub registered_at_ms: i64,
}

// ---------------------------------------------------------------------------
// MetaStore
// ---------------------------------------------------------------------------

pub struct MetaStore {
    conn: Mutex<Connection>,
}

impl MetaStore {
    pub fn open(path: &Path) -> Result<Self> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let conn = Connection::open(path)
            .map_err(|e| FlintError::Internal(format!("sqlite open: {e}")))?;
        conn.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA busy_timeout=5000;")
            .map_err(|e| FlintError::Internal(format!("sqlite pragma: {e}")))?;
        let store = Self { conn: Mutex::new(conn) };
        store.migrate()?;
        Ok(store)
    }

    pub fn open_in_memory() -> Result<Self> {
        let conn = Connection::open_in_memory()
            .map_err(|e| FlintError::Internal(format!("sqlite mem: {e}")))?;
        let store = Self { conn: Mutex::new(conn) };
        store.migrate()?;
        Ok(store)
    }

    fn migrate(&self) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute_batch(
            r#"
            CREATE TABLE IF NOT EXISTS schema_version (v INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS api_keys (
                key_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                secret_hash TEXT NOT NULL,
                quotas_json TEXT NOT NULL,
                created_at_ms INTEGER NOT NULL,
                revoked INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS sandboxes (
                id TEXT PRIMARY KEY,
                key_id TEXT NOT NULL,
                project TEXT,
                template_id TEXT,
                state TEXT NOT NULL,
                vm_json TEXT NOT NULL,
                env_json TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                timeouts_json TEXT NOT NULL,
                worker_addr TEXT,
                worker_node_id TEXT,
                current_snapshot_id TEXT,
                created_at_ms INTEGER NOT NULL,
                last_activity_ms INTEGER NOT NULL,
                last_pause_ms INTEGER,
                usage_active_ms INTEGER NOT NULL DEFAULT 0,
                usage_paused_ms INTEGER NOT NULL DEFAULT 0,
                tool_calls_today INTEGER NOT NULL DEFAULT 0,
                tool_calls_day_start_ms INTEGER NOT NULL DEFAULT 0,
                deleted INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_sandboxes_key ON sandboxes(key_id, deleted);
            CREATE INDEX IF NOT EXISTS idx_sandboxes_state ON sandboxes(state);
            CREATE TABLE IF NOT EXISTS templates (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                key_id TEXT NOT NULL,
                base_snapshot_id TEXT NOT NULL,
                vm_json TEXT NOT NULL,
                env_json TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                size_b INTEGER NOT NULL DEFAULT 0,
                created_at_ms INTEGER NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS snapshots (
                id TEXT PRIMARY KEY,
                sandbox_id TEXT NOT NULL,
                kind TEXT NOT NULL,
                manifest_json TEXT NOT NULL,
                size_b INTEGER NOT NULL DEFAULT 0,
                created_at_ms INTEGER NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_snapshots_sbx ON snapshots(sandbox_id);
            CREATE TABLE IF NOT EXISTS workers (
                node_id TEXT PRIMARY KEY,
                addr TEXT NOT NULL,
                capacity_json TEXT NOT NULL,
                load_json TEXT NOT NULL,
                drained INTEGER NOT NULL DEFAULT 0,
                last_heartbeat_ms INTEGER NOT NULL,
                registered_at_ms INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS routing (
                sandbox_id TEXT PRIMARY KEY,
                worker_node_id TEXT NOT NULL,
                worker_addr TEXT NOT NULL,
                expires_at_ms INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS usage_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sandbox_id TEXT NOT NULL,
                kind TEXT NOT NULL,
                value_json TEXT NOT NULL,
                ts_ms INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS tool_usage (
                key_id TEXT NOT NULL,
                day TEXT NOT NULL,
                count INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (key_id, day)
            );
            INSERT OR IGNORE INTO schema_version(v) VALUES (1);
            "#,
        )
        .map_err(|e| FlintError::Internal(format!("migrate: {e}")))?;
        Ok(())
    }

    fn map_err(e: rusqlite::Error) -> FlintError {
        FlintError::Internal(format!("sqlite: {e}"))
    }

    // ----- api keys -----

    pub fn upsert_api_key(&self, row: &ApiKeyRow) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO api_keys (key_id, name, secret_hash, quotas_json, created_at_ms, revoked)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
            params![
                row.key_id,
                row.name,
                row.secret_hash,
                serde_json::to_string(&row.quotas)?,
                row.created_at_ms,
                row.revoked as i64
            ],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn get_api_key_by_id(&self, key_id: &str) -> Result<Option<ApiKeyRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT key_id, name, secret_hash, quotas_json, created_at_ms, revoked FROM api_keys WHERE key_id = ?1 AND revoked = 0",
            [key_id],
            |r| {
                Ok(ApiKeyRow {
                    key_id: r.get(0)?,
                    name: r.get(1)?,
                    secret_hash: r.get(2)?,
                    quotas: serde_json::from_str(&r.get::<_, String>(3)?).unwrap_or_default(),
                    created_at_ms: r.get(4)?,
                    revoked: r.get::<_, i64>(5)? != 0,
                })
            },
        )
        .optional()
        .map_err(Self::map_err)
    }

    pub fn find_api_key_by_hash(&self, secret_hash: &str) -> Result<Option<ApiKeyRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT key_id, name, secret_hash, quotas_json, created_at_ms, revoked FROM api_keys WHERE secret_hash = ?1 AND revoked = 0",
            [secret_hash],
            |r| {
                Ok(ApiKeyRow {
                    key_id: r.get(0)?,
                    name: r.get(1)?,
                    secret_hash: r.get(2)?,
                    quotas: serde_json::from_str(&r.get::<_, String>(3)?).unwrap_or_default(),
                    created_at_ms: r.get(4)?,
                    revoked: r.get::<_, i64>(5)? != 0,
                })
            },
        )
        .optional()
        .map_err(Self::map_err)
    }

    pub fn list_api_keys(&self) -> Result<Vec<ApiKeyRow>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn
            .prepare("SELECT key_id, name, secret_hash, quotas_json, created_at_ms, revoked FROM api_keys WHERE revoked = 0 ORDER BY created_at_ms")
            .map_err(Self::map_err)?;
        let rows = stmt
            .query_map([], |r| {
                Ok(ApiKeyRow {
                    key_id: r.get(0)?,
                    name: r.get(1)?,
                    secret_hash: r.get(2)?,
                    quotas: serde_json::from_str(&r.get::<_, String>(3)?).unwrap_or_default(),
                    created_at_ms: r.get(4)?,
                    revoked: r.get::<_, i64>(5)? != 0,
                })
            })
            .map_err(Self::map_err)?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(Self::map_err)?);
        }
        Ok(out)
    }

    pub fn revoke_api_key(&self, key_id: &str) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("UPDATE api_keys SET revoked = 1 WHERE key_id = ?1", [key_id]).map_err(Self::map_err)?;
        Ok(())
    }

    // ----- sandboxes -----

    pub fn upsert_sandbox(&self, row: &SandboxRow) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO sandboxes
             (id, key_id, project, template_id, state, vm_json, env_json, metadata_json, timeouts_json,
              worker_addr, worker_node_id, current_snapshot_id, created_at_ms, last_activity_ms, last_pause_ms,
              usage_active_ms, usage_paused_ms, tool_calls_today, tool_calls_day_start_ms, deleted)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20)",
            params![
                row.id,
                row.key_id,
                row.project,
                row.template_id,
                row.state,
                serde_json::to_string(&row.vm)?,
                serde_json::to_string(&row.env)?,
                serde_json::to_string(&row.metadata)?,
                serde_json::to_string(&row.timeouts)?,
                row.worker_addr,
                row.worker_node_id,
                row.current_snapshot_id,
                row.created_at_ms,
                row.last_activity_ms,
                row.last_pause_ms,
                row.usage_active_ms,
                row.usage_paused_ms,
                row.tool_calls_today,
                row.tool_calls_day_start_ms,
                row.deleted as i64
            ],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn get_sandbox(&self, id: &str) -> Result<Option<SandboxRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT id, key_id, project, template_id, state, vm_json, env_json, metadata_json, timeouts_json,
                    worker_addr, worker_node_id, current_snapshot_id, created_at_ms, last_activity_ms, last_pause_ms,
                    usage_active_ms, usage_paused_ms, tool_calls_today, tool_calls_day_start_ms, deleted
             FROM sandboxes WHERE id = ?1",
            [id],
            Self::row_to_sandbox,
        )
        .optional()
        .map_err(Self::map_err)
    }

    fn row_to_sandbox(r: &rusqlite::Row<'_>) -> rusqlite::Result<SandboxRow> {
        Ok(SandboxRow {
            id: r.get(0)?,
            key_id: r.get(1)?,
            project: r.get(2)?,
            template_id: r.get(3)?,
            state: r.get(4)?,
            vm: serde_json::from_str(&r.get::<_, String>(5)?).unwrap_or_default(),
            env: serde_json::from_str(&r.get::<_, String>(6)?).unwrap_or_default(),
            metadata: serde_json::from_str(&r.get::<_, String>(7)?).unwrap_or_default(),
            timeouts: serde_json::from_str(&r.get::<_, String>(8)?).unwrap_or_default(),
            worker_addr: r.get(9)?,
            worker_node_id: r.get(10)?,
            current_snapshot_id: r.get(11)?,
            created_at_ms: r.get(12)?,
            last_activity_ms: r.get(13)?,
            last_pause_ms: r.get(14)?,
            usage_active_ms: r.get(15)?,
            usage_paused_ms: r.get(16)?,
            tool_calls_today: r.get(17)?,
            tool_calls_day_start_ms: r.get(18)?,
            deleted: r.get::<_, i64>(19)? != 0,
        })
    }

    pub fn list_sandboxes(
        &self,
        key_id: Option<&str>,
        state: Option<SandboxState>,
        limit: usize,
    ) -> Result<Vec<SandboxRow>> {
        let conn = self.conn.lock().unwrap();
        let mut sql = String::from(
            "SELECT id, key_id, project, template_id, state, vm_json, env_json, metadata_json, timeouts_json,
                    worker_addr, worker_node_id, current_snapshot_id, created_at_ms, last_activity_ms, last_pause_ms,
                    usage_active_ms, usage_paused_ms, tool_calls_today, tool_calls_day_start_ms, deleted
             FROM sandboxes WHERE deleted = 0",
        );
        let mut binds: Vec<String> = Vec::new();
        if let Some(k) = key_id {
            sql.push_str(&format!(" AND key_id = ?{}", binds.len() + 1));
            binds.push(k.to_string());
        }
        if let Some(s) = state {
            sql.push_str(&format!(" AND state = ?{}", binds.len() + 1));
            binds.push(s.as_str().to_string());
        }
        sql.push_str(" ORDER BY created_at_ms DESC LIMIT 200");
        let mut stmt = conn.prepare(&sql).map_err(Self::map_err)?;
        let refs: Vec<&dyn rusqlite::ToSql> = binds.iter().map(|b| b as &dyn rusqlite::ToSql).collect();
        let rows = stmt
            .query_map(refs.as_slice(), Self::row_to_sandbox)
            .map_err(Self::map_err)?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(Self::map_err)?);
        }
        out.truncate(limit);
        Ok(out)
    }

    /// Transition sandbox state with a guarded UPDATE (optimistic:
    /// only applied if the current state is `expect`).
    pub fn transition_sandbox(&self, id: &str, expect: SandboxState, to: SandboxState) -> Result<bool> {
        let conn = self.conn.lock().unwrap();
        let n = conn
            .execute(
                "UPDATE sandboxes SET state = ?2 WHERE id = ?1 AND state = ?3",
                params![id, to.as_str(), expect.as_str()],
            )
            .map_err(Self::map_err)?;
        Ok(n > 0)
    }

    pub fn set_sandbox_state(&self, id: &str, to: SandboxState) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("UPDATE sandboxes SET state = ?2 WHERE id = ?1", params![id, to.as_str()])
            .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn touch_sandbox_activity(&self, id: &str, now_ms: i64) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("UPDATE sandboxes SET last_activity_ms = ?2 WHERE id = ?1", params![id, now_ms])
            .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn add_usage(&self, id: &str, active_ms: i64, paused_ms: i64) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "UPDATE sandboxes SET usage_active_ms = usage_active_ms + ?2, usage_paused_ms = usage_paused_ms + ?3 WHERE id = ?1",
            params![id, active_ms, paused_ms],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    /// Record a tool call for a key on a calendar day (UTC) and return
    /// the day's total.
    pub fn record_tool_call(&self, key_id: &str) -> Result<i64> {
        let day = chrono::Utc::now().format("%Y-%m-%d").to_string();
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT INTO tool_usage (key_id, day, count) VALUES (?1, ?2, 1)
             ON CONFLICT(key_id, day) DO UPDATE SET count = count + 1",
            params![key_id, day],
        )
        .map_err(Self::map_err)?;
        conn.query_row(
            "SELECT count FROM tool_usage WHERE key_id = ?1 AND day = ?2",
            params![key_id, day],
            |r| r.get::<_, i64>(0),
        )
        .map_err(Self::map_err)
    }

    pub fn tool_calls_today(&self, key_id: &str) -> Result<i64> {
        let day = chrono::Utc::now().format("%Y-%m-%d").to_string();
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT count FROM tool_usage WHERE key_id = ?1 AND day = ?2",
            params![key_id, day],
            |r| r.get::<_, i64>(0),
        )
        .optional()
        .map_err(Self::map_err)
        .map(|o| o.unwrap_or(0))
    }

    pub fn count_active_sandboxes(&self, key_id: &str) -> Result<i64> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT COUNT(*) FROM sandboxes WHERE key_id = ?1 AND deleted = 0 AND state NOT IN ('stopped','deleted')",
            [key_id],
            |r| r.get::<_, i64>(0),
        )
        .map_err(Self::map_err)
    }

    // ----- templates -----

    pub fn upsert_template(&self, row: &TemplateRow) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO templates (id, name, key_id, base_snapshot_id, vm_json, env_json, metadata_json, size_b, created_at_ms, deleted)
             VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10)",
            params![
                row.id,
                row.name,
                row.key_id,
                row.base_snapshot_id,
                serde_json::to_string(&row.vm)?,
                serde_json::to_string(&row.env)?,
                serde_json::to_string(&row.metadata)?,
                row.size_b as i64,
                row.created_at_ms,
                row.deleted as i64
            ],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn get_template(&self, id: &str) -> Result<Option<TemplateRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT id, name, key_id, base_snapshot_id, vm_json, env_json, metadata_json, size_b, created_at_ms, deleted
             FROM templates WHERE id = ?1 AND deleted = 0",
            [id],
            |r| {
                Ok(TemplateRow {
                    id: r.get(0)?,
                    name: r.get(1)?,
                    key_id: r.get(2)?,
                    base_snapshot_id: r.get(3)?,
                    vm: serde_json::from_str(&r.get::<_, String>(4)?).unwrap_or_default(),
                    env: serde_json::from_str(&r.get::<_, String>(5)?).unwrap_or_default(),
                    metadata: serde_json::from_str(&r.get::<_, String>(6)?).unwrap_or_default(),
                    size_b: r.get::<_, i64>(7)? as u64,
                    created_at_ms: r.get(8)?,
                    deleted: r.get::<_, i64>(9)? != 0,
                })
            },
        )
        .optional()
        .map_err(Self::map_err)
    }

    pub fn list_templates(&self) -> Result<Vec<TemplateRow>> {
        let conn = self.conn.lock().unwrap();
        let mut stmt = conn
            .prepare("SELECT id, name, key_id, base_snapshot_id, vm_json, env_json, metadata_json, size_b, created_at_ms, deleted FROM templates WHERE deleted = 0 ORDER BY created_at_ms")
            .map_err(Self::map_err)?;
        let rows = stmt
            .query_map([], |r| {
                Ok(TemplateRow {
                    id: r.get(0)?,
                    name: r.get(1)?,
                    key_id: r.get(2)?,
                    base_snapshot_id: r.get(3)?,
                    vm: serde_json::from_str(&r.get::<_, String>(4)?).unwrap_or_default(),
                    env: serde_json::from_str(&r.get::<_, String>(5)?).unwrap_or_default(),
                    metadata: serde_json::from_str(&r.get::<_, String>(6)?).unwrap_or_default(),
                    size_b: r.get::<_, i64>(7)? as u64,
                    created_at_ms: r.get(8)?,
                    deleted: r.get::<_, i64>(9)? != 0,
                })
            })
            .map_err(Self::map_err)?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(Self::map_err)?);
        }
        Ok(out)
    }

    // ----- snapshots -----

    pub fn upsert_snapshot(&self, row: &SnapshotRow) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO snapshots (id, sandbox_id, kind, manifest_json, size_b, created_at_ms, deleted)
             VALUES (?1,?2,?3,?4,?5,?6,?7)",
            params![row.id, row.sandbox_id, row.kind, row.manifest_json, row.size_b as i64, row.created_at_ms, row.deleted as i64],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn get_snapshot(&self, id: &str) -> Result<Option<SnapshotRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT id, sandbox_id, kind, manifest_json, size_b, created_at_ms, deleted FROM snapshots WHERE id = ?1",
            [id],
            |r| {
                Ok(SnapshotRow {
                    id: r.get(0)?,
                    sandbox_id: r.get(1)?,
                    kind: r.get(2)?,
                    manifest_json: r.get(3)?,
                    size_b: r.get::<_, i64>(4)? as u64,
                    created_at_ms: r.get(5)?,
                    deleted: r.get::<_, i64>(6)? != 0,
                })
            },
        )
        .optional()
        .map_err(Self::map_err)
    }

    pub fn latest_snapshot_for(&self, sandbox_id: &str) -> Result<Option<SnapshotRow>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT id, sandbox_id, kind, manifest_json, size_b, created_at_ms, deleted FROM snapshots
             WHERE sandbox_id = ?1 AND deleted = 0 ORDER BY created_at_ms DESC LIMIT 1",
            [sandbox_id],
            |r| {
                Ok(SnapshotRow {
                    id: r.get(0)?,
                    sandbox_id: r.get(1)?,
                    kind: r.get(2)?,
                    manifest_json: r.get(3)?,
                    size_b: r.get::<_, i64>(4)? as u64,
                    created_at_ms: r.get(5)?,
                    deleted: r.get::<_, i64>(6)? != 0,
                })
            },
        )
        .optional()
        .map_err(Self::map_err)
    }

    // ----- workers + routing -----

    pub fn upsert_worker(&self, row: &WorkerRow) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO workers (node_id, addr, capacity_json, load_json, drained, last_heartbeat_ms, registered_at_ms)
             VALUES (?1,?2,?3,?4,?5,?6,?7)",
            params![row.node_id, row.addr, row.capacity_json, row.load_json, row.drained as i64, row.last_heartbeat_ms, row.registered_at_ms],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn list_workers(&self, stale_after_ms: i64) -> Result<Vec<WorkerRow>> {
        let conn = self.conn.lock().unwrap();
        let cutoff = flint_core::util::now_ms() - stale_after_ms;
        let mut stmt = conn
            .prepare("SELECT node_id, addr, capacity_json, load_json, drained, last_heartbeat_ms, registered_at_ms FROM workers WHERE last_heartbeat_ms >= ?1")
            .map_err(Self::map_err)?;
        let rows = stmt
            .query_map([cutoff], |r| {
                Ok(WorkerRow {
                    node_id: r.get(0)?,
                    addr: r.get(1)?,
                    capacity_json: r.get(2)?,
                    load_json: r.get(3)?,
                    drained: r.get::<_, i64>(4)? != 0,
                    last_heartbeat_ms: r.get(5)?,
                    registered_at_ms: r.get(6)?,
                })
            })
            .map_err(Self::map_err)?;
        let mut out = Vec::new();
        for r in rows {
            out.push(r.map_err(Self::map_err)?);
        }
        Ok(out)
    }

    pub fn set_worker_drained(&self, node_id: &str, drained: bool) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("UPDATE workers SET drained = ?2 WHERE node_id = ?1", params![node_id, drained as i64])
            .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn set_route(&self, sandbox_id: &str, worker_node_id: &str, worker_addr: &str, ttl_ms: i64) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT OR REPLACE INTO routing (sandbox_id, worker_node_id, worker_addr, expires_at_ms) VALUES (?1,?2,?3,?4)",
            params![sandbox_id, worker_node_id, worker_addr, flint_core::util::now_ms() + ttl_ms],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }

    pub fn get_route(&self, sandbox_id: &str) -> Result<Option<(String, String)>> {
        let conn = self.conn.lock().unwrap();
        conn.query_row(
            "SELECT worker_node_id, worker_addr FROM routing WHERE sandbox_id = ?1 AND expires_at_ms > ?2",
            rusqlite::params![sandbox_id, flint_core::util::now_ms()],
            |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)),
        )
        .optional()
        .map_err(Self::map_err)
    }

    pub fn delete_route(&self, sandbox_id: &str) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute("DELETE FROM routing WHERE sandbox_id = ?1", [sandbox_id]).map_err(Self::map_err)?;
        Ok(())
    }

    // ----- usage events -----

    pub fn append_usage_event(&self, sandbox_id: &str, kind: &str, value_json: &str) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        conn.execute(
            "INSERT INTO usage_events (sandbox_id, kind, value_json, ts_ms) VALUES (?1,?2,?3,?4)",
            params![sandbox_id, kind, value_json, flint_core::util::now_ms()],
        )
        .map_err(Self::map_err)?;
        Ok(())
    }
}

// A default spec helper for tests / migrations.
pub fn default_create_spec() -> SandboxCreateSpec {
    SandboxCreateSpec::default()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sbx(id: &str, key: &str, state: SandboxState) -> SandboxRow {
        SandboxRow {
            id: id.into(),
            key_id: key.into(),
            project: None,
            template_id: None,
            state: state.as_str().into(),
            vm: VmSpec::default(),
            env: BTreeMap::new(),
            metadata: BTreeMap::new(),
            timeouts: TimeoutPolicy::default(),
            worker_addr: None,
            worker_node_id: None,
            current_snapshot_id: None,
            created_at_ms: 1,
            last_activity_ms: 1,
            last_pause_ms: None,
            usage_active_ms: 0,
            usage_paused_ms: 0,
            tool_calls_today: 0,
            tool_calls_day_start_ms: 0,
            deleted: false,
        }
    }

    #[test]
    fn sandbox_lifecycle_and_routing() {
        let store = MetaStore::open_in_memory().unwrap();
        store.upsert_sandbox(&sbx("sbx_1", "key_a", SandboxState::Creating)).unwrap();
        assert!(store.transition_sandbox("sbx_1", SandboxState::Creating, SandboxState::Running).unwrap());
        assert!(!store.transition_sandbox("sbx_1", SandboxState::Creating, SandboxState::Running).unwrap()); // stale
        let row = store.get_sandbox("sbx_1").unwrap().unwrap();
        assert_eq!(row.state, "running");
        assert_eq!(store.count_active_sandboxes("key_a").unwrap(), 1);

        store.set_route("sbx_1", "wrk_1", "http://127.0.0.1:7500", 60_000).unwrap();
        let (node, addr) = store.get_route("sbx_1").unwrap().unwrap();
        assert_eq!(node, "wrk_1");
        assert_eq!(addr, "http://127.0.0.1:7500");
        store.delete_route("sbx_1").unwrap();
        assert!(store.get_route("sbx_1").unwrap().is_none());
    }

    #[test]
    fn api_key_lookup_by_hash() {
        let store = MetaStore::open_in_memory().unwrap();
        let row = ApiKeyRow {
            key_id: "key_1".into(),
            name: "test".into(),
            secret_hash: "deadbeef".into(),
            quotas: KeyQuotas { max_concurrent_sandboxes: 5, max_req_per_sec: 10.0, max_tool_calls_per_day: 100 },
            created_at_ms: 0,
            revoked: false,
        };
        store.upsert_api_key(&row).unwrap();
        assert!(store.find_api_key_by_hash("deadbeef").unwrap().is_some());
        assert!(store.find_api_key_by_hash("other").unwrap().is_none());
        store.revoke_api_key("key_1").unwrap();
        assert!(store.find_api_key_by_hash("deadbeef").unwrap().is_none());
    }

    #[test]
    fn worker_registry_and_drain() {
        let store = MetaStore::open_in_memory().unwrap();
        let w = WorkerRow {
            node_id: "wrk_1".into(),
            addr: "http://127.0.0.1:7500".into(),
            capacity_json: "{}".into(),
            load_json: "{}".into(),
            drained: false,
            last_heartbeat_ms: flint_core::util::now_ms(),
            registered_at_ms: flint_core::util::now_ms(),
        };
        store.upsert_worker(&w).unwrap();
        assert_eq!(store.list_workers(60_000).unwrap().len(), 1);
        store.set_worker_drained("wrk_1", true).unwrap();
        let ws = store.list_workers(60_000).unwrap();
        assert!(ws[0].drained);
    }
}
