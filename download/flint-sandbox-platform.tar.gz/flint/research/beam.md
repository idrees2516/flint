# Beam (beam.cloud) — Deep Research

*Researched by task R2, October 2025. Sources: beam.cloud blog/docs, github.com/beam-cloud/beta9, comparisons.*

## Overview
Beam (Smartshare, Inc.) brands itself as "the GPU runtime for sandboxes and inference": "Give every agent its own computer: a sandbox that boots in seconds, runs anything, and forks from snapshots. Serve any model behind an autoscaling API… Everything runs on serverless GPUs and CPUs, scales to zero, and bills by the millisecond, on Beam's cloud or your own AWS, GCP, or Azure." Originally an ultrafast serverless-GPU runtime for arbitrary Python (vs. providers that only serve pre-loaded models), it has expanded to stateful agent sandboxes, task queues, managed databases, and BYOC "Compute Pools" — plus a fully open-source runtime, **beta9**, so the whole stack can be self-hosted.

## Isolation & Architecture
- **Open-source core (beta9)**: a custom container runtime + scheduler + embedded caching that launches containers in **under a second** (CPU) and ~2–10s on GPUs. Releases show a **forked gVisor** ("gVisor to release-…-beam.8", gVisor sandbox work) for sandboxes, with **Firecracker microVMs as the strongest isolation tier** ("Beam uses gVisor + runc, Firecracker microVMs — each sandbox boots its own kernel" — self-host guide). Egress can be fully blocked or restricted via CIDR allowlists, updatable at runtime.
- **Image pipeline** (from "The Magic of Serverless GPU" engineering post): early Beam pulled images from NFS; they then built a **custom image format + content-addressable storage (CAS)** — "in only 150 lines of code" supporting hundreds of concurrent pulls with <200GiB RAM; ~80% of any image is served from cache. 7–10s total to launch a GPU container + pull a 10GB image + load into GPU memory.
- **Model weights** on persistent volumes backed by NFS, mounted directly into containers; Tigris case study: "<10s cold starts, as fast as 50ms warm starts."
- Scheduling: Kubernetes-based scheduling with autoscaling (KEDA/Karpenter-style), QueueDepthAutoscaler exposing `min_containers`/`max_containers`/`tasks_per_container`; same SDK runs on Beam cloud, reserved capacity, your own hardware, or self-hosted beta9.
- Managed storage tiers: distributed Volumes (NFS-backed), S3 bucket mounts, **Durable Disks** (node-local persistent storage "for stateful services such as databases", with disk snapshots), managed Postgres/Redis/MySQL/MongoDB.

## API Surface
Python decorator programming model + TypeScript SDK for sandboxes/endpoints:
- `@endpoint(...)` — web endpoints (HTTP-invocable functions) with `on_start` initialization, `keep_warm_seconds`, `autoscaler=QueueDepthAutoscaler(...)`, `checkpoint_enabled=True`.
- `@function(...)` / `@task_queue(...)` — one-off remote functions, cron-style scheduled jobs, and Celery-replacing task queues with `TaskPolicy(max_retries=…)`, callbacks, `put()` invocation, `.map()` fan-out to hundreds of containers.
- `Sandbox(...).create()` — the agent-computer primitive: `sandbox.process.run_code("print(...)")`, `process.exec(...)` with stdin/stdout streaming, `sandbox.expose_port(8000)` for preview URLs, `sandbox.create_image_from_filesystem()`, `sandbox.snapshot_memory()`, `Sandbox().create_from_memory_snapshot(...)`, filesystem ops, Docker(-in-sandbox) support.
- CLI: `beam deploy app.py:fn --name …`, workspace MCP server for coding agents, webhooks, dashboard deploys from git repos.

## Persistence & Checkpointing
- **Sandbox snapshots** (docs): "capture the filesystem and/or memory of a Sandbox as an immutable artifact," then create new sandboxes from it — explicitly for **forking** ("test different variations of code"), warm-starting from saved state, and reproducible environments. Two distinct artifacts: `create_image_from_filesystem()` → image ID (cold-boot image), `snapshot_memory()` → checkpoint ID (restores process state *and* filesystem, "on supported runtimes"); restored sandboxes get fresh identity/URLs. Docs warn to wait for readiness (e.g., port-accepting loop) before snapshotting.
- **Endpoint checkpoint/restore**: `checkpoint_enabled=True` captures initialized state (post-`on_start`) and restores it on subsequent cold boots; "support depends on the runtime and workload; reconnect external services after restoring" — external connections are not restored.
- **Volumes/Durable Disks**: checkpoints written to a volume persist after container exit ("Deploy an endpoint that mounts the same volume and your model is serving traffic"); initial durable-disk checkpoints can take up to ~3 minutes to capture; snapshots included in storage pricing ($0.021/GB/mo cited).

## Agent & Long-Running Features
- Positioning has shifted agent-first: "Give an Agent a Computer" quickstart, coding-agent setup (Cursor/Claude Code/Codex via MCP + CLI briefings), RL environments & verifier rollouts (`.map()` fan-out of environments across GPUs), sandboxes with Docker and stateful processes, preview URLs for dev servers.
- Timeouts: task default 180s, settable to `-1` (no limit) for cron/long jobs; endpoints can keep containers warm indefinitely (`min_containers`); concurrency per container configurable ("workers per container" sharing CPU/RAM).
- Task queues with retries/callbacks, distributed maps, and Stack-level configuration group related apps.

## Pricing & Limits
- **Bills by the millisecond**, per-second advertised; **no charge for cold-start or image-pull time** (a deliberate differentiator vs Modal). Example: RTX 4090 endpoint w/ 4 vCPU + 16GiB = $1.77/hr ($0.69 GPU + $0.76 CPU + $0.32 RAM). H100 ≈ $3.95/hr class. Every tier includes **$30/month free credits**; free tier up to 5 GPU containers. Storage: volumes included free for weights/checkpoints on some plans; $0.021/GB/mo cited for durable storage.
- Limits: default task timeout 180s (docs) / 1 hour default for cron jobs (blog); synchronous web endpoints bound ~180s → move to task queues; warm containers bill while idle.

## Open-Source & Engineering Notes
- **github.com/beam-cloud/beta9** — "Ultrafast serverless GPU inference, sandboxes, and background jobs", **AGPL-3.0**, self-hostable (Helm charts; AWS/GCP/Azure "Compute Pools" BYOC; local dev cluster). This is Beam's biggest differentiator: the entire managed cloud is built on an open-source runtime you can run yourself.
- Engineering posts: https://www.beam.cloud/blog/serverless-platform-guide ("The Magic of Serverless GPU: A Behind the Scenes Look" — CAS, NFS, 7–10s GPU boot anatomy), /blog/cold-start-serverless-gpu-inference, /blog/modal-pricing-explained (honest cross-provider pricing teardown), /blog/how-to-self-host-code-sandbox, /blog/best-stateful-sandbox-code-execution-2026.
- Docs index: https://docs.beam.cloud/llms.txt (llms.txt-served Mintlify docs; notable pages: /v2/sandbox/snapshots, /v2/topics/cold-start, /v2/endpoint/keep-warm, /v2/data/durable-disks).

## Lessons for a Rust Implementation
1. **Open-source the runtime, sell the cloud.** beta9 (Go) proves an OSS "serverless GPU + sandbox engine" drives adoption; a Rust equivalent (single binary control plane + worker agents + gRPC dataplane) could be materially faster and lighter.
2. **Content-addressable image store with hot local cache**: a ~150-line CAS serving ~80% of layers from cache is the cheapest big win for cold starts — decouple *image pull* from *billing* (don't charge for pulls, win friends).
3. **Fork as a primitive**: `snapshot_memory()` → `create_from_memory_snapshot()` turns one sandbox into a template; frame snapshots as *images* (filesystem) vs *checkpoints* (memory+processes) — different IDs, different restore paths.
4. **Tiered isolation**: gVisor default + Firecracker microVM tier for hostile workloads; allowlist/CIDR egress control updatable at runtime.
5. **Queue-depth autoscaling as the user-visible contract** (`min_containers`, `max_containers`, `tasks_per_container`) is simpler to reason about than raw concurrency targets.
6. **Readiness probes before snapshotting** (poll the port, then checkpoint) — a practical detail every snapshot API needs.
