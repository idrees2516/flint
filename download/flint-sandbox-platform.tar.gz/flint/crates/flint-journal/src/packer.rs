//! Layer packer: tar.gz a directory (streaming, bounded memory) and
//! safely unpack it back (escape-proof extraction).

use flint_core::FlintError;
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{BufReader, BufWriter, Read, Write};
use std::path::{Component, Path, PathBuf};

/// Pack `dir` (contents, recursively) into `out` as tar.gz.
/// Returns `(sha256_hex, size_bytes)` of the archive.
pub fn pack_dir(dir: &Path, out: &Path) -> Result<(String, u64), FlintError> {
    if let Some(parent) = out.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let out_file = File::create(out)?;
    let mut writer = BufWriter::new(out_file);
    let enc = flate2::write::GzEncoder::new(&mut writer, flate2::Compression::fast());
    let mut builder = tar::Builder::new(enc);
    builder.mode(tar::HeaderMode::Deterministic);
    builder.follow_symlinks(false);
    builder.append_dir_all(".", dir).map_err(|e| FlintError::Internal(format!("tar: {e}")))?;
    let enc = builder.into_inner().map_err(|e| FlintError::Internal(format!("tar finish: {e}")))?;
    enc.finish().map_err(|e| FlintError::Internal(format!("gzip finish: {e}")))?;
    writer.flush()?;
    writer.get_ref().sync_all()?;

    // Hash while reading back (cheap relative to the pack itself).
    let mut f = File::open(out)?;
    let mut hasher = Sha256::new();
    let mut buf = [0u8; 64 * 1024];
    let mut size: u64 = 0;
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        hasher.update(&buf[..n]);
        size += n as u64;
    }
    Ok((hex::encode(hasher.finalize()), size))
}

/// Validate that an archive entry path is safe to extract under `dest`
/// (no absolute paths, no `..` escapes). Symlinks must have lexically
/// in-root relative targets.
fn safe_entry_path(dest: &Path, entry_path: &Path) -> Option<PathBuf> {
    let mut out = dest.to_path_buf();
    let mut depth: i32 = 0;
    for comp in entry_path.components() {
        match comp {
            Component::Normal(c) => {
                out.push(c);
                depth += 1;
            }
            Component::CurDir => {}
            Component::ParentDir => {
                if depth == 0 {
                    return None;
                }
                out.pop();
                depth -= 1;
            }
            _ => return None,
        }
    }
    Some(out)
}

fn safe_symlink_target(_dest: &Path, target: &str) -> bool {
    // Only allow relative targets that never escape the root lexically.
    if target.starts_with('/') || target.contains(":\\") || target.contains('\0') {
        return false;
    }
    let mut depth: i32 = 0;
    for comp in Path::new(target).components() {
        match comp {
            Component::Normal(_) => depth += 1,
            Component::CurDir => {}
            Component::ParentDir => {
                depth -= 1;
                if depth < 0 {
                    return false;
                }
            }
            _ => return false,
        }
    }
    true
}

/// Unpack a tar.gz archive into `dest`, skipping unsafe entries.
/// Returns the number of entries extracted.
pub fn unpack_dir(archive: &Path, dest: &Path) -> Result<usize, FlintError> {
    std::fs::create_dir_all(dest)?;
    let f = BufReader::new(File::open(archive)?);
    let gz = flate2::read::GzDecoder::new(f);
    let mut tar = tar::Archive::new(gz);
    tar.set_overwrite(true);
    let mut count = 0usize;
    for entry in tar.entries().map_err(|e| FlintError::Internal(format!("tar read: {e}")))? {
        let mut entry = entry.map_err(|e| FlintError::Internal(format!("tar entry: {e}")))?;
        let path = entry.path().map_err(|e| FlintError::Internal(format!("tar path: {e}")))?.into_owned();
        let Some(safe) = safe_entry_path(dest, &path) else {
            tracing::warn!(entry = ?path, "skipping unsafe tar entry");
            continue;
        };
        let header = entry.header();
        let kind = header.entry_type();
        use std::os::unix::fs::PermissionsExt;
        let mode = header.mode().unwrap_or(0o644);
        match kind {
            tar::EntryType::Regular | tar::EntryType::Continuous => {
                if let Some(parent) = safe.parent() {
                    let _ = std::fs::create_dir_all(parent);
                }
                let mut out = File::create(&safe)?;
                std::io::copy(&mut entry, &mut out)?;
                let _ = std::fs::set_permissions(&safe, std::fs::Permissions::from_mode(mode));
            }
            tar::EntryType::Directory => {
                std::fs::create_dir_all(&safe)?;
                let _ = std::fs::set_permissions(&safe, std::fs::Permissions::from_mode(mode | 0o700));
            }
            tar::EntryType::Symlink => {
                let target = header
                    .link_name()
                    .ok()
                    .flatten()
                    .map(|t| t.to_string_lossy().into_owned());
                match target {
                    Some(t) if safe_symlink_target(dest, &t) => {
                        if let Some(parent) = safe.parent() {
                            let _ = std::fs::create_dir_all(parent);
                        }
                        let _ = std::os::unix::fs::symlink(&t, &safe);
                    }
                    _ => tracing::warn!(entry = ?path, "skipping unsafe symlink"),
                }
            }
            tar::EntryType::Link => {
                // Hard link: only if target resolves inside dest.
                let target = header.link_name().ok().flatten().map(|t| t.into_owned());
                if let Some(t) = target {
                    if let Some(safe_t) = safe_entry_path(dest, &t) {
                        if safe_t.exists() {
                            let _ = std::fs::hard_link(&safe_t, &safe);
                        }
                    }
                }
            }
            _ => {
                tracing::debug!(entry = ?path, ?kind, "skipping special tar entry");
            }
        }
        count += 1;
    }
    Ok(count)
}

/// Stream-copy a reader into a file with a hard size cap.
pub fn copy_bounded<R: Read, W: Write>(mut r: R, mut w: W, max_bytes: u64) -> Result<u64, FlintError> {
    let mut buf = [0u8; 64 * 1024];
    let mut total: u64 = 0;
    loop {
        let n = r.read(&mut buf)?;
        if n == 0 {
            break;
        }
        total += n as u64;
        if total > max_bytes {
            return Err(FlintError::InvalidParam { msg: format!("payload exceeds {max_bytes} bytes") });
        }
        w.write_all(&buf[..n])?;
    }
    w.flush()?;
    Ok(total)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pack_unpack_roundtrip() {
        let src = tempfile::tempdir().unwrap();
        let dst = tempfile::tempdir().unwrap();
        std::fs::create_dir_all(src.path().join("a/b")).unwrap();
        std::fs::write(src.path().join("a/b/f.txt"), b"content").unwrap();
        std::fs::write(src.path().join("top.bin"), vec![0u8; 100_000]).unwrap();
        std::os::unix::fs::symlink("b/f.txt", src.path().join("a/link")).unwrap();

        let arch = src.path().join("../archive.tar.gz");
        let (sha, size) = pack_dir(src.path(), &arch).unwrap();
        assert!(size > 0);
        assert_eq!(sha.len(), 64);

        let n = unpack_dir(&arch, dst.path()).unwrap();
        assert!(n >= 4);
        assert_eq!(std::fs::read(dst.path().join("a/b/f.txt")).unwrap(), b"content");
        assert!(dst.path().join("a/link").is_symlink());
        assert_eq!(std::fs::read(dst.path().join("top.bin")).unwrap().len(), 100_000);
    }
}
