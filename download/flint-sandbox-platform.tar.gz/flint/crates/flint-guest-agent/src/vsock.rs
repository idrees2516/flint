//! AF_VSOCK listener for production microVM mode.
//!
//! Inside the VM the agent listens on vsock (guest CID is implicit); the
//! host dials through the Firecracker vsock UDS with `CONNECT <port>\n`.
//! Implementation uses raw sockets via `libc` + tokio `AsyncFd` (there is
//! no first-class vsock support in std or tokio).

use anyhow::{Context, Result};
use std::os::fd::{AsRawFd, FromRawFd, RawFd};
use std::task::Poll;

pub const VMADDR_CID_ANY: u32 = 0xFFFF_FFFF;
const AF_VSOCK: i32 = 40;

pub fn vsock_listen(port: u32) -> Result<RawFd> {
    unsafe {
        let fd = libc::socket(AF_VSOCK, libc::SOCK_STREAM | libc::SOCK_CLOEXEC, 0);
        if fd < 0 {
            return Err(anyhow::anyhow!("socket(AF_VSOCK) failed — is CONFIG_VIRTIO_VSOCKETS enabled?"));
        }
        let addr = libc::sockaddr_vm {
            svm_family: AF_VSOCK as u16,
            svm_reserved1: 0,
            svm_port: port,
            svm_cid: VMADDR_CID_ANY,
            svm_zero: [0; 4],
        };
        let ret = libc::bind(
            fd,
            &addr as *const libc::sockaddr_vm as *const libc::sockaddr,
            std::mem::size_of::<libc::sockaddr_vm>() as u32,
        );
        if ret < 0 {
            libc::close(fd);
            return Err(anyhow::anyhow!("vsock bind(:{port}) failed"));
        }
        if libc::listen(fd, 64) < 0 {
            libc::close(fd);
            return Err(anyhow::anyhow!("vsock listen failed"));
        }
        Ok(fd)
    }
}

/// An async duplex stream over a raw fd (vsock connections and PTY
/// masters alike — both are just fds to us).
pub struct FdStream {
    fd: std::sync::Arc<tokio::io::unix::AsyncFd<std::os::fd::OwnedFd>>,
}

pub type VsockStream = FdStream;

impl FdStream {
    pub fn from_raw(fd: RawFd) -> Result<Self> {
        let owned = unsafe { std::os::fd::OwnedFd::from_raw_fd(fd) };
        unsafe {
            let flags = libc::fcntl(owned.as_raw_fd(), libc::F_GETFL);
            libc::fcntl(owned.as_raw_fd(), libc::F_SETFL, flags | libc::O_NONBLOCK);
        }
        let async_fd = tokio::io::unix::AsyncFd::new(owned).context("AsyncFd::new")?;
        Ok(Self { fd: std::sync::Arc::new(async_fd) })
    }

    /// Share the same underlying fd (async readiness state is shared; the
    /// poll methods take `&self`, so reader and writer tasks can each hold
    /// a clone).
    pub fn try_clone(&self) -> FdStream {
        FdStream { fd: self.fd.clone() }
    }

    /// The underlying raw fd (for ioctls).
    pub fn raw_fd(&self) -> RawFd {
        self.fd.get_ref().as_raw_fd()
    }
}

impl tokio::io::AsyncRead for FdStream {
    fn poll_read(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
        buf: &mut tokio::io::ReadBuf<'_>,
    ) -> Poll<std::io::Result<()>> {
        loop {
            let mut guard = match self.fd.poll_read_ready(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(Ok(g)) => g,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
            };
            let unfilled = buf.initialize_unfilled();
            let n = unsafe { libc::recv(self.raw_fd(), unfilled.as_mut_ptr() as *mut _, unfilled.len(), 0) };
            if n < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() == std::io::ErrorKind::WouldBlock {
                    guard.clear_ready();
                    continue;
                }
                return Poll::Ready(Err(err));
            }
            if n == 0 {
                return Poll::Ready(Ok(()));
            }
            let n = n as usize;
            unsafe { buf.assume_init(n) };
            buf.advance(n);
            return Poll::Ready(Ok(()));
        }
    }
}

impl tokio::io::AsyncWrite for FdStream {
    fn poll_write(
        self: std::pin::Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
        buf: &[u8],
    ) -> Poll<std::io::Result<usize>> {
        loop {
            let mut guard = match self.fd.poll_write_ready(cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(Ok(g)) => g,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
            };
            let n = unsafe { libc::send(self.raw_fd(), buf.as_ptr() as *const _, buf.len(), libc::MSG_NOSIGNAL) };
            if n < 0 {
                let err = std::io::Error::last_os_error();
                if err.kind() == std::io::ErrorKind::WouldBlock {
                    guard.clear_ready();
                    continue;
                }
                return Poll::Ready(Err(err));
            }
            return Poll::Ready(Ok(n as usize));
        }
    }

    fn poll_flush(self: std::pin::Pin<&mut Self>, _cx: &mut std::task::Context<'_>) -> Poll<std::io::Result<()>> {
        Poll::Ready(Ok(()))
    }

    fn poll_shutdown(self: std::pin::Pin<&mut Self>, _cx: &mut std::task::Context<'_>) -> Poll<std::io::Result<()>> {
        Poll::Ready(Ok(()))
    }
}

/// Accept one vsock connection. The listener is intentionally leaked
/// (boxed) so it stays open across calls — the agent serves forever.
pub async fn vsock_accept(listener_fd: RawFd) -> Result<FdStream> {
    unsafe {
        let flags = libc::fcntl(listener_fd, libc::F_GETFL);
        libc::fcntl(listener_fd, libc::F_SETFL, flags | libc::O_NONBLOCK);
    }
    let listener = unsafe { std::os::fd::OwnedFd::from_raw_fd(listener_fd) };
    let fd: &'static tokio::io::unix::AsyncFd<std::os::fd::OwnedFd> =
        Box::leak(Box::new(tokio::io::unix::AsyncFd::new(listener).context("AsyncFd::new")?));
    loop {
        let mut guard = fd.readable().await.context("vsock readable")?;
        let conn = unsafe {
            libc::accept4(
                fd.get_ref().as_raw_fd(),
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                libc::SOCK_CLOEXEC,
            )
        };
        if conn >= 0 {
            return FdStream::from_raw(conn);
        }
        let err = std::io::Error::last_os_error();
        if err.kind() == std::io::ErrorKind::WouldBlock {
            guard.clear_ready();
            continue;
        }
        return Err(err).context("vsock accept");
    }
}
