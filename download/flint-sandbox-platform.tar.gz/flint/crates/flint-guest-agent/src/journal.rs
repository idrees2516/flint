//! Guest-side journal: mirrors journaled ops into the sandbox filesystem
//! so disk state and op-log travel together (defense-in-depth on top of
//! the host WAL).

use flint_journal::ops::Op;
use flint_journal::FsyncPolicy;
use std::path::{Path, PathBuf};

pub struct GuestJournal {
    wal: std::sync::Mutex<Option<flint_journal::Wal>>,
    path: PathBuf,
}

impl GuestJournal {
    /// Journal lives at `<home>/.flint/journal.log` in dev, or
    /// `/var/lib/flint/journal.log` when home is `/`.
    pub fn open(home: &Path) -> Self {
        let path = if home == Path::new("/") {
            PathBuf::from("/var/lib/flint/journal.log")
        } else {
            home.join(".flint/journal.log")
        };
        let wal = flint_journal::Wal::open(&path, FsyncPolicy::Barrier).ok();
        Self { wal: std::sync::Mutex::new(wal), path }
    }

    pub fn append(&self, op_id: &str, op: &Op) -> u64 {
        let mut guard = self.wal.lock().unwrap();
        match guard.as_mut() {
            Some(wal) => wal
                .append(flint_journal::WalRecord::OpApplied {
                    op_id: op_id.to_string(),
                    op: op.clone(),
                })
                .map(|seq| seq)
                .unwrap_or(0),
            None => 0,
        }
    }

    pub fn barrier(&self) -> u64 {
        let mut guard = self.wal.lock().unwrap();
        match guard.as_mut() {
            Some(wal) => wal.barrier().unwrap_or(0),
            None => 0,
        }
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn seq(&self) -> u64 {
        self.wal.lock().unwrap().as_ref().map(|w| w.len()).unwrap_or(0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn journal_appends_and_barriers() {
        let tmp = tempfile::tempdir().unwrap();
        let j = GuestJournal::open(tmp.path());
        j.append(
            "op_1",
            &Op::FileWrite { path: "/x".into(), content_b64: "aGk=".into(), mode: None },
        );
        let seq = j.barrier();
        assert!(seq >= 1);
        // Durability: the record is on disk.
        assert!(j.path().exists());
        let recs = flint_journal::wal::recover_records(j.path()).0;
        assert_eq!(recs.len(), 2); // op + barrier
    }
}
