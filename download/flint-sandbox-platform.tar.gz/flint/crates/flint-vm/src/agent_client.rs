//! `GuestAgentClient`: multiplexed client for the guest-agent protocol
//! (`flint-core::agent_proto`) over any byte stream — vsock-UDS pipe in
//! production, localhost TCP in dev.

use flint_core::agent_proto::{self, WireMsg};
use flint_core::{FlintError, Result};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::sync::{mpsc, oneshot};

const MAX_FRAME: usize = 64 * 1024 * 1024;

/// Messages a stream consumer receives for a streaming call.
#[derive(Debug, Clone)]
pub enum StreamMsg {
    /// Agent push (stdout/stderr/exit/term.out/port.data...).
    Event { kind: String, seq: u64, data: Value },
    /// Final response (agent is done with this call).
    End { ok: bool, result: Value, error: Option<String> },
}

enum Pending {
    Call(oneshot::Sender<Result<Value>>),
    Stream { events: mpsc::Sender<StreamMsg> },
}

pub struct GuestAgentClient {
    tx: mpsc::Sender<Vec<u8>>,
    next_id: AtomicU64,
    pending: Arc<Mutex<HashMap<u64, Pending>>>,
    closed: Arc<AtomicBool>,
}

impl GuestAgentClient {
    /// Connect over an already-established stream. For Firecracker vsock
    /// the stream must have completed the `CONNECT <port>\n` handshake
    /// (see [`connect_vsock_uds`]).
    pub fn connect<S>(stream: S) -> Arc<Self>
    where
        S: AsyncRead + AsyncWrite + Unpin + Send + 'static,
    {
        let (tx, rx) = mpsc::channel::<Vec<u8>>(256);
        let pending = Arc::new(Mutex::new(HashMap::new()));
        let closed = Arc::new(AtomicBool::new(false));
        tokio::spawn(run_connection(stream, rx, pending.clone(), closed.clone()));
        Arc::new(Self { tx, next_id: AtomicU64::new(1), pending, closed })
    }

    fn check(&self) -> Result<()> {
        if self.closed.load(Ordering::Relaxed) {
            return Err(FlintError::Unavailable { msg: "guest agent connection closed".into() });
        }
        Ok(())
    }

    async fn send(&self, msg: &WireMsg) -> Result<()> {
        self.check()?;
        let mut buf = Vec::new();
        agent_proto::encode(msg, &mut buf);
        self.tx.send(buf).await.map_err(|_| FlintError::Unavailable { msg: "agent writer gone".into() })
    }

    /// Fire a unary call and await its response.
    pub async fn call(&self, method: &str, params: Value) -> Result<Value> {
        self.call_with_timeout(method, params, Duration::from_secs(60)).await
    }

    pub async fn call_with_timeout(
        &self,
        method: &str,
        params: Value,
        timeout: Duration,
    ) -> Result<Value> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let (tx, rx) = oneshot::channel();
        self.pending.lock().unwrap().insert(id, Pending::Call(tx));
        self.send(&WireMsg::Req { id, method: method.into(), params }).await?;
        match tokio::time::timeout(timeout, rx).await {
            Ok(Ok(res)) => res,
            Ok(Err(_)) => {
                self.pending.lock().unwrap().remove(&id);
                Err(FlintError::Unavailable { msg: "agent dropped call".into() })
            }
            Err(_) => {
                self.pending.lock().unwrap().remove(&id);
                Err(FlintError::Timeout { op: method.into(), ms: timeout.as_millis() as u64 })
            }
        }
    }

    /// Fire a streaming call (exec / terminal / port tunnel); returns the
    /// event receiver. The stream ends with `StreamMsg::End`.
    pub async fn call_stream(&self, method: &str, params: Value) -> Result<mpsc::Receiver<StreamMsg>> {
        self.call_stream_buffered(method, params, 256).await
    }

    pub async fn call_stream_buffered(
        &self,
        method: &str,
        params: Value,
        buffer: usize,
    ) -> Result<mpsc::Receiver<StreamMsg>> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let (tx, rx) = mpsc::channel(buffer.max(1));
        self.pending.lock().unwrap().insert(id, Pending::Stream { events: tx });
        self.send(&WireMsg::Req { id, method: method.into(), params }).await?;
        Ok(rx)
    }

    /// Call stream with a caller-known payload; returns the numeric agent
    /// stream id used (needed to push input/resize/close frames later).
    pub async fn call_stream_tagged(
        &self,
        method: &str,
        params: Value,
    ) -> Result<(u64, mpsc::Receiver<StreamMsg>)> {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let (tx, rx) = mpsc::channel(256);
        self.pending.lock().unwrap().insert(id, Pending::Stream { events: tx });
        self.send(&WireMsg::Req { id, method: method.into(), params }).await?;
        Ok((id, rx))
    }

    /// Push data to an open stream (process stdin / terminal input /
    /// port tunnel bytes / resize).
    pub async fn push(&self, id: u64, kind: &str, data: Value) -> Result<()> {
        self.send(&WireMsg::Push { id, kind: kind.into(), data }).await
    }

    /// The id a streaming call would use next (used to re-attach writers).
    pub fn peek_next_id(&self) -> u64 {
        self.next_id.load(Ordering::Relaxed)
    }

    // ----- convenience methods used across the worker -----

    pub async fn ping(&self) -> Result<()> {
        self.call("ping", json!({})).await.map(|_| ())
    }

    pub async fn barrier(&self) -> Result<u64> {
        let v = self.call("barrier", json!({})).await?;
        Ok(v.get("journal_seq").and_then(|s| s.as_u64()).unwrap_or(0))
    }

    /// Blocking exec: returns (exit_code, stdout, stderr, timed_out).
    pub async fn exec(
        &self,
        spec: &flint_core::ExecSpec,
        op_id: &str,
        max_output: usize,
    ) -> Result<(i32, Vec<u8>, Vec<u8>, bool)> {
        let timeout = Duration::from_millis(spec.timeout_ms.unwrap_or(120_000).min(600_000));
        let mut rx = self
            .call_stream_buffered(agent_proto::methods::EXEC, agent_proto::params_exec(spec, op_id), 512)
            .await?;
        let mut stdout = Vec::new();
        let mut stderr = Vec::new();
        let mut exit_code = None;
        let mut timed_out = false;
        let deadline = tokio::time::Instant::now() + timeout;
        loop {
            let msg = tokio::time::timeout_at(deadline, rx.recv()).await;
            match msg {
                Err(_) => {
                    // Client-side timeout: kill via process table.
                    let _ = self.push(0, "kill_all", json!({ "op_id": op_id })).await;
                    timed_out = true;
                    let _ = &timed_out;
                    // Drain whatever is left briefly.
                    while let Ok(m) = rx.try_recv() {
                        match m {
                            StreamMsg::Event { kind, data, .. } => {
                                absorb_event(&kind, &data, &mut stdout, &mut stderr, &mut exit_code, max_output);
                            }
                            StreamMsg::End { .. } => break,
                        }
                    }
                    return Ok((exit_code.unwrap_or(-1), stdout, stderr, true));
                }
                Ok(Some(StreamMsg::Event { kind, data, .. })) => {
                    absorb_event(&kind, &data, &mut stdout, &mut stderr, &mut exit_code, max_output);
                }
                Ok(Some(StreamMsg::End { ok, result, error })) => {
                    if !ok {
                        return Err(FlintError::Internal(format!(
                            "exec failed: {}",
                            error.unwrap_or_default()
                        )));
                    }
                    if let Some(code) = result.get("exit_code").and_then(|c| c.as_i64()) {
                        exit_code = Some(code as i32);
                    }
                    if let Some(t) = result.get("timed_out").and_then(|c| c.as_bool()) {
                        timed_out = t;
                    }
                    return Ok((exit_code.unwrap_or(0), stdout, stderr, timed_out));
                }
                Ok(None) => {
                    return Ok((exit_code.unwrap_or(-1), stdout, stderr, timed_out));
                }
            }
        }
    }
}

fn absorb_event(
    kind: &str,
    data: &Value,
    stdout: &mut Vec<u8>,
    stderr: &mut Vec<u8>,
    exit_code: &mut Option<i32>,
    max_output: usize,
) {
    match kind {
        flint_core::agent_proto::events::STDOUT => {
            if stdout.len() < max_output {
                if let Some(b) = decode_b64(data.get("data_b64")) {
                    stdout.extend_from_slice(&b[..(b.len().min(max_output - stdout.len()))]);
                }
            }
        }
        flint_core::agent_proto::events::STDERR => {
            if stderr.len() < max_output {
                if let Some(b) = decode_b64(data.get("data_b64")) {
                    stderr.extend_from_slice(&b[..(b.len().min(max_output - stderr.len()))]);
                }
            }
        }
        flint_core::agent_proto::events::EXIT => {
            if let Some(c) = data.get("exit_code").and_then(|c| c.as_i64()) {
                *exit_code = Some(c as i32);
            }
        }
        _ => {}
    }
}

fn decode_b64(v: Option<&Value>) -> Option<Vec<u8>> {
    let s = v?.as_str()?;
    flint_core::util::b64_decode(s).ok()
}

async fn run_connection<S>(
    mut stream: S,
    mut out_rx: mpsc::Receiver<Vec<u8>>,
    pending: Arc<Mutex<HashMap<u64, Pending>>>,
    closed: Arc<AtomicBool>,
) where
    S: AsyncRead + AsyncWrite + Unpin + Send + 'static,
{
    let mut read_buf: Vec<u8> = Vec::with_capacity(8192);
    let mut decoder = agent_proto::FrameDecoder::default();
    let mut tmp = [0u8; 16384];
    loop {
        tokio::select! {
            out = out_rx.recv() => {
                match out {
                    Some(bytes) => {
                        if stream.write_all(&bytes).await.is_err() {
                            break;
                        }
                    }
                    None => {
                        let _ = stream.shutdown().await;
                        break;
                    }
                }
            }
            n = stream.read(&mut tmp) => {
                match n {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        read_buf.extend_from_slice(&tmp[..n]);
                        if read_buf.len() > MAX_FRAME * 2 {
                            tracing::error!("agent connection: read buffer overflow");
                            break;
                        }
                        decoder.feed(&tmp[..n]);
                        while let Some(msg) = decoder.next() {
                            route(msg, &pending).await;
                        }
                    }
                }
            }
        }
    }
    closed.store(true, Ordering::Relaxed);
    // Fail all pending calls.
    let mut p = pending.lock().unwrap();
    for (_, v) in p.drain() {
        match v {
            Pending::Call(tx) => {
                let _ = tx.send(Err(FlintError::Unavailable { msg: "agent connection lost".into() }));
            }
            Pending::Stream { events } => {
                let _ = events.try_send(StreamMsg::End {
                    ok: false,
                    result: Value::Null,
                    error: Some("agent connection lost".into()),
                });
            }
        }
    }
}

async fn route(msg: WireMsg, pending: &Arc<Mutex<HashMap<u64, Pending>>>) {
    match msg {
        WireMsg::Resp { id, ok, result, error } => {
            let entry = pending.lock().unwrap().remove(&id);
            match entry {
                Some(Pending::Call(tx)) => {
                    let _ = tx.send(if ok {
                        Ok(result)
                    } else {
                        Err(FlintError::Internal(format!(
                            "agent error: {}",
                            error.unwrap_or_else(|| "unknown".into())
                        )))
                    });
                }
                Some(Pending::Stream { events }) => {
                    let _ = events.send(StreamMsg::End { ok, result, error }).await;
                }
                None => {}
            }
        }
        WireMsg::Ev { id, seq, kind, data } => {
            let events = {
                let p = pending.lock().unwrap();
                match p.get(&id) {
                    Some(Pending::Stream { events }) => Some(events.clone()),
                    _ => None,
                }
            };
            if let Some(events) = events {
                if events.send(StreamMsg::Event { kind, seq, data }).await.is_err() {
                    pending.lock().unwrap().remove(&id);
                }
            }
        }
        WireMsg::Req { .. } | WireMsg::Push { .. } => {
            tracing::debug!("agent client: unexpected inbound Req/Push frame (ignored)");
        }
    }
}

/// Complete the Firecracker vsock handshake: dial the FC vsock UDS, send
/// `CONNECT <port>\n`, wait for `OK`, and return the established pipe.
pub async fn connect_vsock_uds(uds_path: &std::path::Path, port: u32) -> Result<tokio::net::UnixStream> {
    let mut s = tokio::net::UnixStream::connect(uds_path)
        .await
        .map_err(|e| FlintError::Unavailable { msg: format!("vsock uds connect: {e}") })?;
    s.write_all(format!("CONNECT {port}\n").as_bytes()).await?;
    // Firecracker replies "OK <port>\n" (or ERR ...).
    let mut buf = Vec::new();
    let mut byte = [0u8; 1];
    loop {
        let n = s.read(&mut byte).await?;
        if n == 0 {
            return Err(FlintError::Unavailable { msg: "vsock uds closed during handshake".into() });
        }
        buf.push(byte[0]);
        if buf.ends_with(b"\n") {
            break;
        }
        if buf.len() > 128 {
            return Err(FlintError::Unavailable { msg: "vsock handshake too long".into() });
        }
    }
    let line = String::from_utf8_lossy(&buf).into_owned();
    if line.starts_with("OK") {
        Ok(s)
    } else {
        Err(FlintError::Unavailable { msg: format!("vsock handshake failed: {line}") })
    }
}
