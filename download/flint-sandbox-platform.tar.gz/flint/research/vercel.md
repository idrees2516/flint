# Vercel — Sandbox API, Functions, Fluid Compute

## Overview
Vercel Sandbox is "run agent-generated code in isolation": on-demand **Firecracker microVMs** behind JS/Python SDKs, a Docker-like CLI and REST — for agent workflows, code interpreters, debugging and previews (v0 itself runs generated apps in sandboxes). The design thesis: agents spend 71–98% of wall-time waiting on model inference, so Vercel meters **Active CPU**, not wall-clock. **Fluid Compute** is a separate product — the execution model for Vercel *Functions* (warm instances handling concurrent requests in-process), not the Sandbox.

## Isolation & Architecture
- `Sandbox.create()` provisions a **Firecracker microVM with a dedicated kernel** ("microVM boundary prevents escapes"); each sandbox has its own network namespace, strict CPU/memory/disk limits, automatic timeouts.
- Default image: Vercel-managed "universal" (Ubuntu 26.04 + Node + Python + coding agents preinstalled; legacy runtimes ran Amazon Linux 2023) or **any OCI image** from the Vercel Container Registry; snapshots can serve as boot source.
- **System-privileged workloads are a feature**: Docker-in-sandbox, VPN clients, FUSE mounts run with `sudo`, contained by the VM boundary.
- Networking: default-open outbound HTTP(S) with user-defined **NetworkPolicy** rules; a per-sandbox **proxy CA cert** is injected into the trust store with env vars (`NODE_EXTRA_CA_CERTS`, `SSL_CERT_FILE`) preset, making TLS interception transparent; **Secure Compute** networks offer static egress IPs + AWS VPC peering.
- Fluid Compute (context): multiple concurrent invocations per warm instance, `waitUntil` background work, pre-warming, AZ→region failover — "serverless servers" handling 45B+ weekly requests, cutting cold starts/compute cost up to 95%.

## API Surface
- JS `@vercel/sandbox`, Python `vercel.sandbox`, CLI (`sandbox create/exec/stop`, `--interactive --tty`, `--sudo`, `--env`), REST (`api.vercel.com` v1/v2 sandboxes + sessions endpoints).
- Classes: `Sandbox` (create / getOrCreate-by-name, `runCommand` blocking or detached + polling, `createUser`/`createGroup`/`asUser`, `extendTimeout`, `snapshot()`), `SandboxUser`, `Session` (a single running VM instance — a sandbox spans many sessions), `FileSystem` (node:fs/promises-compatible), `Command` streaming, `NetworkPolicy`, `Snapshot`, `Drive` (persistent mounted storage), tags, region + failover regions. Auth via **OIDC tokens** (automatic on Vercel, `vercel link` locally).
- Ecosystem/KB: LangChain, OpenAI/Anthropic SDKs, **Devin Outposts on Vercel Sandbox**, **Terminal-Bench / SWE-bench / Harbor benchmark runner** ("each trial executes in an isolated Firecracker microVM"), `ai-sdk-tool-code-execution` (Python 3.13 executeCode tool), container-image testing via VCR.

## Persistence & Lifecycle
**Persistent by default**: when a session stops (timeout or `stop()`), the filesystem is auto-snapshotted; the next call starts a new session restored from it — no manual resume. Model: one named sandbox (identity + filesystem) ↔ many ephemeral sessions. Default session timeout ~5 min; **maximum runtime 24 hours** (changelog). Explicit **Snapshots** (create/list/get/delete) for checkpointing, setup-skipping and sharing; **Drives** (public beta) are persistent mounted volumes up to **16 TiB**; remote object stores (S3) mountable via FUSE; data *downloaded into* sandboxes is free. Docs position sandboxes for bursty agent work, not 24/7 hosting or bulk storage.

## Agent-Specific Features
**Multi-Agent Sandboxes**: each agent gets its own Linux user + private home dir, with files shared between agents via groups. Coding agents preinstalled in the universal image. Active-CPU billing explicitly framed for agent loops. Detached commands + polling for long steps. Per-agent sandbox patterns (Herdr changelog).

## Pricing & Limits (iad1 rates, docs 2026-09)
- **Active CPU $0.128/hr per vCPU** (5 hrs/month included on Hobby) — metered on actual CPU work.
- **Provisioned Memory $0.0212/GB-hr** (420 GB-hrs/month included) — billed while running even when idle (docs example: $0.0552 vs $0.1704/day at 10% CPU).
- Sandbox creations, egress ~$0.15/GB (downloads free), snapshot and drive storage billed per GB-month.
- Limits: ~10 concurrent sandboxes (Hobby) → ~10,000 (Pro); vCPU allocation rate limits; 24h max runtime; broad regional coverage (iad1, sfo1, cle1, cdg1, … 19 regions).

## Open-Source & Engineering Notes (URLs)
- github.com/vercel/sandbox — **SDK + CLI are open source**.
- Blogs: vercel.com/blog/vercel-sandbox-is-now-generally-available · /blog/fluid-how-we-built-serverless-servers · /blog/how-fluid-compute-works-on-vercel.
- Docs are fully markdown/agent-crawlable, incl. per-page `.graph.md` cross-link maps for AI agents; changelogs (Drives beta, 24h runtime, free downloads).
- Comparisons: fly.io/learn/ai-sandbox-pricing · northflank.com/blog/vercel-sandbox-vs-cloudflare-sandbox · vercel.com/kb/guide/vercel-sandbox-vs-codesandbox.

## Lessons for a Rust implementation
1. **Bill by active CPU, not wall-clock** — cgroup CPU-time accounting makes this cheap, fair for agent loops, and a marketing differentiator.
2. **Sessions vs sandboxes**: separate persistent identity+filesystem from ephemeral running instances — a clean state machine (`pending → running → stopping → stopped/failed`) and the right default is *persistence*.
3. **Auto-snapshot on stop** (filesystem-level) removes a whole class of user error; explicit snapshots become an optimization, not a chore.
4. **Per-agent Linux users + group-shared files** = OS-native multi-agent tenancy inside one VM.
5. **Egress proxy with injected CA + preset env vars** yields network policy + static IPs without breaking tools — replicate with a Rust TLS-terminating forward proxy.
6. **fs/promises-shaped SDK APIs** cut adoption friction to near zero for Node users; a Rust crate should feel like `std::fs`.
