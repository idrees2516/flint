//! FirecrackerDriver: the production microVM backend.
//!
//! Implements the full lifecycle against the Firecracker UDS API
//! (research: exact call order from `research/tech-firecracker.md`):
//!
//! **Fresh boot** — jailer'd firecracker process, then
//! `PUT /boot-source` → `PUT /drives/rootfs` → `PUT /network-interfaces/eth0`
//! → `PUT /machine-config` → `PUT /vsock` → `PUT /mmds/config` + `/mmds`
//! → `PUT /actions {InstanceStart}` → connect the agent over the vsock UDS.
//!
//! **Pause** — `PATCH /vm {"state":"Paused"}` →
//! `PUT /snapshot/create {Full}` → operator copies the drive file
//! (FC drains+fsyncs block devices but does not copy them).
//!
//! **Restore** — fresh FC process → `PUT /snapshot/load` →
//! `PATCH /vm {"state":"Resumed"}` → vsock reconnect.
//!
//! The agent channel rides the Firecracker vsock UDS with the
//! `CONNECT 5252\n` handshake (host-managed CIDs ≥ 3).

use crate::agent_client::{connect_vsock_uds, GuestAgentClient};
use crate::driver::{RestoredLayers, SpawnRequest, StagedLayer, VmDriver, VmInstance};
use flint_core::{minhttp, DriverKind, FlintError, Result};
use flint_journal::LayerKind;
use nix::sys::signal::{killpg, Signal};
use nix::unistd::Pid;
use serde::Serialize;
use std::path::{Path, PathBuf};
use std::process::Stdio;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Arc;
use std::time::Duration;

pub const AGENT_VSOCK_PORT: u32 = 5252;

// ---------------------------------------------------------------------------
// Typed Firecracker API payloads (field names are load-bearing)
// ---------------------------------------------------------------------------

#[derive(Serialize, Debug, Clone)]
pub struct BootSource {
    pub kernel_image_path: String,
    pub boot_args: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct Drive {
    pub drive_id: String,
    pub is_root_device: bool,
    pub path_on_host: String,
    pub is_read_only: bool,
    pub io_engine: String,
}

#[derive(Serialize, Debug, Clone, Default)]
pub struct RateLimit {
    pub bandwidth: Option<TokenBucket>,
    pub ops: Option<TokenBucket>,
}

#[derive(Serialize, Debug, Clone)]
pub struct TokenBucket {
    pub size: u64,
    pub refill_time: u64,
}

#[derive(Serialize, Debug, Clone)]
pub struct NetworkInterface {
    pub iface_id: String,
    pub guest_mac: String,
    pub host_dev_name: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub rx_rate_limiter: Option<RateLimit>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tx_rate_limiter: Option<RateLimit>,
}

#[derive(Serialize, Debug, Clone)]
pub struct MachineConfig {
    pub vcpu_count: u16,
    pub mem_size_mib: u32,
    pub smt: bool,
    pub track_dirty_pages: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cpu_template: Option<String>,
}

#[derive(Serialize, Debug, Clone)]
pub struct VsockConfig {
    pub guest_cid: u32,
    pub uds_path: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct MmdsConfig {
    pub network_interfaces: Vec<String>,
    pub version: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct ActionStart {
    pub action_type: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct VmStatePatch {
    pub state: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct SnapshotCreate {
    pub snapshot_type: String,
    pub snapshot_path: String,
    pub mem_file_path: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct MemBackend {
    pub backend_type: String,
    pub backend_path: String,
}

#[derive(Serialize, Debug, Clone)]
pub struct SnapshotLoad {
    pub snapshot_path: String,
    pub mem_backend: MemBackend,
    pub resume_vm: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub vsock_override: Option<VsockConfig>,
}

pub fn default_boot_args(extra: &str) -> String {
    format!(
        "console=ttyS0 reboot=k panic=1 pci=off ip={GUEST}::{TAP}:{MASK}:instance:eth0:off:tap0 {extra}",
        GUEST = crate::firecracker::guest_ip_const(),
        TAP = crate::firecracker::tap_ip_const(),
        MASK = "255.255.255.252"
    )
}

fn guest_ip_const() -> &'static str {
    "169.254.0.21"
}
fn tap_ip_const() -> &'static str {
    "169.254.0.22"
}

// ---------------------------------------------------------------------------
// UDS API client
// ---------------------------------------------------------------------------

pub struct FcClient {
    sock: PathBuf,
}

impl FcClient {
    pub fn new(sock: impl Into<PathBuf>) -> Self {
        Self { sock: sock.into() }
    }

    async fn req(&self, method: &str, path: &str, body: Option<&[u8]>) -> Result<minhttp::HttpResponse> {
        let mut stream = tokio::net::UnixStream::connect(&self.sock)
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("fc uds {path}: {e}") })?;
        let resp = minhttp::request_over(&mut stream, method, path, &[], body).await?;
        if !resp.is_success() {
            return Err(FlintError::Internal(format!(
                "fc {method} {path} -> {}: {}",
                resp.status,
                resp.body_string()
            )));
        }
        Ok(resp)
    }

    pub async fn put_json<T: Serialize>(&self, path: &str, body: &T) -> Result<()> {
        let payload = serde_json::to_vec(body)?;
        self.req("PUT", path, Some(&payload)).await.map(|_| ())
    }

    pub async fn patch_json<T: Serialize>(&self, path: &str, body: &T) -> Result<()> {
        let payload = serde_json::to_vec(body)?;
        self.req("PATCH", path, Some(&payload)).await.map(|_| ())
    }

    pub async fn get(&self, path: &str) -> Result<minhttp::HttpResponse> {
        self.req("GET", path, None).await
    }
}

// ---------------------------------------------------------------------------
// Driver
// ---------------------------------------------------------------------------

pub struct FirecrackerDriver {
    firecracker_bin: PathBuf,
    jailer_bin: PathBuf,
    kernel_image: PathBuf,
    #[allow(dead_code)]
    rootfs_dir: PathBuf,
    vm_dir: PathBuf,
    cpu_template: Option<String>,
    next_cid: AtomicU32,
}

impl FirecrackerDriver {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        firecracker_bin: PathBuf,
        jailer_bin: Option<PathBuf>,
        kernel_image: PathBuf,
        rootfs_dir: PathBuf,
        vm_dir: PathBuf,
        cpu_template: Option<String>,
    ) -> Self {
        let jailer_bin = jailer_bin.unwrap_or_else(|| {
            let mut p = firecracker_bin
                .parent()
                .map(|p| p.to_path_buf())
                .unwrap_or_default();
            p.push("jailer");
            p
        });
        Self {
            firecracker_bin,
            jailer_bin,
            kernel_image,
            rootfs_dir,
            vm_dir,
            cpu_template,
            next_cid: AtomicU32::new(3),
        }
    }

    fn allocate_cid(&self) -> u32 {
        loop {
            let cid = self.next_cid.fetch_add(1, Ordering::Relaxed);
            if cid >= 3 {
                return cid;
            }
        }
    }

    fn vm_dir_for(&self, sandbox_id: &str) -> PathBuf {
        self.vm_dir.join(sandbox_id)
    }

    /// Copy a template rootfs with copy-on-write when the filesystem
    /// supports it (btrfs/xfs reflink), falling back to a full copy.
    fn cow_copy_drive(&self, template: &Path, dest: &Path) -> Result<()> {
        let status = std::process::Command::new("cp")
            .args(["--reflink=auto", "--sparse=always"])
            .arg(template)
            .arg(dest)
            .status()
            .map_err(|e| FlintError::Internal(format!("cp drive: {e}")))?;
        if !status.success() {
            return Err(FlintError::Internal("cp drive failed".into()));
        }
        Ok(())
    }
}

#[async_trait::async_trait]
impl VmDriver for FirecrackerDriver {
    fn kind(&self) -> DriverKind {
        DriverKind::Firecracker
    }

    async fn init(&self) -> Result<()> {
        tokio::fs::create_dir_all(&self.vm_dir).await?;
        if !self.kernel_image.exists() {
            return Err(FlintError::InvalidParam {
                msg: format!("kernel image missing: {}", self.kernel_image.display()),
            });
        }
        Ok(())
    }

    async fn spawn(&self, req: SpawnRequest) -> Result<Box<dyn VmInstance>> {
        let vmdir = self.vm_dir_for(&req.sandbox_id);
        // Jailer layout: <chroot-base>/<id>/root/ is FC's chroot; paths in
        // the API are chroot-relative, sockets land under it.
        let jail = vmdir.join("root");
        tokio::fs::create_dir_all(jail.join("run")).await?;

        let cid = req.cid.unwrap_or_else(|| self.allocate_cid());
        let api_sock = jail.join("run/firecracker.sock");
        let vsock_uds = jail.join("v.sock");

        // Drive: restore > template-CoW > fresh sparse.
        let drive_outside = vmdir.join("drive.img");
        if let Some(restored) = &req.restore {
            if let Some(d) = &restored.drive {
                tokio::fs::copy(d, &drive_outside).await?;
            }
        } else if let Some(tpl) = &req.template_drive {
            self.cow_copy_drive(tpl, &drive_outside)?;
        } else {
            let f = tokio::fs::File::create(&drive_outside).await?;
            f.set_len(req.vm.disk_mib as u64 * 1024 * 1024).await?;
        }
        if !drive_outside.exists() {
            return Err(FlintError::Internal("drive setup failed".into()));
        }

        // Stage kernel + drive inside the chroot.
        let chroot_kernel = jail.join("vmlinux");
        if !chroot_kernel.exists() {
            tokio::fs::copy(&self.kernel_image, &chroot_kernel).await?;
        }
        let chroot_drive = jail.join("drive.img");
        if !chroot_drive.exists() {
            tokio::fs::copy(&drive_outside, &chroot_drive).await?;
        }

        // Jailer: FC runs chrooted with cgroup + seccomp restrictions.
        let mut cmd = tokio::process::Command::new(&self.jailer_bin);
        cmd.args(["--id", &req.sandbox_id, "--uid", "1000", "--gid", "1000", "--exec-file"])
            .arg(&self.firecracker_bin)
            .arg("--chroot-base-dir")
            .arg(&self.vm_dir)
            .arg("--api-sock")
            .arg("/run/firecracker.sock")
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .kill_on_drop(true);
        if let Some(ns) = &req.netns {
            cmd.arg("--netns").arg(format!("/var/run/netns/{ns}"));
        }
        let mut child = cmd
            .spawn()
            .map_err(|e| FlintError::Internal(format!("jailer spawn: {e}")))?;

        // Wait for the api socket to appear.
        for _ in 0..100 {
            if api_sock.exists() {
                break;
            }
            if let Ok(Some(status)) = child.try_wait() {
                return Err(FlintError::Internal(format!("jailer exited ({status}) before socket")));
            }
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
        if !api_sock.exists() {
            let _ = child.start_kill();
            return Err(FlintError::Timeout { op: "firecracker api socket".into(), ms: 2000 });
        }
        let client = Arc::new(FcClient::new(&api_sock));

        let restored =
            req.restore.clone().and_then(|r| (r.memory.is_some() && r.snapfile.is_some()).then_some(r));

        if let Some(r) = &restored {
            // ---- Restore path ----
            let mem_path = jail.join("memfile");
            let snap_path = jail.join("snapfile");
            tokio::fs::copy(r.memory.as_ref().unwrap(), &mem_path).await?;
            tokio::fs::copy(r.snapfile.as_ref().unwrap(), &snap_path).await?;
            client
                .put_json(
                    "/snapshot/load",
                    &SnapshotLoad {
                        snapshot_path: "/snapfile".into(),
                        mem_backend: MemBackend {
                            backend_type: "File".into(),
                            backend_path: "/memfile".into(),
                        },
                        resume_vm: false,
                        vsock_override: Some(VsockConfig {
                            guest_cid: cid,
                            uds_path: "/v.sock".into(),
                        }),
                    },
                )
                .await?;
            client.patch_json("/vm", &VmStatePatch { state: "Resumed".into() }).await?;
        } else {
            // ---- Fresh boot path ----
            client
                .put_json(
                    "/boot-source",
                    &BootSource {
                        kernel_image_path: "/vmlinux".into(),
                        boot_args: default_boot_args(""),
                    },
                )
                .await?;
            client
                .put_json(
                    "/drives/rootfs",
                    &Drive {
                        drive_id: "rootfs".into(),
                        is_root_device: true,
                        path_on_host: "/drive.img".into(),
                        is_read_only: false,
                        io_engine: "Async".into(),
                    },
                )
                .await?;
            client
                .put_json(
                    "/network-interfaces/eth0",
                    &NetworkInterface {
                        iface_id: "eth0".into(),
                        guest_mac: "02:FC:00:00:00:05".into(),
                        host_dev_name: "tap0".into(),
                        rx_rate_limiter: None,
                        tx_rate_limiter: None,
                    },
                )
                .await?;
            client
                .put_json(
                    "/machine-config",
                    &MachineConfig {
                        vcpu_count: req.vm.vcpu_count as u16,
                        mem_size_mib: req.vm.mem_mib,
                        smt: false,
                        track_dirty_pages: true,
                        cpu_template: self.cpu_template.clone(),
                    },
                )
                .await?;
            client
                .put_json(
                    "/vsock",
                    &VsockConfig { guest_cid: cid, uds_path: "/v.sock".into() },
                )
                .await?;
            client
                .put_json(
                    "/mmds/config",
                    &MmdsConfig { network_interfaces: vec!["eth0".into()], version: "V2".into() },
                )
                .await?;
            client
                .put_json(
                    "/mmds",
                    &serde_json::json!({
                        "sandbox_id": req.sandbox_id,
                        "agent_token": req.agent_token,
                        "latest": { "meta-data": { "sandbox_id": req.sandbox_id, "agent_token": req.agent_token } }
                    }),
                )
                .await?;
            client
                .put_json("/actions", &ActionStart { action_type: "InstanceStart".into() })
                .await?;
        }

        // Agent over vsock.
        let stream = connect_vsock_uds(&vsock_uds, AGENT_VSOCK_PORT).await?;
        let agent = GuestAgentClient::connect(stream);

        Ok(Box::new(FcInstance {
            sandbox_id: req.sandbox_id,
            agent,
            client,
            child: tokio::sync::Mutex::new(Some(child)),
            paused: Arc::new(AtomicBool::new(false)),
            vmdir,
            drive: drive_outside,
        }))
    }

    async fn prepare_restore(&self, sandbox_id: &str, layers: &mut RestoredLayers) -> Result<()> {
        if layers.memory.is_none() || layers.snapfile.is_none() {
            // Disk-only restore: the sandbox will cold-boot and the worker
            // replays the journal; report that upstream via the layers.
            tracing::info!(sandbox = %sandbox_id, "disk-only restore (no memory snapshot)");
        }
        Ok(())
    }
}

pub struct FcInstance {
    sandbox_id: String,
    agent: Arc<GuestAgentClient>,
    client: Arc<FcClient>,
    child: tokio::sync::Mutex<Option<tokio::process::Child>>,
    paused: Arc<AtomicBool>,
    vmdir: PathBuf,
    drive: PathBuf,
}

#[async_trait::async_trait]
impl VmInstance for FcInstance {
    fn sandbox_id(&self) -> &str {
        &self.sandbox_id
    }

    fn kind(&self) -> DriverKind {
        DriverKind::Firecracker
    }

    fn agent(&self) -> &Arc<GuestAgentClient> {
        &self.agent
    }

    fn home_dir(&self) -> Option<&Path> {
        None
    }

    async fn pause(&self, staging: &Path) -> Result<Vec<StagedLayer>> {
        tokio::fs::create_dir_all(staging).await?;
        let _ = self.agent.barrier().await;

        self.client.patch_json("/vm", &VmStatePatch { state: "Paused".into() }).await?;
        self.paused.store(true, Ordering::Relaxed);

        let snap_path = staging.join("snapfile");
        let mem_path = staging.join("memfile");
        self.client
            .put_json(
                "/snapshot/create",
                &SnapshotCreate {
                    snapshot_type: "Full".into(),
                    snapshot_path: snap_path.display().to_string(),
                    mem_file_path: mem_path.display().to_string(),
                },
            )
            .await?;

        // FC flushes block devices but does not copy them — we stage the
        // drive ourselves so the worker can upload all three layers.
        let drive_dest = staging.join("drive.img");
        tokio::fs::copy(&self.drive, &drive_dest).await?;

        Ok(vec![
            StagedLayer { kind: LayerKind::Memory, path: mem_path },
            StagedLayer { kind: LayerKind::DeviceState, path: snap_path },
            StagedLayer { kind: LayerKind::FsTarGz, path: drive_dest },
        ])
    }

    async fn resume(&self) -> Result<()> {
        self.client.patch_json("/vm", &VmStatePatch { state: "Resumed".into() }).await?;
        self.paused.store(false, Ordering::Relaxed);
        // vsock connections are killed across snapshot restore
        // (VIRTIO_VSOCK_EVENT_TRANSPORT_RESET); the worker re-dials via a
        // fresh spawn in practice.
        self.agent.ping().await
    }

    async fn stop(&self) -> Result<()> {
        if let Some(pgid) = self
            .child
            .try_lock()
            .ok()
            .and_then(|g| g.as_ref().and_then(|c| c.id()).map(|id| id as i32))
        {
            let _ = killpg(Pid::from_raw(-pgid), Signal::SIGTERM);
            tokio::time::sleep(Duration::from_millis(300)).await;
            let _ = killpg(Pid::from_raw(-pgid), Signal::SIGKILL);
        }
        *self.child.lock().await = None;
        let _ = tokio::fs::remove_dir_all(&self.vmdir).await;
        Ok(())
    }

    async fn is_alive(&self) -> bool {
        if self.paused.load(Ordering::Relaxed) {
            return true; // paused VMs are intentionally frozen, not dead
        }
        let exited = self
            .child
            .try_lock()
            .ok()
            .and_then(|mut g| match g.as_mut() {
                Some(c) => c.try_wait().ok().flatten().map(|_| true),
                None => Some(false),
            })
            .unwrap_or(false);
        if exited {
            return false;
        }
        self.agent.ping().await.is_ok()
    }
}

// ---------------------------------------------------------------------------
// Tests: payload shapes are load-bearing (they must match the Firecracker
// API exactly — verified against the swagger-derived research notes).
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn boot_source_fields() {
        let v = serde_json::to_value(BootSource {
            kernel_image_path: "/vmlinux".into(),
            boot_args: "console=ttyS0".into(),
        })
        .unwrap();
        assert_eq!(v["kernel_image_path"], "/vmlinux");
        assert_eq!(v["boot_args"], "console=ttyS0");
    }

    #[test]
    fn drive_fields() {
        let v = serde_json::to_value(Drive {
            drive_id: "rootfs".into(),
            is_root_device: true,
            path_on_host: "/drive.img".into(),
            is_read_only: false,
            io_engine: "Async".into(),
        })
        .unwrap();
        assert_eq!(v["drive_id"], "rootfs");
        assert!(v["is_root_device"].as_bool().unwrap());
        assert_eq!(v["io_engine"], "Async");
    }

    #[test]
    fn network_interface_fields() {
        let v = serde_json::to_value(NetworkInterface {
            iface_id: "eth0".into(),
            guest_mac: "02:FC:00:00:00:05".into(),
            host_dev_name: "tap0".into(),
            rx_rate_limiter: None,
            tx_rate_limiter: None,
        })
        .unwrap();
        assert_eq!(v["iface_id"], "eth0");
        assert_eq!(v["host_dev_name"], "tap0");
        assert!(v.get("rx_rate_limiter").is_none(), "None limiters must be omitted");
    }

    #[test]
    fn machine_config_fields() {
        let v = serde_json::to_value(MachineConfig {
            vcpu_count: 2,
            mem_size_mib: 2048,
            smt: false,
            track_dirty_pages: true,
            cpu_template: None,
        })
        .unwrap();
        assert_eq!(v["vcpu_count"], 2);
        assert_eq!(v["mem_size_mib"], 2048);
        assert!(!v["smt"].as_bool().unwrap());
        assert!(v["track_dirty_pages"].as_bool().unwrap());
        assert!(v.get("cpu_template").is_none());
    }

    #[test]
    fn snapshot_load_fields() {
        let v = serde_json::to_value(SnapshotLoad {
            snapshot_path: "/snapfile".into(),
            mem_backend: MemBackend { backend_type: "File".into(), backend_path: "/memfile".into() },
            resume_vm: false,
            vsock_override: Some(VsockConfig { guest_cid: 7, uds_path: "/v.sock".into() }),
        })
        .unwrap();
        assert_eq!(v["mem_backend"]["backend_type"], "File");
        assert_eq!(v["mem_backend"]["backend_path"], "/memfile");
        assert!(!v["resume_vm"].as_bool().unwrap());
        assert_eq!(v["vsock_override"]["guest_cid"], 7);
    }

    #[test]
    fn boot_args_have_static_ip() {
        let args = default_boot_args("");
        assert!(args.contains("ip=169.254.0.21::169.254.0.22:255.255.255.252:instance:eth0:off:tap0"));
        assert!(args.contains("reboot=k panic=1"));
    }
}
