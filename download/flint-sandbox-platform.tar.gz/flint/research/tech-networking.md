# Networking Patterns for microVM Fleets (R4 research)

Sources: Firecracker docs (network-setup.md, design.md, network-for-clones.md, network-performance.md), E2B runtime source `packages/orchestrator/pkg/sandbox/network/*` + ARCHITECTURE.md, Cloudflare "Virtual networking 101: TAP" blog.

## 1. The base primitive: one TAP per VM

Firecracker emulated NICs (virtio-net) are backed by **TAP devices on the host**; FC only does L2 Ethernet frames between the guest virtio ring and `write()/read()` on the TAP fd. No DHCP server built in, no switch, no multi-queue (`docs/network-setup.md`: "only TUN/TAP backend, no multiqueue"). You must: create the TAP, assign IPs, route, NAT. All guest egress is untrusted — **Firecracker does zero traffic filtering**; enforce at host (nftables).

Minimal NAT setup per FC docs:
```bash
ip tuntap add tap0 mode tap
ip addr add 172.16.0.1/30 dev tap0 && ip link set tap0 up
sysctl net.ipv4.ip_forward=1
nft add table firecracker
nft 'add chain firecracker postrouting { type nat hook postrouting priority srcnat; policy accept; }'
nft 'add chain firecracker filter { type filter hook forward priority filter; policy accept; }'
nft add rule firecracker postrouting ip saddr 172.16.0.2 oifname eth0 counter masquerade
nft add rule firecracker filter iifname tap0 oifname eth0 accept
```
Three routing archetypes (network-setup.md): **NAT** (simple, no LAN exposure), **bridge** (guest on LAN via br0), **namespaced NAT** (per-VM netns — needed for snapshot clones, some perf cost).

## 2. E2B's production design (read from source, `pkg/sandbox/network/`)

Per-sandbox **"slot"** = pre-created pool of network plumbing (pooled & recycled; slot idx allocated locally per node):

- **Named network namespace** per slot: `netns.NewNamed(s.NamespaceID())` (e.g. `/var/run/netns/<ns-id>`); passed to jailer via `--netns`. Startup "reclaim" tears down stale namespaces from previous runs.
- **veth pair**: host end `vethX` in host netns with a **/32 host IP from 10.11.0.0/16** (slot idx → `10.11.X.Y`); peer `vpeerX` stays in the sandbox netns with a **/31 from 10.12.0.0/16** (`vpeer = idx*2`, `veth = idx*2+1` — `GetIndexedIP` math; 32-2-15 = 32768 slots max). Default route in the netns → veth host end (gateway).
- **TAP `tap0` inside the sandbox netns**, `169.254.0.22/30`, **fixed guest MAC `02:FC:00:00:00:05`** and **fixed host-side TAP MAC `02:FC:00:00:00:06` shared by all slots** — so a resumed/snapshot-rested guest's ARP cache for the gateway still resolves (comment in source: "Keep resumed guests' cached gateway ARP entries valid").
- **Guest static IP via kernel cmdline** (no DHCP!): `ip=169.254.0.21::169.254.0.22:255.255.255.252:instance:eth0:off:tap0` → guest eth0 = 169.254.0.21/30, gw = TAP. Host reaches guest at slot HostIP (10.11.x.y) via NAT; orchestrator's per-node sandbox proxy (:5007) forwards to `http://slotIP:port`.
- **iptables NAT** in each netns (MASQUERADE from the /30 to the vpeer) + host-level MASQUERADE of the /31 blocks upstream; **per-slot nftables egress firewall**: table `slot-firewall` (inet family), filter chain at **PREROUTING** priority -150, with `nftables` **sets** `filtered_always_allowlist` / `filtered_always_denylist` / `filtered_allowlist` / `filtered_denylist` (TypeIPAddr) for IP-level policy.
- **Domain-level (SNI/Host) allow-deny**: userspace **TCP proxy** (`pkg/tcpfirewall`) that peeks TLS ClientHello SNI / HTTP Host (via `inetaf/tcpproxy`), matches the hostname against policy, then dials upstream (30 s timeout, DSCP marking via `IP_TOS`/`IPV6_TCLASS`). HTTP/HTTPS outgoing from guests is thus filterable by domain without MITM certs (only SNI, not encrypted DNS/ESNI/ECH).
- **Edge routing for ingress**: wildcard DNS `https://<port>-<sandboxID>.<domain>` → client-proxy (port 3002) → Redis routing record `sandbox:routing:{id}` (JSON: `orchestrator_id, orchestrator_ip, execution_id, sandbox_started_at, sandbox_max_length_in_hours`, TTL = max sandbox length, written by orchestrator on MarkRunning, guarded delete via Lua on execution_id) → node's orchestrator proxy :5007 (per-sandbox access token checked) → `slotIP:port`.
- **MMDS rides eth0**: `PUT /mmds/config {network_interfaces:["eth0"]}` — guest route `169.254.169.254 dev eth0`. Works because MMDS is intercepted in the device model, never hits the wire.

Scaling notes: a /16 host-side block supports ~65k slots/node; E2B notes private-range avoidance (`pool.go`: don't collide with `10.0.0.0/8, 172.16.0.0/12` in use elsewhere).

## 3. vsock vs TCP vs virtio-serial for the host<->guest agent channel

**Firecracker vsock** (docs/vsock.md + swagger): `PUT /vsock {"guest_cid": N, "uds_path": "./v.sock"}`; `guest_cid` **must be ≥ 3** (0=null, 1=local, 2=well-known "host" `VMADDR_CID_HOST`). Firecracker *bypasses vhost-vsock* and mediates AF_UNIX ↔ AF_VSOCK itself:

- **Host→guest**: FC **listens** on the UDS at `uds_path`. Host dials the UDS, sends ASCII `CONNECT <port>\n` (0x0A EOL); if guest has a listener on that AF_VSOCK port, FC replies `OK <host_port>\n` (host port is auto-assigned, e.g. 1073741824) and the UDS stream is now a byte pipe to the guest vsock port. No listener → host connection terminated.
- **Guest→host**: guest `connect(AF_VSOCK, cid=2, port=P)` → FC forwards to host UDS **`{uds_path}_P`** (e.g. `/path/v.sock_52`); host must be listening there or the guest gets `VIRTIO_VSOCK_OP_RST`.
- Constraints: pre-boot-only config, one vsock device per VM, ports are 32-bit (guest ephemeral range starts at 0x80000000... typically 1073741824+). Kernel needs `CONFIG_VIRTIO_VSOCKETS=y` guest, host `CONFIG_VHOST_VSOCK=m` (vhost not actually used by FC), guest check `ls /dev/vsock`.
- **CID allocation gotcha**: Firecracker does **not** auto-allocate CIDs and does not enforce global uniqueness — duplicate `guest_cid` across VMs "works" until two hosts' UDS meshes confuse clients; you must run your own CID allocator (per-node bitmap) if you ever route vsock across hosts. Since FC's host side is a UDS *per VM*, CID only matters inside the guest, which is why E2B simply doesn't need vsock at all.
- **vs TCP-over-TAP**: TCP needs a configured network (IP, routes, MTU, firewall holes) before the agent is reachable, and shares fate with the user's netns (a guest firewall rule or `ifdown` kills your control channel). vsock has no IP stack dependency (works before net config), is connection-oriented and multiplexed by port, and survives guest network misconfig — ideal for **bootstrap/control** (get agent up, push net config). E2B uses slot-IP TCP (:49983) for the agent because routing/ingress needs real networking anyway, and one channel simplifies ingress + auth; the orchestrator talks to envd over the host netns at slot IP (control routes `/init`, `/upgrade` are blocked from the public proxy by spec-marking `x-internal: true`).
- **vs virtio-serial (virtconsole)**: single byte stream, no ports, flow control is coarse; used by FC only for the serial console. Kata/others use virtio-serial + `vsock` hybrid; vsock is strictly better for structured channels. Cloud Hypervisor/libkrun (microsandbox) also default to vsock.
- Recommendation for our platform: **vsock (AF_VSOCK CID 3+, port 5252 for control RPC) for bootstrap + exec channel**, with UDS-per-VM on host (`/run/flint/<vm-id>/v.sock`), CONNECT-handshake framing documented; TCP on the TAP for user-facing ingress.

## 4. IPAM for fleets

- **Per-node slot model** (E2B): deterministic IPs from slot index (host /16 + vrt /16, 2 addresses per slot /31); state lives in the netns itself → reconciliation = enumerate `ip netns`. No central IPAM for ephemeral nets; node-local reuse, no cross-node routability for guest link-local (all NAT'd at node edge). This is "IPAM-free by design" — the only globally-routable identity is `sandboxID → node IP` in Redis.
- Alternatives: DHCP per netns (slow, stateful), one bridge per VM + containers-style veth (Kubernetes CNI-like), or host-local ranges with per-node assignment from a control-plane allocator if you want flat L2 fabric routing (FC docs discussion #4720 pattern: DNAT ingress `iptables -t nat -A PREROUTING -i veth0 -d <clone-addr> -j DNAT --to <guest-ip>` + host route `ip route add <clone-addr> via <veth-ip>`).
- MTU/perf: TAP+virtio-net adds ~12 bytes L2 overhead (frame = 1514 off-wire); set `mtu` on the interface config (VIRTIO_NET_F_MTU) to match your fabric if you tunnel (E2B doesn't override; watch for VXLAN/Geneve → use 1450-1480 inside guests). Firecracker net perf doc: single-queue limitation, one vCPU busy-polling TAP at high pps; rx/tx rate limiters + IRQ steering via `--cgroup cpuset` pinning recommended. Disable GRO/TSO tuning needs; measure with `iperf3`, expect ~ several Gbit/s virtio-net.
