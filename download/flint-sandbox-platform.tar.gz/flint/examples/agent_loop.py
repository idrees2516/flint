#!/usr/bin/env python3
"""
Flint agent example: a coding-agent loop in the style of platform sandboxes
(E2B/Daytona) — write code, run it, read output, fix, re-run; long-lived
state persists across pauses because every write is journaled.

Usage:
  export FLINT_URL=http://127.0.0.1:8080 FLINT_API_KEY=...
  python3 agent_loop.py
"""

import json
import os
import sys
import urllib.request

BASE = os.environ.get("FLINT_URL", "http://127.0.0.1:8080")
KEY = os.environ["FLINT_API_KEY"]


def call(method: str, path: str, body=None, raw: bytes | None = None):
    req = urllib.request.Request(BASE + path, method=method)
    req.add_header("Authorization", f"Bearer {KEY}")
    data = None
    if raw is not None:
        data = raw
    elif body is not None:
        data = json.dumps(body).encode()
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, data) as resp:
            text = resp.read()
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as e:
        raise SystemExit(f"HTTP {e.code} on {method} {path}: {e.read().decode()}")


def main():
    # 1. Long-running sandbox for this agent session.
    sbx = call("POST", "/v1/sandboxes", {"vm": {"vcpu_count": 2, "mem_mib": 2048}})
    sid = sbx["id"]
    print(f"sandbox: {sid}")

    def exec_sh(cmd: str):
        r = call("POST", f"/v1/sandboxes/{sid}/exec",
                 {"spec": {"cmd": ["sh", "-c", cmd], "timeout_ms": 60000}})
        return r["exit_code"], r.get("stdout", "")

    def write_file(path: str, content: str):
        call("PUT", f"/v1/sandboxes/{sid}/files?path={path}", raw=content.encode())

    try:
        # 2. Write AI-generated code (journaled → survives crashes/pauses).
        write_file("/app/fib.py", "def fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\nprint([fib(i) for i in range(10)])\n")
        code, out = exec_sh("python3 /app/fib.py")
        print(out.strip())
        assert code == 0 and "34" in out  # fib(9) == 34

        # 3. Debug loop: write, run, read output, fix.
        write_file("/app/upper.py", "print('hello'.upper())\n")
        _, out = exec_sh("python3 /app/upper.py && ls /app")
        print(out.strip())

        # 4. Research through the brokered tool gateway (no guest egress needed).
        try:
            results = call("POST", "/v1/tools/web_search", {"query": "rust sandbox platforms", "num": 3})
            for r in results.get("results", []):
                print("  *", r["title"])
        except SystemExit as e:
            print(f"  (web search unavailable: {e})")

        # 5. Pause — snapshot + layers uploaded; resume preserves everything.
        call("POST", f"/v1/sandboxes/{sid}/pause")
        print("paused (storage-only billing)")
        call("POST", f"/v1/sandboxes/{sid}/resume")
        _, out = exec_sh("cat /app/fib.py | head -2")
        print("post-resume state:", out.strip().splitlines()[0])

        # 6. Branch the sandbox for best-of-N exploration.
        fork = call("POST", f"/v1/sandboxes/{sid}/fork", {"count": 2})
        print("forks:", [f["id"] for f in fork["forks"]])
        for f in fork["forks"]:
            call("DELETE", "/v1/sandboxes/" + f["id"])
    finally:
        call("DELETE", f"/v1/sandboxes/{sid}")
        print("cleaned up")


if __name__ == "__main__":
    sys.exit(main())
