//! The platform error model: one enum, stable machine codes, HTTP mapping.

use thiserror::Error;

pub type Result<T> = std::result::Result<T, FlintError>;

#[derive(Debug, Error)]
pub enum FlintError {
    #[error("resource not found: {resource} {id}")]
    NotFound { resource: &'static str, id: String },

    #[error("invalid state transition: {from} -> {to}")]
    InvalidState { from: String, to: String },

    #[error("invalid parameter: {msg}")]
    InvalidParam { msg: String },

    #[error("unauthenticated: {msg}")]
    Unauthenticated { msg: String },

    #[error("forbidden: {msg}")]
    Forbidden { msg: String },

    #[error("rate limited, retry after {retry_after_ms}ms")]
    RateLimited { retry_after_ms: u64 },

    #[error("quota exceeded: {quota}")]
    QuotaExceeded { quota: String },

    #[error("resource exhausted: {msg}")]
    ResourceExhausted { msg: String },

    #[error("operation timed out after {ms}ms: {op}")]
    Timeout { op: String, ms: u64 },

    #[error("sandbox worker unavailable: {msg}")]
    Unavailable { msg: String },

    #[error("conflict: {msg}")]
    Conflict { msg: String },

    #[error("internal error: {0}")]
    Internal(String),
}

impl FlintError {
    /// Stable machine-readable code (used by REST, gRPC and WS alike).
    pub fn code(&self) -> &'static str {
        match self {
            Self::NotFound { .. } => "not_found",
            Self::InvalidState { .. } => "invalid_state",
            Self::InvalidParam { .. } => "invalid_param",
            Self::Unauthenticated { .. } => "unauthenticated",
            Self::Forbidden { .. } => "forbidden",
            Self::RateLimited { .. } => "rate_limited",
            Self::QuotaExceeded { .. } => "quota_exceeded",
            Self::ResourceExhausted { .. } => "resource_exhausted",
            Self::Timeout { .. } => "timeout",
            Self::Unavailable { .. } => "unavailable",
            Self::Conflict { .. } => "conflict",
            Self::Internal(_) => "internal",
        }
    }

    /// Default HTTP status for the REST surface.
    pub fn http_status(&self) -> u16 {
        match self {
            Self::NotFound { .. } => 404,
            Self::InvalidState { .. } => 409,
            Self::InvalidParam { .. } => 400,
            Self::Unauthenticated { .. } => 401,
            Self::Forbidden { .. } => 403,
            Self::RateLimited { .. } => 429,
            Self::QuotaExceeded { .. } => 429,
            Self::ResourceExhausted { .. } => 503,
            Self::Timeout { .. } => 504,
            Self::Unavailable { .. } => 503,
            Self::Conflict { .. } => 409,
            Self::Internal(_) => 500,
        }
    }
}

impl From<std::io::Error> for FlintError {
    fn from(e: std::io::Error) -> Self {
        Self::Internal(format!("io: {e}"))
    }
}

impl From<serde_json::Error> for FlintError {
    fn from(e: serde_json::Error) -> Self {
        Self::InvalidParam { msg: format!("bad json: {e}") }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn codes_and_statuses_are_stable() {
        let e = FlintError::NotFound { resource: "sandbox", id: "sbx_x".into() };
        assert_eq!(e.code(), "not_found");
        assert_eq!(e.http_status(), 404);
    }
}
