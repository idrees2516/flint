# E2B (e2b.dev) — Research Report

*Researched: Task R1, general-purpose research agent. Sources: e2b.dev, docs.e2b.dev, github.com/e2b-dev/runtime (formerly e2b-dev/infra), third-party comparisons.*

## Overview

E2B ("Environment to Binary") is the pioneer and de-facto category leader of cloud sandboxes for AI-generated code. Founded by the DevBook team (Vasek Mlejnko, Miloš Živković) after they gave a GPT-3.5 agent tools to run code inside their old sandbox product. Positioning today: **"The Enterprise AI Agent Cloud"** — claims use by 94% of Fortune 100 companies for frontier agentic workflows. The product is a fleet of short-lived, hardware-isolated Linux VMs ("sandboxes") that AI agents create, control, and destroy via SDKs (Python, JS/TS) or REST. E2B is used as the execution backend for agent frameworks (OpenAI Agents SDK, Pydantic AI, Mastra, LangChain, CrewAI, NVIDIA NeMo Gym, Rivet, etc.) and claims massive scale: ~600k sandboxes/day for one customer (Arena), a benchmark of 100k+ *concurrent* sandboxes with 100% success, tens of millions of sandboxes launched lifetime.

## Isolation & Architecture

- **One Firecracker microVM per sandbox**, each in its own cgroup + network namespace, with a per-sandbox nftables egress firewall (SNI/Host-inspecting domain allow/deny lists). Dedicated kernel per sandbox, custom memory + snapshot layer. ~5 MB hypervisor overhead per microVM; default 1–2 vCPU, 512MB–2GiB RAM.
- Core design idea #1: **"A sandbox is a resumed snapshot."** Templates are *pre-booted* VM snapshots (memory + disk + VM state) stored in object storage (S3/GCS). Creating a sandbox = restoring a snapshot, not booting a kernel. Memory pages are served **lazily on page-fault via userfaultfd (UFFD)**; rootfs is a **copy-on-write overlay** over a read-only template image exposed as an NBD block device served by an in-process userspace NBD server. Only touched data is fetched. Cold start ≈ **150 ms** (third-party tests; LogRocket benchmarks report 717ms create-to-first-response for some workloads).
- Core design idea #2: **Control plane and data plane never mix.** Control-plane API decides *where* a sandbox runs (placement, best-of-K node sampling scored on CPU load and hugepage-pool load); a per-node **orchestrator** (Go, root) owns *how* it runs (Firecracker process, netns, block device, cgroup). Sandbox traffic goes edge → node directly, never through the API.
- Services (all open source, Apache-2.0, Go): `api` (REST control plane, Gin + OpenAPI), `orchestrator` (per-node, gRPC :5008, also template-manager role on build nodes), `client-proxy` (edge router :3002 for `https://<port>-<sandboxID>.<domain>` URLs), `envd` (in-VM agent), `dashboard-api`. State: **PostgreSQL** (templates, builds, snapshots, teams), **Redis** (running sandboxes + routing catalog `sandbox:routing:{id}`), **ClickHouse** (events, metrics, logs), **object storage** (template + snapshot artifacts). Node discovery via Nomad, Kubernetes, or static list; Kubernetes is the supported distribution; E2B Embed packages the whole stack as docker-compose/Terraform/GCP/K8s manifest for single-machine self-hosting.

## API Surface

- **REST control plane** (`/v3/sandboxes` etc.): create/list/kill/pause/resume/connect/timeout/metrics/logs; templates & builds; volumes; API keys; secrets; sandbox events & webhooks. Auth via `X-API-Key` (`e2b_` prefix) or OIDC JWTs. Per-team Redis-backed rate limits (429 + Retry-After). OpenAPI served at `/openapi.json`.
- **envd** — the in-VM agent (chi + Connect RPC on :49983): **Process service** (start/list/connect processes, stream stdout/stderr, stdin, signals, **PTYs**), **Filesystem service** (stat/list/make/move/remove/**watch**), REST endpoints `/health /metrics /envs /files` (upload/download), `/init` (orchestrator pushes env vars, access token, metadata after boot/resume), `/upgrade` (live self-upgrade). Auth: `X-Access-Token` delivered via Firecracker MMDS; signed URLs for file endpoints.
- SDK model: `Sandbox.create()` → `sandbox.commands.run()` (foreground or `background: true`), `sandbox.files.*`, `sandbox.run_code()` (code interpreter with onStdout/onStderr streaming callbacks), `sandbox.ports`, `sandbox.pause() / .resume()`, `sandbox.fork()`, `sandbox.set_timeout()`. Streaming is callback-based in SDKs (WebSocket under the hood via the client-proxy/orchestrator proxy chain).
- **Sandbox URLs**: `https://<port>-<sandboxID>.<domain>` reaches *any port a process opens* (envd port-scans and forwards), with per-sandbox access tokens — huge for previewing agent-built apps.

## Persistence & Lifecycle

- Lifecycle states: **created → running → paused → (resumed | killed)**, plus checkpoint/fork. Docs: https://docs.e2b.dev/sandbox, /sandbox/persistence, /sandbox/auto-resume, /sandbox/snapshots.
- **Timeout**: every sandbox has a timeout (default 5 min, configurable to **24h Pro / 1h Hobby**); SDK methods like `keep_alive` reset it.
- **Auto-pause on timeout expiry**: preserves full VM state. A **paused sandbox is kept indefinitely** — no TTL, never auto-deleted. **Auto-resume on request**: when SDK/traffic hits a paused sandbox, it wakes transparently (client-proxy calls `ResumeSandbox` gRPC and retries). Auto-resume timeout = max(5 min, sandbox timeout).
- **Pause mechanics** (deep detail from ARCHITECTURE.md): pause snapshots the VM, diffs memory (dirty-page tracking) and rootfs (COW cache) against the template, caches locally, uploads async to object storage with retry budget. 80-second pause budget, 95s Redis transition TTL. Optional *deferred rootfs export* moves the rootfs-diff off the pause critical path (eject COW cache, seal to reflink diff in background).
- **Resume** prefers the **origin node** (local snapshot cache → no object-storage reads). Same fast path as create. Third-party figures: ~4s per GB RAM to pause, ~1s resume (Novita's compatible offering).
- **Checkpoint/Fork**: `Checkpoint` = pause+resume-in-place (persist state while running). **Fork** checkpoints a live sandbox and spawns up to **100 new sandboxes from that snapshot** while the original keeps running — killer feature for RL rollouts and parallel agent branches.
- **Filesystem-only snapshot** (`memory: false`): rootfs only, no memfile — sandboxes from it cold-boot; used as a rescue when memory state is unusable, and as degradation when auto-pause is refused too long (120s overstay budget → degrade to fs-only so eviction isn't blocked).
- **Crash behavior**: cold-boot of non-quiesced rootfs runs jailed `e2fsck -p -E journal_only` (journal replay only) before VM start — bounded cost, never condemns the snapshot (all failures retryable).
- Known bug: file changes occasionally not persisted across pause/resume cycles (GitHub issue #884 on e2b-dev/E2B).

## Agent-Specific Features

- Background processes (`background: true` on commands.run) that outlive the calling connection; PTY/terminal streams (basis for interactive terminals & the open-source **E2B Desktop** computer-use sandbox at github.com/e2b-dev/desktop).
- Env vars at create + per-execution; **E2B Secrets** — secrets stored as runtime *markers*; the control plane never sees values; resolved at sandbox egress by orchestrator-ee. **Workload identity**: short-lived tokens per sandbox without the API minting credentials.
- **MCP Gateway**: run MCP servers inside the sandbox, expose via `sandbox.getMcpUrl()` (Streamable HTTP) — agents get a sandbox-scoped tool ecosystem; templates can prepull MCP server images.
- Persistent **volumes** that outlive sandboxes (token-authed volume-content API); per-sandbox public URLs; sandbox events + **webhooks** for lifecycle; OpenTelemetry everywhere; live in-VM agent upgrade via `syscall.Exec` with same PID (carries workload stdio/PTY fds, process table, watchers forward — no workload disruption).

## Pricing & Limits

- Usage-based: **$0.000014/vCPU/s ($0.0504/vCPU-hr)** + **$0.0000045/GiB/s ($0.0162/GiB-hr)** + storage (first 5GB free). Hobby: free, $100 one-time credit, 20 concurrent sandboxes, 1h max session. Pro: $150/mo, 500 hrs/mo included, 100–1,100 concurrent, 24h max session. Enterprise custom (dedicated VPC deployment). Billing pauses while sandbox paused (only storage billed).

## Open-Source & Engineering Notes

- **github.com/e2b-dev/runtime** — the complete backend (Apache-2.0, Go). Renamed from `infra`. Includes `docs/ARCHITECTURE.md` (exceptional, sequence diagrams). https://github.com/e2b-dev/runtime
- **github.com/e2b-dev/E2B** — SDKs + CLI (JS, Python). https://github.com/e2b-dev/E2B
- **github.com/e2b-dev/desktop**, **e2b-dev/custom-desktop**, **e2b-dev/e2b-cookbook**.
- Blog: e2b.dev/resources (Firecracker vs QEMU, Introducing Build System 2.0 — Dockerfile-free template builds, E2B Embed, E2B Secrets).

## Lessons for a Rust Implementation

1. **Make creation = snapshot restore.** Pre-boot VM templates + lazy UFFD memory paging + COW rootfs overlay is *the* trick behind 150ms cold starts. A Rust platform should build userfaultfd + userspace NBD/loop devices as first-class subsystems.
2. **Pause = diff, not copy.** Dirty-page memory diff + COW block diff against the template keep snapshots small and pauses fast; async upload with retry budget keeps the critical path short.
3. **Origin-node affinity on resume** (local snapshot cache) is a big latency win — placement should prefer cached nodes.
4. **Strict control/data plane separation**: API never proxies sandbox bytes; edge router + per-node proxy with a Redis routing catalog enables transparent auto-resume on traffic.
5. **In-VM agent (envd-equivalent) with Connect-RPC process/PTY/fs services + versioned live upgrade** is what makes sandboxes SDK-friendly; design its protocol early, gate features on agent version.
6. Lifecycle states to model: `Created, Running, Paused, Resuming, Killed`, plus transitions: timeout → auto-pause, traffic → auto-resume, checkpoint-in-place, fork-from-checkpoint, fs-only degrade path.
7. Fleet-level concerns E2B solved that a Rust clone must too: node drain semantics (Draining vs ShuttingDown), placement best-of-K with backoff on ResourceExhausted, disk-headroom admission for pauses, template cache pinning, sandbox URL wildcard routing, OTel/ClickHouse observability.

**Most differentiating idea:** *sandboxes as lazily-restored snapshots with transparent pause/auto-resume and live forking (up to 100 forks from a running sandbox)* — the "serverless VM" semantics.
