//! `OpsCore` — the gateway's handler core shared by REST, gRPC and WS.

use crate::auth::{Auth, EventBus};
use crate::worker_rpc::WorkerRpcPool;
use flint_core::{
    can_transition, DriverKind, ExecSpec, FlintError, Result, SandboxCreateSpec, SandboxState,
    TimeoutPolicy,
};
use flint_proto::fleet::StartSandboxRequest;
use flint_scheduler::{PlaceRequest, Scheduler};
use flint_store::{
    build_object_store, MetaStore, SandboxRow, SnapshotRow, TemplateRow,
};
use flint_tools::ToolGateway;
use serde_json::{json, Value};
use std::sync::Arc;

pub struct Gateway {
    pub cfg: flint_core::config::GatewayConfig,
    pub store: Arc<MetaStore>,
    pub auth: Auth,
    pub scheduler: Arc<Scheduler>,
    pub workers: WorkerRpcPool,
    pub tools: Arc<ToolGateway>,
    pub objects: Arc<dyn flint_store::ObjectStore>,
    pub events: Arc<EventBus>,
    pub objects_local: bool,
}

impl Gateway {
    pub fn new(cfg: flint_core::config::GatewayConfig, store: Arc<MetaStore>) -> Result<Arc<Self>> {
        let auth = Auth::new(store.clone(), cfg.limits.clone());
        let scheduler = Arc::new(Scheduler::new(cfg.scheduler.placement_k));
        let tools = Arc::new(ToolGateway::from_config(&cfg.tools));
        let objects = build_object_store(&cfg.object_store)?;
        Ok(Arc::new(Self {
            objects_local: cfg.object_store.kind == "local",
            cfg,
            store,
            auth,
            scheduler,
            workers: WorkerRpcPool::new(),
            tools,
            objects,
            events: Arc::new(EventBus::default()),
        }))
    }

    // ----- api keys -----

    pub fn bootstrap_key(&self) -> Result<Option<String>> {
        let keys = self.store.list_api_keys()?;
        if !keys.is_empty() {
            return Ok(None);
        }
        if let Ok(pinned) = std::env::var("FLINT_BOOTSTRAP_API_KEY") {
            let row = flint_store::ApiKeyRow {
                key_id: flint_core::ids::new_id(flint_core::ids::prefixes::API_KEY),
                name: "bootstrap".into(),
                secret_hash: flint_core::tokens::hash_api_key(&pinned),
                quotas: Default::default(),
                created_at_ms: flint_core::util::now_ms(),
                revoked: false,
            };
            self.store.upsert_api_key(&row)?;
            return Ok(None); // known to the operator already
        }
        let (key_id, secret) = flint_core::tokens::generate_api_key();
        let row = flint_store::ApiKeyRow {
            key_id,
            name: "bootstrap (shown once)".into(),
            secret_hash: flint_core::tokens::hash_api_key(&secret),
            quotas: Default::default(),
            created_at_ms: flint_core::util::now_ms(),
            revoked: false,
        };
        self.store.upsert_api_key(&row)?;
        Ok(Some(secret))
    }

    pub fn create_key(&self, name: &str) -> Result<(String, String)> {
        let (key_id, secret) = flint_core::tokens::generate_api_key();
        let row = flint_store::ApiKeyRow {
            key_id,
            name: name.into(),
            secret_hash: flint_core::tokens::hash_api_key(&secret),
            quotas: Default::default(),
            created_at_ms: flint_core::util::now_ms(),
            revoked: false,
        };
        self.store.upsert_api_key(&row)?;
        Ok((row.key_id, secret))
    }

    // ----- sandboxes -----

    pub async fn create_sandbox(&self, key_id: &str, spec: SandboxCreateSpec) -> Result<Value> {
        self.auth.enforce_sandbox_quota(&flint_store::ApiKeyRow {
            key_id: key_id.into(),
            name: String::new(),
            secret_hash: String::new(),
            quotas: Default::default(),
            created_at_ms: 0,
            revoked: false,
        })?;

        // Resolve template.
        let (template, restore_manifest, restore_snap_id) = match &spec.template_id {
            Some(tid) => {
                let tpl = self
                    .store
                    .get_template(tid)?
                    .ok_or(FlintError::NotFound { resource: "template", id: tid.clone() })?;
                let snap = self
                    .store
                    .get_snapshot(&tpl.base_snapshot_id)?
                    .ok_or(FlintError::NotFound { resource: "template snapshot", id: tpl.base_snapshot_id.clone() })?;
                let manifest: flint_journal::SnapshotManifest =
                    serde_json::from_str(&snap.manifest_json)?;
                (Some(tpl), Some(manifest), Some(snap.id))
            }
            None => (None, None, None),
        };

        // Place.
        let node = self
            .scheduler
            .place(&PlaceRequest {
                vcpu: spec.vm.vcpu_count,
                mem_mib: spec.vm.mem_mib,
                reserve_pause_headroom: true,
                driver_kind: String::new(),
            })
            .map_err(|e| {
                tracing::warn!(error = %e, "placement failed");
                e
            })?;
        let worker = self
            .scheduler
            .get(&node)
            .ok_or(FlintError::ResourceExhausted { msg: "worker vanished during placement".into() })?;

        // Store row (Creating).
        let id = flint_core::ids::new_id(flint_core::ids::prefixes::SANDBOX);
        let now = flint_core::util::now_ms();
        let row = SandboxRow {
            id: id.clone(),
            key_id: key_id.to_string(),
            project: spec.project.clone(),
            template_id: spec.template_id.clone(),
            state: SandboxState::Creating.as_str().into(),
            vm: spec.vm,
            env: spec.env.clone(),
            metadata: spec.metadata.clone(),
            timeouts: spec.timeouts.clone(),
            worker_addr: Some(worker.addr.clone()),
            worker_node_id: Some(worker.node_id.clone()),
            current_snapshot_id: restore_snap_id.clone(),
            created_at_ms: now,
            last_activity_ms: now,
            last_pause_ms: None,
            usage_active_ms: 0,
            usage_paused_ms: 0,
            tool_calls_today: 0,
            tool_calls_day_start_ms: 0,
            deleted: false,
        };
        self.store.upsert_sandbox(&row)?;
        self.store.set_route(&id, &worker.node_id, &worker.addr, (self.cfg.scheduler.routing_ttl_s * 1000) as i64)?;

        // Worker start (restore from the template snapshot = create path).
        let agent_token = flint_core::ids::new_id("tok");
        let start = StartSandboxRequest {
            sandbox_id: id.clone(),
            template_snapshot_id: template.as_ref().map(|t| t.base_snapshot_id.clone()).unwrap_or_default(),
            vcpu_count: spec.vm.vcpu_count,
            mem_mib: spec.vm.mem_mib,
            disk_mib: spec.vm.disk_mib,
            env: spec.env.clone().into_iter().collect(),
            timeouts_json: serde_json::to_string(&spec.timeouts)?,
            driver_kind: format!("{:?}", spec.driver.unwrap_or(DriverKind::Process)).to_lowercase(),
            agent_token,
            egress_policy_json: String::new(),
            restore_snapshot_id: restore_snap_id.unwrap_or_default(),
            restore_manifest_json: restore_manifest
                .map(|m| serde_json::to_string(&m))
                .transpose()?
                .unwrap_or_default(),
        };
        if let Err(e) = self.workers.start_sandbox(&worker.addr, start).await {
            let _ = self.store.set_sandbox_state(&id, SandboxState::Error);
            let _ = self.store.delete_route(&id);
            return Err(e);
        }
        self.store.set_sandbox_state(&id, SandboxState::Running)?;
        self.store.touch_sandbox_activity(&id, flint_core::util::now_ms())?;
        self.events
            .publish(&id, json!({ "type": "state", "state": "running" }))
            .await;
        flint_core::metrics::counter_inc(flint_core::metrics::names::OPS_TOTAL, &[("op", "create".into()), ("result", "ok".into())]);
        Ok(self.sandbox_json(&self.store.get_sandbox(&id)?.unwrap()).await)
    }

    pub async fn sandbox_json(&self, row: &SandboxRow) -> Value {
        json!({
            "id": row.id,
            "state": row.state,
            "template_id": row.template_id,
            "project": row.project,
            "vm": row.vm,
            "env": row.env,
            "metadata": row.metadata,
            "timeouts": row.timeouts,
            "created_at": flint_core::util::iso8601(row.created_at_ms),
            "last_activity_at": flint_core::util::iso8601(row.last_activity_ms),
            "current_snapshot_id": row.current_snapshot_id,
            "usage": {
                "active_ms": row.usage_active_ms,
                "paused_ms": row.usage_paused_ms,
            },
        })
    }

    pub fn get_sandbox_row(&self, key_id: &str, id: &str) -> Result<SandboxRow> {
        let row = self
            .store
            .get_sandbox(id)?
            .ok_or(FlintError::NotFound { resource: "sandbox", id: id.to_string() })?;
        if row.key_id != key_id {
            // Don't leak existence across tenants.
            return Err(FlintError::NotFound { resource: "sandbox", id: id.to_string() });
        }
        Ok(row)
    }

    /// Resolve a sandbox to a live worker addr, auto-resuming (wake-on-
    /// traffic) when paused and the policy allows it.
    pub async fn route(&self, key_id: &str, id: &str) -> Result<(SandboxRow, String)> {
        let mut row = self.get_sandbox_row(key_id, id)?;
        let addr = row.worker_addr.clone().unwrap_or_default();
        if addr.is_empty() {
            return Err(FlintError::Unavailable { msg: "sandbox has no worker".into() });
        }
        let state: SandboxState = serde_json::from_value(json!(row.state.clone())).unwrap_or(SandboxState::Error);
        if state == SandboxState::Paused && row.timeouts.wake_on_request {
            tracing::info!(sandbox = %id, "wake-on-request: resuming");
            self.workers.resume_sandbox(&addr, id).await?;
            self.store.set_sandbox_state(id, SandboxState::Running)?;
            row.state = SandboxState::Running.as_str().into();
        }
        self.store.touch_sandbox_activity(id, flint_core::util::now_ms())?;
        Ok((row, addr))
    }

    async fn lifecycle(
        &self,
        key_id: &str,
        id: &str,
        action: &str,
    ) -> Result<Value> {
        let row = self.get_sandbox_row(key_id, id)?;
        let cur: SandboxState =
            serde_json::from_value(json!(row.state.clone())).unwrap_or(SandboxState::Error);
        let addr = row.worker_addr.clone().unwrap_or_default();
        let (next, snap_id) = match action {
            "pause" => {
                if !can_transition(cur, SandboxState::Pausing) {
                    return Err(FlintError::InvalidState { from: row.state.clone(), to: "pausing".into() });
                }
                let snap = self.workers.pause_sandbox(&addr, id).await?;
                (SandboxState::Paused, snap)
            }
            "resume" | "start" => {
                let target = if action == "start" { SandboxState::Creating } else { SandboxState::Resuming };
                if !can_transition(cur, target) && cur != SandboxState::Stopped {
                    return Err(FlintError::InvalidState { from: row.state.clone(), to: action.into() });
                }
                if action == "start" {
                    // Restart from stopped: worker respawns + replays.
                    self.workers.resume_sandbox(&addr, id).await?;
                } else {
                    self.workers.resume_sandbox(&addr, id).await?;
                }
                (SandboxState::Running, row.current_snapshot_id.clone().unwrap_or_default())
            }
            "stop" => {
                if !can_transition(cur, SandboxState::Stopping) {
                    return Err(FlintError::InvalidState { from: row.state.clone(), to: "stopping".into() });
                }
                let keep = true; // disk-preserving stop
                let snap = self.workers.stop_sandbox(&addr, id, keep).await?;
                (SandboxState::Stopped, snap)
            }
            _ => return Err(FlintError::InvalidParam { msg: format!("unknown action {action}") }),
        };
        self.store.set_sandbox_state(id, next)?;
        if !snap_id.is_empty() {
            let mut r = self.store.get_sandbox(id)?.unwrap();
            r.current_snapshot_id = Some(snap_id.clone());
            self.store.upsert_sandbox(&r)?;
        }
        self.events
            .publish(id, json!({ "type": "state", "state": next.as_str() }))
            .await;
        let row = self.get_sandbox_row(key_id, id)?;
        Ok(self.sandbox_json(&row).await)
    }

    pub async fn pause(&self, k: &str, id: &str) -> Result<Value> {
        self.lifecycle(k, id, "pause").await
    }
    pub async fn resume(&self, k: &str, id: &str) -> Result<Value> {
        self.lifecycle(k, id, "resume").await
    }
    pub async fn start(&self, k: &str, id: &str) -> Result<Value> {
        self.lifecycle(k, id, "start").await
    }
    pub async fn stop(&self, k: &str, id: &str) -> Result<Value> {
        self.lifecycle(k, id, "stop").await
    }

    pub async fn delete_sandbox(&self, key_id: &str, id: &str) -> Result<Value> {
        let row = self.get_sandbox_row(key_id, id)?;
        if let Some(addr) = &row.worker_addr {
            let _ = self.workers.delete_sandbox_local(addr, id).await;
        }
        self.store.delete_route(id)?;
        let mut r = self.store.get_sandbox(id)?.unwrap();
        r.deleted = true;
        r.state = SandboxState::Deleted.as_str().into();
        self.store.upsert_sandbox(&r)?;
        self.events.publish(id, json!({ "type": "deleted" })).await;
        Ok(json!({ "id": id, "deleted": true }))
    }

    pub async fn snapshot(&self, key_id: &str, id: &str) -> Result<Value> {
        let row = self.get_sandbox_row(key_id, id)?;
        let addr = row.worker_addr.clone().unwrap_or_default();
        let snap_id = self.workers.snapshot_sandbox(&addr, id, "explicit").await?;
        self.upsert_snapshot_row(&snap_id, id, "explicit", 0).await?;
        let mut r = self.store.get_sandbox(id)?.unwrap();
        r.current_snapshot_id = Some(snap_id.clone());
        self.store.upsert_sandbox(&r)?;
        Ok(json!({ "snapshot_id": snap_id }))
    }

    async fn upsert_snapshot_row(&self, snap_id: &str, sandbox_id: &str, kind: &str, _size: u64) -> Result<()> {
        let manifest_key = format!("snapshots/{sandbox_id}/{snap_id}/manifest.json");
        let manifest = match self.objects.get(&manifest_key) {
            Ok(bytes) => String::from_utf8_lossy(&bytes).into_owned(),
            Err(_) => String::new(),
        };
        let row = SnapshotRow {
            id: snap_id.to_string(),
            sandbox_id: sandbox_id.to_string(),
            kind: kind.into(),
            manifest_json: manifest,
            size_b: 0,
            created_at_ms: flint_core::util::now_ms(),
            deleted: false,
        };
        self.store.upsert_snapshot(&row)?;
        Ok(())
    }

    pub async fn fork(&self, key_id: &str, id: &str, count: u32, keep_paused: bool) -> Result<Value> {
        let count = count.clamp(1, 16);
        let row = self.get_sandbox_row(key_id, id)?;
        // Cut a fork base snapshot from the current state.
        let addr = row.worker_addr.clone().unwrap_or_default();
        let was_paused = row.state == "paused";
        if !was_paused {
            let _ = self.workers.pause_sandbox(&addr, id).await?;
            self.store.set_sandbox_state(id, SandboxState::Paused)?;
        }
        let base_snap = self
            .store
            .get_sandbox(id)?
            .and_then(|r| r.current_snapshot_id.clone())
            .ok_or(FlintError::Internal(
                "no base snapshot for fork (pause the sandbox or snapshot it first)".into(),
            ))?;
        self.upsert_snapshot_row(&base_snap, id, "fork", 0).await?;

        let manifest = self
            .objects
            .get(&format!("snapshots/{id}/{base_snap}/manifest.json"))
            .ok()
            .and_then(|b| serde_json::from_slice::<flint_journal::SnapshotManifest>(&b).ok())
            .ok_or(FlintError::Internal("fork base manifest missing".into()))?;

        // Create N clones restoring from the base snapshot.
        let mut forks = Vec::new();
        for _ in 0..count {
            let spec = SandboxCreateSpec {
                template_id: row.template_id.clone(),
                project: row.project.clone(),
                vm: row.vm,
                env: row.env.clone(),
                metadata: {
                    let mut m = row.metadata.clone();
                    m.insert("forked_from".into(), id.to_string());
                    m
                },
                timeouts: row.timeouts.clone(),
                driver: None,
                start_paused: keep_paused,
            };
            // Direct create with restore override.
            match self.create_fork(key_id, &spec, &base_snap, &manifest).await {
                Ok(v) => forks.push(v),
                Err(e) => return Err(e),
            }
        }
        if !was_paused && !keep_paused {
            // Original returns to running after forking.
            let _ = self.workers.resume_sandbox(&addr, id).await;
            self.store.set_sandbox_state(id, SandboxState::Running)?;
        }
        Ok(json!({ "forks": forks, "snapshot_id": base_snap }))
    }

    async fn create_fork(
        &self,
        key_id: &str,
        spec: &SandboxCreateSpec,
        snap_id: &str,
        manifest: &flint_journal::SnapshotManifest,
    ) -> Result<Value> {
        // Same as create_sandbox but restoring from the fork base.
        let node = self.scheduler.place(&PlaceRequest {
            vcpu: spec.vm.vcpu_count,
            mem_mib: spec.vm.mem_mib,
            reserve_pause_headroom: true,
            driver_kind: String::new(),
        })?;
        let worker = self.scheduler.get(&node).ok_or(FlintError::ResourceExhausted {
            msg: "no worker for fork".into(),
        })?;
        let id = flint_core::ids::new_id(flint_core::ids::prefixes::SANDBOX);
        let now = flint_core::util::now_ms();
        let row = SandboxRow {
            id: id.clone(),
            key_id: key_id.to_string(),
            project: spec.project.clone(),
            template_id: spec.template_id.clone(),
            state: SandboxState::Creating.as_str().into(),
            vm: spec.vm,
            env: spec.env.clone(),
            metadata: spec.metadata.clone(),
            timeouts: spec.timeouts.clone(),
            worker_addr: Some(worker.addr.clone()),
            worker_node_id: Some(worker.node_id.clone()),
            current_snapshot_id: Some(snap_id.to_string()),
            created_at_ms: now,
            last_activity_ms: now,
            last_pause_ms: None,
            usage_active_ms: 0,
            usage_paused_ms: 0,
            tool_calls_today: 0,
            tool_calls_day_start_ms: 0,
            deleted: false,
        };
        self.store.upsert_sandbox(&row)?;
        self.store.set_route(&id, &worker.node_id, &worker.addr, (self.cfg.scheduler.routing_ttl_s * 1000) as i64)?;
        let start = StartSandboxRequest {
            sandbox_id: id.clone(),
            template_snapshot_id: String::new(),
            vcpu_count: spec.vm.vcpu_count,
            mem_mib: spec.vm.mem_mib,
            disk_mib: spec.vm.disk_mib,
            env: spec.env.clone().into_iter().collect(),
            timeouts_json: serde_json::to_string(&spec.timeouts)?,
            driver_kind: "process".into(),
            agent_token: flint_core::ids::new_id("tok"),
            egress_policy_json: String::new(),
            restore_snapshot_id: snap_id.to_string(),
            restore_manifest_json: serde_json::to_string(manifest)?,
        };
        self.workers.start_sandbox(&worker.addr, start).await?;
        self.store.set_sandbox_state(&id, SandboxState::Running)?;
        let row = self.get_sandbox_row(key_id, &id)?;
        Ok(self.sandbox_json(&row).await)
    }

    // ----- ops through the pipe -----

    pub async fn op(&self, key_id: &str, id: &str, kind: &str, payload: &Value) -> Result<Value> {
        let (_, addr) = self.route(key_id, id).await?;
        self.workers.op(&addr, id, kind, payload).await
    }

    pub async fn exec(&self, key_id: &str, id: &str, spec: &ExecSpec) -> Result<Value> {
        let op_id = flint_core::ids::new_id(flint_core::ids::prefixes::OP);
        self.op(key_id, id, "exec", &json!({ "spec": spec, "op_id": op_id })).await
    }

    pub async fn set_timeouts(&self, key_id: &str, id: &str, timeouts: &TimeoutPolicy) -> Result<Value> {
        let mut row = self.get_sandbox_row(key_id, id)?;
        row.timeouts = timeouts.clone();
        self.store.upsert_sandbox(&row)?;
        // Propagate to the worker via a control op (best-effort).
        let addr = row.worker_addr.clone().unwrap_or_default();
        let _ = self
            .workers
            .op(&addr, id, "timeouts.set", &json!({ "timeouts": timeouts }))
            .await;
        Ok(self.sandbox_json(&row).await)
    }

    pub async fn keepalive(&self, key_id: &str, id: &str) -> Result<Value> {
        self.store.touch_sandbox_activity(id, flint_core::util::now_ms())?;
        let row = self.get_sandbox_row(key_id, id)?;
        Ok(json!({ "id": id, "last_activity_at": flint_core::util::iso8601(row.last_activity_ms) }))
    }

    // ----- templates -----

    pub async fn create_template_from(&self, key_id: &str, sandbox_id: &str, name: &str) -> Result<Value> {
        let row = self.get_sandbox_row(key_id, sandbox_id)?;
        let addr = row.worker_addr.clone().unwrap_or_default();
        let snap_id = self.workers.snapshot_sandbox(&addr, sandbox_id, "template_base").await?;
        self.upsert_snapshot_row(&snap_id, sandbox_id, "template_base", 0).await?;
        let manifest = self
            .objects
            .get(&format!("snapshots/{sandbox_id}/{snap_id}/manifest.json"))
            .ok()
            .and_then(|b| serde_json::from_slice::<flint_journal::SnapshotManifest>(&b).ok())
            .ok_or(FlintError::Internal("template manifest missing".into()))?;
        let tpl = TemplateRow {
            id: flint_core::ids::new_id(flint_core::ids::prefixes::TEMPLATE),
            name: name.into(),
            key_id: key_id.to_string(),
            base_snapshot_id: snap_id.clone(),
            vm: row.vm,
            env: row.env.clone(),
            metadata: row.metadata.clone(),
            size_b: manifest.total_size_b(),
            created_at_ms: flint_core::util::now_ms(),
            deleted: false,
        };
        self.store.upsert_template(&tpl)?;
        Ok(json!({
            "id": tpl.id,
            "name": tpl.name,
            "base_snapshot_id": snap_id,
            "size_b": tpl.size_b,
            "created_at": flint_core::util::iso8601(tpl.created_at_ms),
        }))
    }

    pub fn list_templates(&self, key_id: &str) -> Result<Value> {
        let tpls: Vec<Value> = self
            .store
            .list_templates()?
            .into_iter()
            .filter(|t| t.key_id == key_id)
            .map(|t| {
                json!({
                    "id": t.id,
                    "name": t.name,
                    "base_snapshot_id": t.base_snapshot_id,
                    "vm": t.vm,
                    "size_b": t.size_b,
                    "created_at": flint_core::util::iso8601(t.created_at_ms),
                })
            })
            .collect();
        Ok(json!({ "templates": tpls }))
    }

    // ----- tools -----

    pub async fn web_search(&self, key: &flint_store::ApiKeyRow, query: &str, num: u32) -> Result<Value> {
        self.auth.enforce_tool_quota(key)?;
        let results = self.tools.web_search(query, num as usize)?;
        Ok(json!({ "query": query, "results": results }))
    }

    pub async fn http_fetch(&self, key: &flint_store::ApiKeyRow, url: &str) -> Result<Value> {
        self.auth.enforce_tool_quota(key)?;
        let r = self.tools.http_fetch(url)?;
        Ok(json!({ "url": url, "status": r.status, "content_type": r.content_type, "body_b64": r.body_b64, "size_b": r.size_b }))
    }

    // ----- usage -----

    pub fn usage(&self, key_id: &str) -> Result<Value> {
        let rows = self.store.list_sandboxes(Some(key_id), None, 1000)?;
        let mut active_ms = 0i64;
        let mut paused_count = 0u64;
        let mut running_count = 0u64;
        for r in &rows {
            match r.state.as_str() {
                "running" | "creating" | "resuming" => {
                    running_count += 1;
                    active_ms += flint_core::util::now_ms() - r.created_at_ms;
                }
                "paused" | "stopped" => {
                    paused_count += 1;
                    active_ms += r.last_activity_ms - r.created_at_ms;
                }
                _ => {}
            }
        }
        Ok(json!({
            "sandboxes_running": running_count,
            "sandboxes_hibernated": paused_count,
            "active_ms_total": active_ms,
            "tool_calls_today": self.store.tool_calls_today(key_id)?,
        }))
    }

    // ----- fleet (called by grpc_fleet) -----

    pub fn handle_report(&self, sandbox_id: &str, state: &str, snapshot_id: &str) -> String {
        if let Ok(Some(mut row)) = self.store.get_sandbox(sandbox_id) {
            row.state = state.to_string();
            if !snapshot_id.is_empty() {
                row.current_snapshot_id = Some(snapshot_id.to_string());
                let _ = self.upsert_snapshot_row_sync(snapshot_id, sandbox_id, "pause");
            }
            self.store.upsert_sandbox(&row).ok();
        }
        // Workers self-recover; the directive is advisory.
        "recover".into()
    }

    fn upsert_snapshot_row_sync(&self, snap_id: &str, sandbox_id: &str, kind: &str) -> Result<()> {
        let manifest_key = format!("snapshots/{sandbox_id}/{snap_id}/manifest.json");
        let manifest = match self.objects.get(&manifest_key) {
            Ok(b) => String::from_utf8_lossy(&b).into_owned(),
            Err(_) => String::new(),
        };
        self.store.upsert_snapshot(&SnapshotRow {
            id: snap_id.to_string(),
            sandbox_id: sandbox_id.to_string(),
            kind: kind.into(),
            manifest_json: manifest,
            size_b: 0,
            created_at_ms: flint_core::util::now_ms(),
            deleted: false,
        })?;
        Ok(())
    }

    pub fn restore_info(&self, sandbox_id: &str) -> Result<(String, String)> {
        let snap = self
            .store
            .latest_snapshot_for(sandbox_id)?
            .ok_or(FlintError::NotFound { resource: "snapshots for sandbox", id: sandbox_id.to_string() })?;
        Ok((snap.manifest_json, snap.id))
    }

    pub fn list_sandboxes_json(&self, key_id: &str, state: Option<SandboxState>, limit: usize) -> Result<Value> {
        let rows = self.store.list_sandboxes(Some(key_id), state, limit)?;
        let list: Vec<Value> = rows
            .iter()
            .map(|r| {
                json!({
                    "id": r.id,
                    "state": r.state,
                    "project": r.project,
                    "template_id": r.template_id,
                    "created_at": flint_core::util::iso8601(r.created_at_ms),
                    "last_activity_at": flint_core::util::iso8601(r.last_activity_ms),
                })
            })
            .collect();
        Ok(json!({ "sandboxes": list }))
    }
}

