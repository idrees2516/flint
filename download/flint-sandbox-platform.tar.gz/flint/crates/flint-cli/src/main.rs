//! `flint` — the human CLI (REST client).

use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use serde_json::{json, Value};

#[derive(Parser, Debug)]
#[command(name = "flint", about = "Flint sandbox platform CLI")]
struct Cli {
    /// Gateway base URL.
    #[arg(long, default_value = "http://127.0.0.1:8080", env = "FLINT_URL")]
    url: String,
    /// API key.
    #[arg(long, env = "FLINT_API_KEY")]
    key: String,
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand, Debug)]
enum Cmd {
    /// Create a sandbox.
    Create {
        #[arg(long)]
        template: Option<String>,
        #[arg(long, default_value = "2")]
        cpus: u32,
        #[arg(long, default_value = "2048")]
        memory: u32,
        #[arg(long, default_value = "10240")]
        disk: u32,
    },
    /// List sandboxes.
    Ls {
        #[arg(long)]
        state: Option<String>,
    },
    /// Get one sandbox.
    Get { id: String },
    /// Run a command (blocking).
    Exec { id: String, #[arg(trailing_var_arg = true)] cmd: Vec<String> },
    /// Pause (memory-preserving in prod).
    Pause { id: String },
    /// Resume.
    Resume { id: String },
    /// Stop (disk persists).
    Stop { id: String },
    /// Start a stopped sandbox.
    Start { id: String },
    /// Explicit snapshot.
    Snapshot { id: String },
    /// Fork a sandbox into N clones.
    Fork { id: String, #[arg(default_value = "1")] count: u32 },
    /// Delete.
    Rm { id: String },
    /// Upload a file.
    Upload { id: String, local: String, path: String },
    /// Download a file.
    Download { id: String, path: String, local: String },
    /// List files.
    Files { id: String, #[arg(default_value = "/")] path: String },
    /// Web search (tool).
    Search { #[arg(trailing_var_arg = true)] query: Vec<String> },
    /// List templates.
    Templates,
    /// Usage summary.
    Usage,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let client = Client::new(&cli.url, &cli.key);
    match cli.cmd {
        Cmd::Create { template, cpus, memory, disk } => {
            let mut body = json!({ "vm": { "vcpu_count": cpus, "mem_mib": memory, "disk_mib": disk } });
            if let Some(t) = template {
                body["template_id"] = json!(t);
            }
            let v = client.post("/v1/sandboxes", &body)?;
            println!("{}", pretty(&v));
        }
        Cmd::Ls { state } => {
            let mut path = "/v1/sandboxes".to_string();
            if let Some(s) = state {
                path.push_str(&format!("?state={s}"));
            }
            let v = client.get(&path)?;
            for sbx in v.get("sandboxes").and_then(|s| s.as_array()).cloned().unwrap_or_default() {
                println!(
                    "{:<40} {:<10} {}",
                    sbx.get("id").and_then(|x| x.as_str()).unwrap_or("-"),
                    sbx.get("state").and_then(|x| x.as_str()).unwrap_or("-"),
                    sbx.get("last_activity_at").and_then(|x| x.as_str()).unwrap_or(""),
                );
            }
        }
        Cmd::Get { id } => {
            let v = client.get(&format!("/v1/sandboxes/{id}"))?;
            println!("{}", pretty(&v));
        }
        Cmd::Exec { id, cmd } => {
            let cmd = if cmd.is_empty() { vec!["echo hello".to_string()] } else { cmd };
            let spec = if cmd.len() == 1 && !cmd[0].contains(|c: char| !c.is_ascii_graphic() || c == ' ') {
                // Single shell-ish command: run via sh -c for convenience.
                json!({ "cmd": ["sh", "-c", cmd[0]], "timeout_ms": 120000 })
            } else {
                json!({ "cmd": cmd, "timeout_ms": 120000 })
            };
            let v = client.post(&format!("/v1/sandboxes/{id}/exec"), &json!({ "spec": spec }))?;
            let stdout = v.get("stdout").and_then(|s| s.as_str()).unwrap_or("");
            let stderr = v.get("stderr").and_then(|s| s.as_str()).unwrap_or("");
            print!("{stdout}");
            if !stderr.is_empty() {
                eprint!("{stderr}");
            }
            let code = v.get("exit_code").and_then(|c| c.as_i64()).unwrap_or(-1) as i32;
            std::process::exit(code);
        }
        Cmd::Pause { id } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/pause"), &json!({}))?;
            println!("{}", pretty(&v));
        }
        Cmd::Resume { id } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/resume"), &json!({}))?;
            println!("{}", pretty(&v));
        }
        Cmd::Stop { id } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/stop"), &json!({}))?;
            println!("{}", pretty(&v));
        }
        Cmd::Start { id } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/start"), &json!({}))?;
            println!("{}", pretty(&v));
        }
        Cmd::Snapshot { id } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/snapshot"), &json!({}))?;
            println!("{}", pretty(&v));
        }
        Cmd::Fork { id, count } => {
            let v = client.post(&format!("/v1/sandboxes/{id}/fork"), &json!({ "count": count }))?;
            println!("{}", pretty(&v));
        }
        Cmd::Rm { id } => {
            let v = client.delete(&format!("/v1/sandboxes/{id}"))?;
            println!("{}", pretty(&v));
        }
        Cmd::Upload { id, local, path } => {
            let data = std::fs::read(&local).with_context(|| format!("read {local}"))?;
            let resp = client.put_bytes(&format!("/v1/sandboxes/{id}/files?path={}", urlencode(&path)), &data)?;
            println!("{}", pretty(&resp));
        }
        Cmd::Download { id, path, local } => {
            let bytes = client.get_bytes(&format!("/v1/sandboxes/{id}/files?raw=1&path={}", urlencode(&path)))?;
            std::fs::write(&local, &bytes).with_context(|| format!("write {local}"))?;
            println!("wrote {} bytes to {local}", bytes.len());
        }
        Cmd::Files { id, path } => {
            let v = client.get(&format!("/v1/sandboxes/{id}/files/list?path={}", urlencode(&path)))?;
            for e in v.get("entries").and_then(|x| x.as_array()).cloned().unwrap_or_default() {
                let dir = if e.get("is_dir").and_then(|d| d.as_bool()).unwrap_or(false) { "d" } else { "-" };
                println!(
                    "{dir} {:>10}  {}",
                    e.get("size_b").and_then(|s| s.as_u64()).unwrap_or(0),
                    e.get("path").and_then(|p| p.as_str()).unwrap_or(""),
                );
            }
        }
        Cmd::Search { query } => {
            let q = query.join(" ");
            let v = client.post("/v1/tools/web_search", &json!({ "query": q, "num": 8 }))?;
            for r in v.get("results").and_then(|x| x.as_array()).cloned().unwrap_or_default() {
                println!(
                    "* {} — {}",
                    r.get("title").and_then(|t| t.as_str()).unwrap_or(""),
                    r.get("url").and_then(|u| u.as_str()).unwrap_or(""),
                );
                println!("  {}", r.get("snippet").and_then(|s| s.as_str()).unwrap_or(""));
            }
        }
        Cmd::Templates => {
            let v = client.get("/v1/templates")?;
            println!("{}", pretty(&v));
        }
        Cmd::Usage => {
            let v = client.get("/v1/usage")?;
            println!("{}", pretty(&v));
        }
    }
    Ok(())
}

fn urlencode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' | b'/' => out.push(b as char),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

fn pretty(v: &Value) -> String {
    serde_json::to_string_pretty(v).unwrap_or_default()
}

#[derive(Clone)]
struct Client {
    base: String,
    key: String,
}

impl Client {
    fn new(base: &str, key: &str) -> Self {
        Self { base: base.trim_end_matches('/').to_string(), key: key.to_string() }
    }

    fn req(&self, method: &str, path: &str, body: Option<&[u8]>) -> Result<ureq::Response> {
        let url = format!("{}{}", self.base, path);
        let mut r = ureq::request(method, &url)
            .set("Authorization", &format!("Bearer {}", self.key));
        if let Some(_b) = body {
            r = r.set("Content-Type", "application/octet-stream");
        }
        let resp = r
            .send_bytes(body.unwrap_or(&[]))
            .with_context(|| format!("{method} {path}"))?;
        if resp.status() >= 400 {
            let status = resp.status();
            let body = resp.into_string().unwrap_or_default();
            anyhow::bail!("HTTP {status}: {body}");
        }
        Ok(resp)
    }

    fn get(&self, path: &str) -> Result<Value> {
        Ok(self.req("GET", path, None)?.into_json()?)
    }

    fn get_bytes(&self, path: &str) -> Result<Vec<u8>> {
        let mut buf = Vec::new();
        self.req("GET", path, None)?
            .into_reader()
            .read_to_end(&mut buf)
            .context("read body")?;
        Ok(buf)
    }

    fn post(&self, path: &str, body: &Value) -> Result<Value> {
        let bytes = serde_json::to_vec(body)?;
        let resp = self.req("POST", path, Some(&bytes))?;
        if resp.status() == 204 {
            return Ok(Value::Null);
        }
        Ok(resp.into_json()?)
    }

    fn delete(&self, path: &str) -> Result<Value> {
        Ok(self.req("DELETE", path, None)?.into_json()?)
    }

    fn put_bytes(&self, path: &str, data: &[u8]) -> Result<Value> {
        let resp = self.req("PUT", path, Some(data))?;
        if resp.status() == 204 {
            return Ok(Value::Null);
        }
        Ok(resp.into_json()?)
    }
}

use std::io::Read as _;
