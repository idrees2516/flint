# Modal (modal.com) — Deep Research

*Researched by task R2, October 2025. Sources: modal.com blog/docs, third-party comparisons.*

## Overview
Modal is a serverless GPU/CPU container runtime "designed to scale from zero," positioned for AI/ML workloads: inference, fine-tuning/RL, batch jobs, notebooks, and — increasingly — sandboxes for coding agents, RL rollouts, and untrusted code. Its product set now includes **Inference**, **Sandboxes** (container and VM runtimes), **Training**, and a "Modal Infrastructure" layer (custom container runtime, storage, multi-cloud capacity pool). Flagship engineering claims: per-second billing, sub-second cold starts via checkpoint/restore, and "scaling to 1 million concurrent sandboxes in seconds." Customers like Linear, Legora, Snorkel, and Ramp run coding-agent sessions and agent-eval environments on Modal. Founded by Erik Bernhardsson & Akshat Bubna; the control plane and hot paths are built in **Rust**, with Python as the primary user-facing language.

## Isolation & Architecture
- Modal's original runtime is **gVisor (`runsc`)** — a userspace kernel intercepting syscalls, chosen over runc for stronger isolation of untrusted code, with custom logic to block malicious syscalls. Modal's memory-snapshot blog explicitly states: "for security reasons Modal uses the gVisor container runtime runsc."
- Filesystem: each container rootfs is an **OverlayFS** whose read-only lower layer is a **FUSE-based lazy-loading file server** backed by a distributed content-addressable store. Most files (e.g., `/usr/share/doc`) are never loaded; popular files are cached in worker memory *across users* (a shared file cache gives 3–5x speedups).
- **VM Sandboxes (GA Oct 2026)**: a second runtime built on the Rust-based **Cloud Hypervisor** microVM, layered with Modal's "half dozen innovations spanning host filesystems, lazy image loading, memory bursting, and snapshotting tech." `modal.Sandbox.create(runtime="vm")` gives a full Linux VM (Docker-in-Docker, FUSE, systemd-ish workloads) while keeping the same exec/FS APIs, `modal.Images`, sub-second cold starts, and "container-shaped" ergonomics. Early customers launched 20M+ VMs. gVisor remains the default for plain sandboxes.
- Autoscaling: containers are booted when warm containers can't absorb pending inputs; `min_containers`/`buffer_containers` keep a warm pool; `scaledown_window` is configurable from **2 seconds to 20 minutes**. Modal also publishes an open-source queueing-theory model of serverless scaling (github.com/modal-labs/serverless-queuing-theory-model).

## API Surface
- Python-first decorators: `@app.function(...)`, `@modal.cls` (parameterized classes), `@modal.enter(snap=True/False)` lifecycle methods, `@modal.concurrent` (input concurrency), `@modal.batched` (dynamic batching), `@modal.web_endpoint`/`fastapi_endpoint`/`asgi_app` for HTTP, `@app.local_entrypoint`.
- **`modal.Sandbox`** is the "sandbox as a resource" primitive: `Sandbox.create(app=..., image=..., cpu=, memory=, volumes=, timeout=, runtime="container"|"vm")`, `sb.exec(cmd, timeout=)` returning process objects with streamable `stdout`/`stderr`, filesystem APIs (`sb.read_file`, `listdir`, etc.), `Sandbox.from_id(...)` rehydration, `snapshot_filesystem()`, `snapshot_directory()`, `sb.terminate()`. Also `modal.Proxy` for static outbound IP.
- Cross-language SDKs: Python, JS/TS, and Go (all in github.com/modal-labs/modal-client, now including the former `libmodal` JS/Go SDKs). Invocation methods include local calls, `.spawn()` (async fire-and-forget), `.map()` (fan-out), and `.remote()` on methods.

## Persistence & Checkpointing
- **Memory snapshots (Jan 2025)**: gVisor checkpoint/restore ("outgrowth of CRIU") captures the entire container state right before it accepts a request — filesystem mutations plus the whole process tree (memory mappings, fd tables, registers, env, PIDs) — into a snapshot "pages" file (typically 100MiB–10GiB). Restore is ~**2.5x faster** than cold boot (e.g., `import torch` = 26,000 syscalls ≈ 5s cold → 1.05s p50 / 0.69s p0 restored; Stable Diffusion 13s → 3.5s). gVisor restores pages in the background, prioritizing pages the restored process blocks on, served via the FUSE file system with aggressive preloading. Enabled with `enable_memory_snapshot=True`; snapshots are created **on demand**, per-worker, and auto-invalidated on redeploy or CPU-feature/NVIDIA-driver incompatibility (e.g., `pclmulqdq` mismatch across instance types). Failed restores fall back to normal cold boot. Live network connections are *not* preserved; entropy assumptions may be violated.
- **GPU memory snapshots (Jul 2025, alpha)**: uses NVIDIA's new **CUDA checkpoint/restore APIs** (`cuCheckpointProcessLock/Checkpoint/Restore/Unlock`, drivers 570/575+) to copy GPU vRAM, CUDA kernels, streams, contexts, and memory maps into the snapshot — up to **10x faster cold boots** (Parakeet 20s→2s p0; vLLM Qwen2.5-0.5B 45s→5s p0). This removes the old two-stage `snap=True` (load to CPU) / `snap=False` (move to GPU) dance and preserves `torch.compile` artifacts.
- **Sandbox snapshots** (user-facing): filesystem snapshots → become `modal.Image`s; directory snapshots (single subtree); memory snapshots; explicit TTLs (filesystem/directory default 30 days, memory snapshots 7 days).
- `modal.Volume` for durable shared storage with commit-based consistency.

## Agent & Long-Running Features
- Sandboxes are explicitly marketed for coding agents, browser-use agents, RL rollouts (Verifiers/OpenEnv), terminal-CLI agent RL, and OpenAI Agents SDK "environments." Docs describe the two canonical patterns: agent *inside* the sandbox vs. agent *outside* driving the sandbox over APIs.
- Long-lived sandboxes support sessions up to **24 hours** (per Northflank comparison), warm-pool maintenance example in docs (`modal.com/docs/examples/sandbox_pool` uses a Modal Queue to keep a pool of healthy warm sandboxes), filesystem persistence across sessions via volumes, and `App.lookup(create_if_missing=True)` for runtime-created apps.
- Function timeout: default 300s, max **24 hours**; web endpoints cap HTTP requests at 150s; `@modal.concurrent` for I/O-bound input concurrency in one container.

## Pricing & Limits
- Per-second billing: ~**$0.0000131/physical-core/s** (≈ $0.047/core-hr); GPUs e.g. B200 ≈ $0.001736/s (~$6.25/hr), H200 ≈ $0.001261/s (~$4.54/hr), H100 ≈ $3.95/hr region-dependent. $30/month free credits. Warm/idle containers bill at reduced rates; scaledown window 2s–20min.
- Sandboxes bill per second on `max(request, actual)` resources — burstable CPU/memory, paying the higher of request vs usage.
- Known limits: 24h max function/sandbox duration; 150s web request timeout; snapshot compatibility constraints (CPU featureset, NVIDIA driver version, runtime version) are why Modal controls snapshot lifecycle centrally.

## Open-Source & Engineering Notes
- SDKs are open source: **github.com/modal-labs/modal-client** (Python/JS/TS/Go), plus the queueing-theory model repo. The platform/control plane itself is closed-source; core infra is Rust (per press coverage: "Serverless for AI Devs: Modal's Python and Rust Based Platform").
- Key blog posts (rich engineering detail):
  - Memory snapshots: https://modal.com/blog/mem-snapshots (CRIU/gVisor internals, pages file, 26k-syscall story)
  - GPU memory snapshots: https://modal.com/blog/gpu-mem-snapshots (CUDA checkpoint APIs)
  - VM Sandboxes: https://modal.com/blog/vm-sandboxes-agent-computers (Cloud Hypervisor-based runtime)
  - Speed-of-wire: https://modal.com/blog/bringing-serverless-functions-closer-to-the-speed-of-wire (input processing, gRPC hot path)
  - Lazy container loading: "Fast, lazy container loading in Modal.com" (referenced in mem-snapshots post)
  - Serverless Servers: https://modal.com/blog/serverless-servers
  - Docs: /docs/guide/memory-snapshots, /docs/guide/cold-start, /docs/guide/scale, /docs/guide/sandbox-snapshots, /docs/examples/sandbox_pool

## Lessons for a Rust Implementation
1. **Snapshot/restore beats lazy-loading for init-heavy workloads.** Python import chains (tens of thousands of sequential syscalls) can't be fixed by filesystem tricks alone; freezing a restored process tree into a page file turns cold start into "roughly a single file load." A Rust engine should treat CRIU-style checkpoint/restore (or gVisor/Cloud Hypervisor native C/R) as a first-class feature, with background page-in that prioritizes faulting pages.
2. **Own the whole stack**: custom FUSE lazy-loading image service + cross-tenant warm file cache + OverlayFS layout + scheduler-aware snapshot placement. Modal's perf comes from co-designing storage, runtime, and scheduler (a snapshot must match worker CPU features & driver versions — schedule restores against a compatibility matrix, and fall back to cold boot on restore failure).
3. **Expose snapshots at multiple granularities** (filesystem-as-image, directory, full memory, GPU state) with explicit TTL/retention semantics.
4. **Two runtimes, one API**: keep gVisor-class isolation for cheap/fast container sandboxes and a Cloud Hypervisor (Rust!) microVM tier for "agents that want a whole computer" (Docker, FUSE), sharing Images, exec/FS APIs, and pricing.
5. **Billing primitives**: per-second metering on `max(request, actual)`, configurable scaledown window (2s–20min), and warm-pool knobs (`min_containers`, `buffer_containers`) as API-level contracts.
6. **Warm pools as a user pattern**: provide first-class pool primitives (or examples) — Tensorlake built this in; Modal shows it via queues.
