//! gRPC surface: the public API services (`flint.api.v1`) implemented on
//! top of `OpsCore`, plus the fleet services (`flint.fleet.v1`) spoken by
//! workers.

use crate::ops::Gateway;
use flint_core::{FlintError, SandboxCreateSpec, TimeoutPolicy, VmSpec};
use flint_proto::api::exec_service_server::ExecService;
use flint_proto::api::file_service_server::FileService;
use flint_proto::api::sandbox_service_server::SandboxService;
use flint_proto::api::template_service_server::TemplateService;
use flint_proto::api::tool_service_server::ToolService;
use flint_proto::api::*;
use flint_proto::fleet::fleet_report_server::FleetReport;
use flint_proto::fleet::fleet_service_server::FleetService;
use flint_proto::fleet::{
    ControlMessage, GetRestoreInfoRequest, GetRestoreInfoResponse, HeartbeatMessage,
    RegisterRequest, RegisterResponse, ReportSandboxRequest, ReportSandboxResponse,
};
use flint_scheduler::WorkerState;
use std::pin::Pin;
use std::sync::Arc;
use tonic::metadata::MetadataMap;
use tonic::{Request, Response, Status, Streaming};

fn auth_key(gw: &Gateway, req: &Request<impl Sized>) -> std::result::Result<flint_store::ApiKeyRow, Status> {
    let meta = req.metadata();
    let key = meta
        .get("x-api-key")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_string())
        .or_else(|| {
            meta.get("authorization")
                .and_then(|v| v.to_str().ok())
                .and_then(|a| a.strip_prefix("Bearer ").map(|t| t.trim().to_string()))
        })
        .ok_or_else(|| Status::unauthenticated("missing x-api-key"))?;
    let hash = flint_core::tokens::hash_api_key(&key);
    let row = gw
        .store
        .find_api_key_by_hash(&hash)
        .map_err(|e| Status::internal(e.to_string()))?
        .ok_or_else(|| Status::unauthenticated("invalid key"))?;
    Ok(row)
}

fn to_status(e: &FlintError) -> Status {
    Status::new(
        tonic::Code::from(e.http_status() as i32),
        format!("{}: {}", e.code(), e),
    )
}

macro_rules! map {
    ($v:expr) => {
        $v.map_err(|e| to_status(&e))
    };
}

fn vm_to_msg(vm: VmSpec) -> VmSpecMsg {
    VmSpecMsg { vcpu_count: vm.vcpu_count, mem_mib: vm.mem_mib, disk_mib: vm.disk_mib }
}

fn row_to_info(row: &flint_store::SandboxRow) -> SandboxInfo {
    SandboxInfo {
        id: row.id.clone(),
        state: row.state.clone(),
        template_id: row.template_id.clone().unwrap_or_default(),
        project: row.project.clone().unwrap_or_default(),
        vm: Some(vm_to_msg(row.vm)),
        created_at_ms: row.created_at_ms,
        last_activity_ms: row.last_activity_ms,
        current_snapshot_id: row.current_snapshot_id.clone().unwrap_or_default(),
        metadata: row.metadata.clone().into_iter().collect(),
    }
}

// ---------------------------------------------------------------------------
// SandboxService
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct ApiServer {
    pub gw: Arc<Gateway>,
}

#[tonic::async_trait]
impl SandboxService for ApiServer {
    async fn create_sandbox(
        &self,
        request: Request<CreateSandboxRequest>,
    ) -> std::result::Result<Response<CreateSandboxResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let spec = SandboxCreateSpec {
            template_id: if r.template_id.is_empty() { None } else { Some(r.template_id.clone()) },
            project: if r.project.is_empty() { None } else { Some(r.project.clone()) },
            vm: VmSpec {
                vcpu_count: if r.vm.is_some() { r.vm.unwrap().vcpu_count } else { 2 },
                mem_mib: if r.vm.as_ref().is_some_and(|v| v.mem_mib > 0) { r.vm.as_ref().unwrap().mem_mib } else { 2048 },
                disk_mib: if r.vm.as_ref().is_some_and(|v| v.disk_mib > 0) { r.vm.as_ref().unwrap().disk_mib } else { 10240 },
            },
            env: r.env.clone().into_iter().collect(),
            metadata: r.metadata.clone().into_iter().collect(),
            timeouts: TimeoutPolicy {
                auto_pause_after_idle_ms: if r.auto_pause_after_idle_ms > 0 { Some(r.auto_pause_after_idle_ms) } else { None },
                auto_stop_after_idle_ms: None,
                max_ttl_ms: if r.max_ttl_ms > 0 { Some(r.max_ttl_ms) } else { None },
                expiry_action: match r.expiry_action.as_str() {
                    "stop" => flint_core::state::ExpiryAction::Stop,
                    "delete" => flint_core::state::ExpiryAction::Delete,
                    _ => flint_core::state::ExpiryAction::Pause,
                },
                wake_on_request: true,
            },
            driver: None,
            start_paused: false,
        };
        let v = map!(self.gw.create_sandbox(&key.key_id, spec).await)?;
        // The core returns the REST-shaped JSON; parse the fields back out.
        let info = SandboxInfo {
            id: v.get("id").and_then(|x| x.as_str()).unwrap_or_default().into(),
            state: v.get("state").and_then(|x| x.as_str()).unwrap_or_default().into(),
            template_id: v.get("template_id").and_then(|x| x.as_str()).unwrap_or_default().into(),
            project: v.get("project").and_then(|x| x.as_str()).unwrap_or_default().into(),
            vm: None,
            created_at_ms: 0,
            last_activity_ms: 0,
            current_snapshot_id: String::new(),
            metadata: Default::default(),
        };
        Ok(Response::new(CreateSandboxResponse { sandbox: Some(info) }))
    }

    async fn get_sandbox(
        &self,
        request: Request<GetSandboxRequest>,
    ) -> std::result::Result<Response<GetSandboxResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let row = map!(self.gw.get_sandbox_row(&key.key_id, &r.id))?;
        Ok(Response::new(GetSandboxResponse { sandbox: Some(row_to_info(&row)) }))
    }

    async fn list_sandboxes(
        &self,
        request: Request<ListSandboxesRequest>,
    ) -> std::result::Result<Response<ListSandboxesResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let state = serde_json::from_value::<flint_core::SandboxState>(serde_json::json!(r.state)).ok();
        let rows = map!(self.gw.store.list_sandboxes(Some(&key.key_id), state, r.limit.max(1) as usize))?;
        Ok(Response::new(ListSandboxesResponse {
            sandboxes: rows.iter().map(row_to_info).collect(),
        }))
    }

    async fn delete_sandbox(
        &self,
        request: Request<DeleteSandboxRequest>,
    ) -> std::result::Result<Response<DeleteSandboxResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw.delete_sandbox(&key.key_id, &r.id).await)?;
        Ok(Response::new(DeleteSandboxResponse { deleted: true }))
    }

    async fn pause(
        &self,
        request: Request<PauseRequest>,
    ) -> std::result::Result<Response<PauseResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw.pause(&key.key_id, &r.id).await)?;
        let row = map!(self.gw.get_sandbox_row(&key.key_id, &r.id))?;
        Ok(Response::new(PauseResponse { sandbox: Some(row_to_info(&row)) }))
    }

    async fn resume(
        &self,
        request: Request<ResumeRequest>,
    ) -> std::result::Result<Response<ResumeResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw.resume(&key.key_id, &r.id).await)?;
        let row = map!(self.gw.get_sandbox_row(&key.key_id, &r.id))?;
        Ok(Response::new(ResumeResponse { sandbox: Some(row_to_info(&row)) }))
    }

    async fn stop(
        &self,
        request: Request<StopRequest>,
    ) -> std::result::Result<Response<StopResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw.stop(&key.key_id, &r.id).await)?;
        let row = map!(self.gw.get_sandbox_row(&key.key_id, &r.id))?;
        Ok(Response::new(StopResponse { sandbox: Some(row_to_info(&row)) }))
    }

    async fn snapshot(
        &self,
        request: Request<SnapshotRequest>,
    ) -> std::result::Result<Response<SnapshotResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.snapshot(&key.key_id, &r.id).await)?;
        let row = map!(self.gw.get_sandbox_row(&key.key_id, &r.id))?;
        Ok(Response::new(SnapshotResponse {
            snapshot_id: v.get("snapshot_id").and_then(|s| s.as_str()).unwrap_or_default().into(),
            sandbox: Some(row_to_info(&row)),
        }))
    }

    async fn fork(
        &self,
        request: Request<ForkRequest>,
    ) -> std::result::Result<Response<ForkResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.fork(&key.key_id, &r.id, r.count.max(1), r.keep_paused).await)?;
        let forks: Vec<SandboxInfo> = v
            .get("forks")
            .and_then(|f| f.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|f| SandboxInfo {
                        id: f.get("id").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        state: f.get("state").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        ..Default::default()
                    })
                    .collect()
            })
            .unwrap_or_default();
        Ok(Response::new(ForkResponse {
            forks,
            snapshot_id: v.get("snapshot_id").and_then(|x| x.as_str()).unwrap_or_default().into(),
        }))
    }
}

// ---------------------------------------------------------------------------
// ExecService
// ---------------------------------------------------------------------------

#[tonic::async_trait]
impl ExecService for ApiServer {
    type RunExecStream = Pin<Box<dyn tokio_stream::Stream<Item = std::result::Result<ExecEvent, Status>> + Send>>;

    async fn run_exec(
        &self,
        request: Request<RunExecRequest>,
    ) -> std::result::Result<Response<Self::RunExecStream>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let spec = flint_core::ExecSpec {
            cmd: r.cmd.clone(),
            env: r.env.clone().into_iter().collect(),
            cwd: if r.cwd.is_empty() { None } else { Some(r.cwd.clone()) },
            timeout_ms: Some(r.timeout_ms.min(self.gw.cfg.limits.max_exec_timeout_ms)),
            pty: if r.pty { Some(flint_core::PtySize { cols: r.cols.max(1) as u16, rows: r.rows.max(1) as u16 }) } else { None },
            restartable: false,
            user: if r.user.is_empty() { None } else { Some(r.user.clone()) },
        };
        let result = map!(self.gw.exec(&key.key_id, &r.sandbox_id, &spec).await)?;
        let events: Vec<std::result::Result<ExecEvent, Status>> = vec![
            Ok(ExecEvent {
                call_id: String::new(),
                kind: "stdout".into(),
                data: result
                    .get("stdout_b64")
                    .and_then(|b| b.as_str())
                    .and_then(|b| flint_core::util::b64_decode(b).ok())
                    .unwrap_or_default()
                    .into(),
                exit_code: 0,
                timed_out: false,
                error: String::new(),
            }),
            Ok(ExecEvent {
                call_id: String::new(),
                kind: "exit".into(),
                data: Vec::new(),
                exit_code: result.get("exit_code").and_then(|c| c.as_i64()).unwrap_or(-1) as i32,
                timed_out: result.get("timed_out").and_then(|t| t.as_bool()).unwrap_or(false),
                error: String::new(),
            }),
        ];
        Ok(Response::new(Box::pin(tokio_stream::iter(events))))
    }

    async fn spawn_process(
        &self,
        request: Request<SpawnProcessRequest>,
    ) -> std::result::Result<Response<SpawnProcessResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let payload = serde_json::json!({
            "cmd": r.cmd, "env": r.env, "cwd": r.cwd, "user": r.user, "restartable": r.restartable
        });
        let v = map!(self
            .gw
            .op(&key.key_id, &r.sandbox_id, "process.spawn", &serde_json::json!({ "spec": payload, "op_id": flint_core::ids::new_id("op") }))
            .await)?;
        Ok(Response::new(SpawnProcessResponse {
            proc_id: v.get("proc_id").and_then(|p| p.as_str()).unwrap_or_default().into(),
        }))
    }

    async fn list_processes(
        &self,
        request: Request<ListProcessesRequest>,
    ) -> std::result::Result<Response<ListProcessesResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.op(&key.key_id, &r.sandbox_id, "process.list", &serde_json::json!({})).await)?;
        let procs: Vec<ProcessInfo> = v
            .get("processes")
            .and_then(|p| p.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|p| ProcessInfo {
                        proc_id: p.get("proc_id").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        cmd: p
                            .get("cmd")
                            .and_then(|x| x.as_array())
                            .map(|a| a.iter().filter_map(|c| c.as_str().map(String::from)).collect())
                            .unwrap_or_default(),
                        status: p.get("status").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        exit_code: p.get("exit_code").and_then(|x| x.as_i64()).unwrap_or(0) as i32,
                        started_at_ms: p.get("started_at_ms").and_then(|x| x.as_u64()).unwrap_or(0),
                    })
                    .collect()
            })
            .unwrap_or_default();
        Ok(Response::new(ListProcessesResponse { processes: procs }))
    }

    async fn process_input(
        &self,
        request: Request<ProcessInputRequest>,
    ) -> std::result::Result<Response<ProcessInputResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "process.input", &serde_json::json!({
                "proc_id": r.proc_id, "data_b64": flint_core::util::b64_encode(&r.data), "close_stdin": r.close_stdin
            }))
            .await)?;
        Ok(Response::new(ProcessInputResponse { ok: true }))
    }

    async fn process_signal(
        &self,
        request: Request<ProcessSignalRequest>,
    ) -> std::result::Result<Response<ProcessSignalResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "process.signal", &serde_json::json!({
                "proc_id": r.proc_id, "signal": r.signal
            }))
            .await)?;
        Ok(Response::new(ProcessSignalResponse { ok: true }))
    }

    async fn kill_process(
        &self,
        request: Request<KillProcessRequest>,
    ) -> std::result::Result<Response<KillProcessResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "process.kill", &serde_json::json!({ "proc_id": r.proc_id }))
            .await)?;
        Ok(Response::new(KillProcessResponse { ok: true }))
    }
}

// ---------------------------------------------------------------------------
// FileService
// ---------------------------------------------------------------------------

#[tonic::async_trait]
impl FileService for ApiServer {
    async fn write(
        &self,
        request: Request<WriteRequest>,
    ) -> std::result::Result<Response<WriteResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        if r.content.len() > self.gw.cfg.limits.max_file_write_bytes {
            return Err(Status::invalid_argument("content too large"));
        }
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "fs.write", &serde_json::json!({
                "path": r.path,
                "content_b64": flint_core::util::b64_encode(&r.content),
                "mode": if r.mode > 0 { Some(r.mode) } else { None },
                "op_id": if r.op_id.is_empty() { flint_core::ids::new_id("op") } else { r.op_id.clone() },
            }))
            .await)?;
        Ok(Response::new(WriteResponse { ok: true, op_id: r.op_id }))
    }

    async fn read(
        &self,
        request: Request<ReadRequest>,
    ) -> std::result::Result<Response<ReadResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "fs.read", &serde_json::json!({
                "path": r.path, "max_bytes": if r.max_bytes > 0 { r.max_bytes as usize } else { 8 * 1024 * 1024 }
            }))
            .await)?;
        Ok(Response::new(ReadResponse {
            content: v
                .get("content_b64")
                .and_then(|b| b.as_str())
                .and_then(|b| flint_core::util::b64_decode(b).ok())
                .unwrap_or_default()
                .into(),
            mode: v.get("mode").and_then(|m| m.as_u64()).unwrap_or(0) as u32,
        }))
    }

    async fn list(
        &self,
        request: Request<ListRequest>,
    ) -> std::result::Result<Response<ListResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.op(&key.key_id, &r.sandbox_id, "fs.list", &serde_json::json!({ "path": r.path })).await)?;
        let entries: Vec<FsEntryMsg> = v
            .get("entries")
            .and_then(|e| e.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|e| FsEntryMsg {
                        name: e.get("name").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        path: e.get("path").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        is_dir: e.get("is_dir").and_then(|x| x.as_bool()).unwrap_or(false),
                        size_b: e.get("size_b").and_then(|x| x.as_u64()).unwrap_or(0),
                        mode: e.get("mode").and_then(|x| x.as_u64()).unwrap_or(0) as u32,
                        mtime_ms: e.get("mtime_ms").and_then(|x| x.as_i64()).unwrap_or(0),
                    })
                    .collect()
            })
            .unwrap_or_default();
        Ok(Response::new(ListResponse { entries }))
    }

    async fn mkdir(
        &self,
        request: Request<MkdirRequest>,
    ) -> std::result::Result<Response<MkdirResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "fs.mkdir", &serde_json::json!({
                "path": r.path, "recursive": r.recursive, "op_id": r.op_id
            }))
            .await)?;
        Ok(Response::new(MkdirResponse { ok: true }))
    }

    async fn remove(
        &self,
        request: Request<RemoveRequest>,
    ) -> std::result::Result<Response<RemoveResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "fs.remove", &serde_json::json!({
                "path": r.path, "recursive": r.recursive, "op_id": r.op_id
            }))
            .await)?;
        Ok(Response::new(RemoveResponse { ok: true }))
    }

    async fn r#move(
        &self,
        request: Request<MoveRequest>,
    ) -> std::result::Result<Response<MoveResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        map!(self.gw
            .op(&key.key_id, &r.sandbox_id, "fs.move", &serde_json::json!({
                "from": r.from, "to": r.to, "op_id": r.op_id
            }))
            .await)?;
        Ok(Response::new(MoveResponse { ok: true }))
    }

    async fn stat(
        &self,
        request: Request<StatRequest>,
    ) -> std::result::Result<Response<StatResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.op(&key.key_id, &r.sandbox_id, "fs.stat", &serde_json::json!({ "path": r.path })).await)?;
        let exists = v.get("exists").and_then(|x| x.as_bool()).unwrap_or(false);
        let entry = FsEntryMsg {
            name: r.path.rsplit('/').next().unwrap_or_default().into(),
            path: r.path.clone(),
            is_dir: v.get("is_dir").and_then(|x| x.as_bool()).unwrap_or(false),
            size_b: v.get("size_b").and_then(|x| x.as_u64()).unwrap_or(0),
            mode: v.get("mode").and_then(|x| x.as_u64()).unwrap_or(0) as u32,
            mtime_ms: v.get("mtime_ms").and_then(|x| x.as_i64()).unwrap_or(0),
        };
        Ok(Response::new(StatResponse { entry: Some(entry), exists }))
    }
}

// ---------------------------------------------------------------------------
// ToolService + TemplateService
// ---------------------------------------------------------------------------

#[tonic::async_trait]
impl ToolService for ApiServer {
    async fn web_search(
        &self,
        request: Request<WebSearchRequest>,
    ) -> std::result::Result<Response<WebSearchResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.web_search(&key, &r.query, r.num.max(1).min(20)).await)?;
        let results: Vec<SearchResultMsg> = v
            .get("results")
            .and_then(|x| x.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|s| SearchResultMsg {
                        title: s.get("title").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        url: s.get("url").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        snippet: s.get("snippet").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        host: s.get("host").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        date: s.get("date").and_then(|x| x.as_str()).unwrap_or_default().into(),
                    })
                    .collect()
            })
            .unwrap_or_default();
        Ok(Response::new(WebSearchResponse { results }))
    }

    async fn http_fetch(
        &self,
        request: Request<HttpFetchRequest>,
    ) -> std::result::Result<Response<HttpFetchResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.http_fetch(&key, &r.url).await)?;
        Ok(Response::new(HttpFetchResponse {
            body: v
                .get("body_b64")
                .and_then(|b| b.as_str())
                .and_then(|b| flint_core::util::b64_decode(b).ok())
                .unwrap_or_default()
                .into(),
            status: v.get("status").and_then(|x| x.as_u64()).unwrap_or(0) as u32,
            content_type: v.get("content_type").and_then(|x| x.as_str()).unwrap_or_default().into(),
        }))
    }
}

#[tonic::async_trait]
impl TemplateService for ApiServer {
    async fn list_templates(
        &self,
        request: Request<ListTemplatesRequest>,
    ) -> std::result::Result<Response<ListTemplatesResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let v = map!(self.gw.list_templates(&key.key_id))?;
        let templates: Vec<TemplateInfo> = v
            .get("templates")
            .and_then(|x| x.as_array())
            .map(|arr| {
                arr.iter()
                    .map(|t| TemplateInfo {
                        id: t.get("id").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        name: t.get("name").and_then(|x| x.as_str()).unwrap_or_default().into(),
                        size_b: t.get("size_b").and_then(|x| x.as_u64()).unwrap_or(0),
                        created_at_ms: t.get("created_at").and_then(|x| x.as_str()).and_then(|s| chrono::DateTime::parse_from_rfc3339(s).ok()).map(|d| d.timestamp_millis()).unwrap_or(0),
                    })
                    .collect()
            })
            .unwrap_or_default();
        Ok(Response::new(ListTemplatesResponse { templates }))
    }

    async fn create_from_sandbox(
        &self,
        request: Request<CreateFromSandboxRequest>,
    ) -> std::result::Result<Response<CreateFromSandboxResponse>, Status> {
        let key = auth_key(&self.gw, &request)?;
        let r = request.into_inner();
        let v = map!(self.gw.create_template_from(&key.key_id, &r.sandbox_id, &r.name).await)?;
        Ok(Response::new(CreateFromSandboxResponse {
            template: Some(TemplateInfo {
                id: v.get("id").and_then(|x| x.as_str()).unwrap_or_default().into(),
                name: v.get("name").and_then(|x| x.as_str()).unwrap_or_default().into(),
                size_b: v.get("size_b").and_then(|x| x.as_u64()).unwrap_or(0),
                created_at_ms: 0,
            }),
        }))
    }
}

// ---------------------------------------------------------------------------
// Fleet services (workers → gateway)
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct FleetServer {
    pub gw: Arc<Gateway>,
}

#[tonic::async_trait]
impl FleetService for FleetServer {
    async fn register(
        &self,
        request: Request<RegisterRequest>,
    ) -> std::result::Result<Response<RegisterResponse>, Status> {
        let r = request.into_inner();
        let worker = WorkerState {
            node_id: r.node_id.clone(),
            addr: r.addr.clone(),
            driver_kind: r.driver_kind.clone(),
            capacity: flint_scheduler::Capacity {
                vcpu_total: r.vcpu_total,
                mem_mib_total: r.mem_mib_total,
                max_sandboxes: r.max_sandboxes,
                pause_headroom_mib: r.pause_headroom_mib,
            },
            load: Default::default(),
            drained: false,
            last_heartbeat_ms: flint_core::util::now_ms(),
        };
        self.gw.scheduler.register(worker);
        self.gw.store.upsert_worker(&flint_store::WorkerRow {
            node_id: r.node_id,
            addr: r.addr,
            capacity_json: String::new(),
            load_json: String::new(),
            drained: false,
            last_heartbeat_ms: flint_core::util::now_ms(),
            registered_at_ms: flint_core::util::now_ms(),
        }).map_err(|e| Status::internal(e.to_string()))?;
        flint_core::metrics::counter_inc(flint_core::metrics::names::WORKER_HEARTBEATS, &[("kind", "register".into())]);
        Ok(Response::new(RegisterResponse { ok: true }))
    }

    type HeartbeatStream = Pin<Box<dyn tokio_stream::Stream<Item = std::result::Result<ControlMessage, Status>> + Send>>;

    async fn heartbeat(
        &self,
        request: Request<Streaming<HeartbeatMessage>>,
    ) -> std::result::Result<Response<Self::HeartbeatStream>, Status> {
        let gw = self.gw.clone();
        let mut inbound = request.into_inner();
        let out = async_stream::stream! {
            use tokio_stream::StreamExt as _;
            while let Some(Ok(hb)) = inbound.next().await {
                flint_core::metrics::counter_inc(flint_core::metrics::names::WORKER_HEARTBEATS, &[("kind", "beat".into())]);
                gw.scheduler.heartbeat(&hb.node_id, flint_scheduler::Load {
                    running: hb.running,
                    paused: hb.paused,
                    cpu_pressure: hb.cpu_pressure,
                    mem_pressure: hb.mem_pressure,
                    slot_pressure: hb.slot_pressure,
                });
                // Piggybacked state reports travel in load_json.
                if !hb.load_json.is_empty() {
                    if let Ok(v) = serde_json::from_str::<serde_json::Value>(&hb.load_json) {
                        if let Some(rep) = v.get("report") {
                            let id = rep.get("sandbox_id").and_then(|x| x.as_str()).unwrap_or_default();
                            let state = rep.get("state").and_then(|x| x.as_str()).unwrap_or_default();
                            let snap = rep.get("snapshot_id").and_then(|x| x.as_str()).unwrap_or_default();
                            if !id.is_empty() && !state.is_empty() {
                                let directive = gw.handle_report(id, state, snap);
                                let _ = gw.events.publish(id, serde_json::json!({ "type": "state", "state": state })).await;
                                yield Ok(ControlMessage { kind: "report_ack".into(), payload_json: serde_json::json!({ "directive": directive }).to_string() });
                            }
                        }
                    }
                }
                // No control messages in v1; hold the stream open.
            }
        };
        Ok(Response::new(Box::pin(out)))
    }
}

#[tonic::async_trait]
impl FleetReport for FleetServer {
    async fn report_sandbox(
        &self,
        request: Request<ReportSandboxRequest>,
    ) -> std::result::Result<Response<ReportSandboxResponse>, Status> {
        let r = request.into_inner();
        let directive = self.gw.handle_report(&r.sandbox_id, &r.state, &r.snapshot_id);
        Ok(Response::new(ReportSandboxResponse { ok: true, directive }))
    }

    async fn get_restore_info(
        &self,
        request: Request<GetRestoreInfoRequest>,
    ) -> std::result::Result<Response<GetRestoreInfoResponse>, Status> {
        let r = request.into_inner();
        match self.gw.restore_info(&r.sandbox_id) {
            Ok((manifest, snap_id)) => Ok(Response::new(GetRestoreInfoResponse {
                manifest_json: manifest,
                snapshot_id: snap_id,
                store_kind: if self.gw.objects_local { "local".into() } else { "s3".into() },
            })),
            Err(e) => Err(to_status(&e)),
        }
    }
}

// Silence unused import when MetadataMap isn't referenced directly.
#[allow(unused)]
fn _meta_check(_: Option<MetadataMap>) {}
