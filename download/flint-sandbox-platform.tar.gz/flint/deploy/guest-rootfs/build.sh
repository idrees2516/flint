#!/usr/bin/env bash
# Build a Firecracker-compatible guest rootfs with the Flint guest agent
# and the "exec-any" runtime set (python3, node, gcc, rustup).
#
# Produces:
#   ./rootfs.ext4          — the base rootfs image (template base)
#   ./vmlinux              — is NOT built here; fetch a FC-compatible
#                            kernel (e.g. from firecracker's
#                            resources/default_vmlinux or build with
#                            CONFIG_VIRTIO_* + CONFIG_VIRTIO_VSOCKETS=y)
#
# Requires: root (or docker), debootstrap or docker.
set -euo pipefail
cd "$(dirname "$0")"

SIZE_MB=${SIZE_MB:-2048}
TARGET_DIR=${TARGET_DIR:-./rootfs-tree}

if [ "$(id -u)" != "0" ] && ! command -v docker >/dev/null; then
  echo "run as root or with docker available" >&2
  exit 1
fi

run_root() { if [ "$(id -u)" = "0" ]; then "$@"; else docker run --rm -i -v "$PWD:/work" -w /work debian:bookworm "$@"; fi; }

echo "==> debootstrap base system"
run_root sh -c "
  set -e
  if [ ! -d $TARGET_DIR ]; then
    debootstrap --variant=minbase bookworm $TARGET_DIR http://deb.debian.org/debian || {
      apt-get update -qq && apt-get install -y -qq debootstrap && debootstrap --variant=minbase bookworm $TARGET_DIR http://deb.debian.org/debian; }
  fi
"

echo "==> install runtimes + agent"
run_root sh -c "
  set -e
  chroot $TARGET_DIR /bin/bash -c '
    export DEBIAN_FRONTEND=noninteractive
    echo \"root:flint\" | chpasswd
    systemctl enable systemd-networkd 2>/dev/null || true
    apt-get update -qq
    apt-get install -y -qq --no-install-recommends \
      python3 python3-pip nodejs npm g++ git curl ca-certificates openssh-server \
      iproute2 iptables nftables less vim procps rsync tar xz-utils zstd jq
    useradd -m -s /bin/bash sandbox || true
  '
"

echo "==> copy flint-guest-agent"
run_root sh -c "
  set -e
  install -Dm755 ${AGENT_BIN:-../../target/debug/flint-guest-agent} $TARGET_DIR/usr/local/bin/flint-guest-agent
  mkdir -p $TARGET_DIR/var/lib/flint $TARGET_DIR/etc/systemd/system
"

run_root sh -c "
  cat > $TARGET_DIR/etc/systemd/system/flint-guest-agent.service <<'UNIT'
[Unit]
Description=Flint guest agent
After=multi-user.target

[Service]
# The agent reads its auth token from MMDS at 169.254.169.254.
ExecStart=/usr/local/bin/flint-guest-agent serve-vsock --vsock-port 5252 --port 0 --home / --sandbox-id \${FLINT_SANDBOX_ID} --token \${FLINT_AGENT_TOKEN}
Restart=always
RestartSec=1

[Install]
WantedBy=multi-user.target
UNIT
  chroot $TARGET_DIR systemctl enable flint-guest-agent 2>/dev/null || true
"

echo "==> build ext4 image"
run_root sh -c "
  set -e
  truncate -s ${SIZE_MB}M rootfs.ext4
  mkfs.ext4 -F -L flint-root rootfs.ext4
  mkdir -p /mnt/flint-rootfs
  mount -o loop rootfs.ext4 /mnt/flint-rootfs
  trap 'umount /mnt/flint-rootfs' EXIT
  cp -a $TARGET_DIR/. /mnt/flint-rootfs/
"

cat <<'EOF'
Done: rootfs.ext4 built.

Next steps:
  1. Fetch/build a Firecracker kernel (needs CONFIG_VIRTIO_VSOCKETS=y):
       curl -LO https://s3.amazonaws.com/spec.ccfc.firecracker.dev/firecracker-ci/v1.9.0/x86_64/vmlinux-6.1.102
       mv vmlinux-6.1.102 vmlinux
  2. Point the worker config at vmlinux + this rootfs.
  3. Create your first template by snapshotting a fresh sandbox and
     calling POST /v1/templates/from-sandbox/{id}.
EOF
