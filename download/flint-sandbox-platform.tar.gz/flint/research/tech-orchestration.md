# Fleet Orchestration for microVM Sandboxes (R4 research)

Sources: E2B runtime ARCHITECTURE.md + source (`packages/api/internal/orchestrator/placement`, `packages/orchestrator/pkg/scheduling`), Modal docs (cold start guide), AWS Lambda SnapStart, BuildBuddy "Snapshot, Chunk, Clone", Cloudflare/Durable-Objects-style patterns.

## 1. Control plane / data plane split

E2B's topology (verified in source): **API** (REST :80 + gRPC :5009/:5109, Postgres for durable entities — teams, templates, `env_builds`, `snapshots`; Redis for running-sandbox records + routing + rate limits) is the control plane; **orchestrator** (one Go binary per sandbox node, root, gRPC :5008, sandbox proxy :5007) is the data plane — it owns the Firecracker process, netns, NBD rootfs, cgroups, UFFD handler. Traffic never passes through the API: `client-proxy` (:3002) at the edge resolves `sandboxID → node` from a Redis routing record written by the orchestrator (`sandbox:routing:{id}`, TTL = sandbox max lifetime) and reverse-proxies straight to the node's proxy port. "The API decides **where** a sandbox runs and records **that** it runs; the orchestrator owns **how** it runs." Node discovery: Nomad, Kubernetes, or static list (E2B packages/shared/pkg/servicediscovery). Stateless control-plane services scale horizontally; sandbox nodes autoscale separately.

## 2. Scheduling: bin-packing vs best-of-K

- E2B placement (read from ARCHITECTURE.md): **best-of-K** — sample K ready nodes, score each by **max(CPU load, hugepage-pool load)**, pick the lowest; full-jitter exponential backoff on `ResourceExhausted` refusals (node stays eligible); nodes with no pool report score 0.5; K, overcommit ratio and alpha tunable via flags (`BEST_OF_K_HUGEPAGE_MEMORY` to rank on hugepages vs CPU). Hugepage pool matters because snapshots restore into 2M pages — memory placement is the binding constraint, not CPU.
- Why best-of-K over full bin-packing: fleet-scale sandbox arrival is bursty and short-lived; power-of-two-choices gives O(log log n) queue imbalance without a global view, and survives stale node state. Bin-packing (Kubernetes `MostAllocated` style) fits long-running pods, but for sub-second sandboxes, placement must cost < 10 ms — best-of-K over cached node snapshots wins. Kubernetes docs "Resource Bin Packing" (`kubernetes.io/docs/concepts/scheduling-eviction/resource-bin-packing`) recommends **the opposite** (pack tight) when scale-down is the goal; choose per workload class.
- Node-local admission (orchestrator `pkg/scheduling`): the orchestrator enforces its own `max_sandboxes`, hugepage availability, free disk (pause admission: guest RAM + rootfs cache + snapfile allowance, doubled if template storage is local), and drains (`Draining`/`ShuttingDown` states; `/health` returns 200 "draining"; SIGTERM/SIGINT/SIGUSR1 trigger drain; `FORCE_STOP` skips sandbox wait). Placement timeouts make an RPC to a draining node fail-fast.
- Oversubscription: Firecracker allows overcommit of CPU/RAM (design doc: "degree of oversubscription controlled by customers"). Practical pattern: cgroup cpu.weight + memory.high (not max) per FC process, balloon free-page-reporting to reclaim idle guest RAM, and a hard `memory.max` = template RAM + headroom so a bursting VM OOMs its own cgroup rather than the host.

## 3. Live migration is impossible → pause-snapshot-resume

Firecracker has **no live migration** (pre-copy memory would violate the minimal VMM design; KVMDirty-log exists only for snapshots). The standard alternative is the same lifecycle used for durability:

1. `PATCH /vm {"state":"Paused"}` (vCPUs stop; guest freezes mid-instruction).
2. `PUT /snapshot/create` (Full) — memory + device state to files; drain+fsync block devices.
3. Move/copy snapshot + disk diffs to target (or object storage).
4. Fresh FC process, `PUT /snapshot/load` (+ network/vsock overrides, UFFD backend) → `PATCH /vm {"state":"Resumed"}`.

E2B's managed lifecycle on top: **Pause** (API writes Postgres snapshot row → gRPC Pause → orchestrator pauses, snapshots, diffs memory (dirty-page) + rootfs (COW/NBD) vs template, caches locally, uploads async with retry budget; 80 s detached budget, 95 s Redis transition TTL); **Resume** = same path as create but **placement prefers the origin node** (local cache hit → no object storage reads); **Checkpoint** = pause + resume in place (persist state while keeping VM running — used for fork); **Fork** = checkpoint a live sandbox, then create N new sandboxes from that snapshot (up to **100 per request**) spread across nodes (forks do NOT prefer origin node); **auto-pause/auto-resume** — idle sandboxes pause; incoming traffic wakes them (client-proxy calls `ResumeSandbox` gRPC on routing miss and retries); a degraded auto-pause (node keeps refusing, e.g. dedup lag > 120 s budget) falls back to a **filesystem-only snapshot** (cold boot on next resume) so expiring sandboxes can't overstay. AWS Lambda SnapStart and BuildBuddy runners do the same at their scale (SnapStart restores snapshots on demand; BuildBuddy "Snapshot, Chunk, Clone" caches memory chunks globally).

## 4. Warm pools & cold-start amortization

- **Snapshot-as-warm-pool** (E2B/Modal Snapshots/Lambda SnapStart): warm = pre-booted template snapshot; "create" = resume (~5–30 ms eager, ms-scale with UFFD + prefetch; E2B quotes ~150 ms end-to-end including envd /init). Costs: memfiles in RAM (MAP_PRIVATE), storage, and CPU-template pinning. Amortizes *kernel+runtime* init, not user session state.
- **Modal (containers, docs/guide/cold-start)**: keep containers warm with `scaledown_window` (idle keep-alive; default 60 s, range 2 s–20 min), `min_containers` (floor of hot replicas; billing while idle), `buffer_containers` (headroom above current demand); autoscaler bores down aggressively when over-provisioned. Map to microVMs: `min_containers` ≈ pre-resumed paused snapshots pinned on nodes + N *running* idle VMs; `buffer` ≈ resume-in-flight pipelines. Modal cold-start guide distinguishes **queueing time** (no warm instance) vs **initialization time** (first-invocation work) — snapshots kill both.
- **Warm pool patterns to steal**: (1) per-template target = running_idle + paused_local + paused_remote; (2) refill on-create with jitter to avoid thundering herd after a burst; (3) predictive warm from request-rate slopes (E2B's ClickHouse metrics feed); (4) origin-node stickiness for resume; (5) chunk cache + peer-to-peer template distribution between nodes (E2B `ChunkService`: nodes serve template chunks to each other P2P before object-storage upload completes, plus optional shared NFS chunk cache).
- GKE "warm pools" (per Penligent roundup) is the managed-VM equivalent: pre-provisioned paused VMs resumed on demand.

## 5. Lifecycle accounting (what the control plane must track)

E2B state model, worth copying: Redis = source of truth for **running** sandboxes (execution_id, node, start time, TTL); Postgres = durable `snapshots` rows for paused ones (template id/build id linkage — "a paused sandbox has the same artifact shape as a template"); routing record guarded by `execution_id` (Lua-scripted CAS delete so a stale lifecycle can't remove a newer execution's route); sandbox **events** to ClickHouse for analytics + webhooks; host stats (cgroup gauges) to ClickHouse; OTel everywhere. Placement cache of node info with 30 s refresh (`maxSandboxes`, `outstandingWork` counters exposed via InfoService and used for admin deletion safety). Every mutating RPC carries a detached budget (80–95 s pause, 10 s terminal writes) so client cancellation never abandons a half-persisted snapshot.

## 6. Sizing rules of thumb (from sources)

- Boot: 125 ms cold (FC spec), + template resume ≈ 5–30 ms VM-side, ~150 ms user-visible create (E2B), 60 ms-class claims (28 ms "28ms sandboxes" dev.to build; Encore 28ms-class via UFFD).
- Density: 5 creates/sec/core; 1000+ VMs/host with 128–256 MB guests; 72-vCPU host ≈ 1020 active VMs in NSDI'20.
- Per-VM host overhead: ≤ 10 MB VMM RSS target + KVM structures (~few MB); jail adds chroot (~binary copy) + cgroup.
- Disk: each running VM holds rootfs COW cache (bounded by writes) + potential memfile (guest RAM size); pause uploads ≈ dirty pages + dirty blocks only.
