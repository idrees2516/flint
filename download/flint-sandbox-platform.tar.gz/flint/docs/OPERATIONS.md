# Operating Flint

## Topology

- **flint-gateway** (×1 active; SQLite metadata + object store config):
  REST/WS `:8080`, gRPC `:7473`. Scales horizontally later by moving the
  meta store to Postgres (one-crate change: everything goes through
  `flint-store::MetaStore`).
- **flint-worker** (×N): runs on KVM nodes. Owns sandboxes end-to-end:
  spawn, journal, snapshots, crash recovery, egress firewall. Each worker
  runs its `WorkerService` gRPC server (`worker_bind`) and registers with
  the gateway over `FleetService`.
- **Object store**: local dir (default) or any S3-compatible endpoint
  (MinIO, R2, Garage, AWS) holding snapshot layers + manifests +
  template bases.

## Bootstrapping

1. First gateway boot prints a one-time bootstrap API key (or pin one via
   `FLINT_BOOTSTRAP_API_KEY`).
2. Start workers with `gateway_addr` pointing at the gateway gRPC port.
   Placement needs ≥1 registered worker (heartbeats every 5s; stale
   after `routing_ttl_s`).
3. Build a guest rootfs (`deploy/guest-rootfs/build.sh`), create your
   first sandbox, install deps, then
   `POST /v1/templates/from-sandbox/{id}` — creation from that template
   is a snapshot restore, never a cold boot.

## Durability semantics (what you get, exactly)

- Every mutating op is appended to a per-sandbox WAL (CRC-framed,
  fsync'd per `journal.fsync` policy) **before** dispatch.
- Pause/stop/snapshot cut layer snapshots (tar.gz of the writable layer
  in dev; + Firecracker memfile/snapfile/drive in prod) uploaded to the
  object store, with `SnapshotRef` recorded in the WAL.
- **Crash of a VM or worker process**: the reconciler detects liveness
  loss, restores the newest snapshot, deterministically replays WAL
  ops recorded after it (full file payloads, idempotency keys), and
  re-spawns `restartable` processes from recorded specs. Uncommitted
  exec output is lost; journaled file state is not.
- **Clean pause (prod)**: full VM memory state is preserved and resumed.
- **Stop**: disk-only; processes are lost by design (documented loudly —
  the Runloop tier).

## Reconciliation & timeouts

Each supervisor ticks at `reconcile_interval_ms`:
- liveness → crash recovery (above), with retry-every-30-ticks in Error.
- `auto_pause_after_idle_ms` since the last *external* interaction →
  auto-pause (background compute does not count, Daytona semantics).
- `max_ttl_ms` wall-clock → `expiry_action`.
- Requests to a paused sandbox auto-resume when `wake_on_request` (the
  gateway's router triggers it transparently).

## Placement

Best-of-K sampling (K = `scheduler.placement_k`), score =
`max(cpu_pressure, mem_pressure, slot_pressure) + U(0, 0.05)`. Workers
report pressure via heartbeats; drained workers are skipped; admission
reserves `pause_headroom_mib` of disk so pauses always fit. On
`resource_exhausted` clients should retry with full jitter.

## Networking (prod)

Per sandbox: netns `flint-<slot>` + veth pair (IPAM `/31` pool) + TAP
`169.254.0.22/30`; guest NIC at `169.254.0.21/30` via kernel cmdline.
Egress policy via nftables (IP allow/deny + SNI domain allowlist path);
`net.default_policy = "deny"` gives default-deny. MASQUERADE at the netns
edge. All provisioning is idempotent and re-runnable.

## Metrics

`GET /metrics` (Prometheus text): `flint_ops_total{op,result}`,
`flint_sandboxes_active/paused`, `flint_exec_duration_ms`,
`flint_ws_connections`, `flint_snapshot_duration_ms` (via ops),
`flint_journal_wal_bytes`, `flint_tool_calls_total{tool,provider}`,
`flint_worker_heartbeats_total`.

## Scaling notes

- Workers are horizontally scalable; the scheduler is in-gateway.
- Routing table lives in SQLite (`routing`), TTL'd at max sandbox life.
- Snapshot I/O is bounded by the object store; the local store is fine
  for single-node deployments and dev.
- The data plane (exec/files) goes gateway→worker→agent directly; the
  meta store is never on the hot path.

## Backups

Everything durable lives in (a) the gateway data dir (`flint.sqlite3`)
and (b) the object store. Snap both and you can rebuild the world.
WALs live on worker nodes and travel into snapshots at pause time.
