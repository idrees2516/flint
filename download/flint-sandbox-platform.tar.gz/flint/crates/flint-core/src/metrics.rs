//! Minimal, dependency-free Prometheus metrics registry.
//!
//! Counters, gauges and fixed-bucket histograms registered lazily by
//! `name{label="value",...}` key, rendered in the Prometheus text
//! exposition format on demand. Hand-rolled to keep the dependency tree
//! lean; atomics everywhere so hot paths (per-exec, per-frame) never lock.

use std::collections::HashMap;
use std::sync::atomic::{AtomicI64, AtomicU64, Ordering};
use std::sync::{Mutex, OnceLock};
use std::time::Duration;

#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
struct MetricKey {
    name: &'static str,
    labels: Vec<(&'static str, String)>,
}

impl MetricKey {
    fn render(&self) -> String {
        if self.labels.is_empty() {
            self.name.to_string()
        } else {
            let pairs: Vec<String> =
                self.labels.iter().map(|(k, v)| format!("{k}=\"{}\"", escape(v))).collect();
            format!("{}{{{}}}", self.name, pairs.join(","))
        }
    }
}

fn escape(v: &str) -> String {
    v.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}

struct Counter(AtomicU64);
struct Gauge(AtomicI64);

#[derive(Default)]
struct Histogram {
    /// Upper bounds (in the observed unit).
    bounds: Vec<u64>,
    /// Per-bucket cumulative counts (bucket i counts observations <= bounds[i]).
    counts: Vec<AtomicU64>,
    count: AtomicU64,
    sum: AtomicU64,
}

impl Histogram {
    fn new(bounds: &[u64]) -> Self {
        Self {
            bounds: bounds.to_vec(),
            counts: bounds.iter().map(|_| AtomicU64::new(0)).collect(),
            count: AtomicU64::new(0),
            sum: AtomicU64::new(0),
        }
    }

    fn observe(&self, value: u64) {
        self.count.fetch_add(1, Ordering::Relaxed);
        self.sum.fetch_add(value, Ordering::Relaxed);
        for (i, b) in self.bounds.iter().enumerate() {
            if value <= *b {
                self.counts[i].fetch_add(1, Ordering::Relaxed);
            }
        }
    }
}

struct Registry {
    counters: Mutex<HashMap<MetricKey, Counter>>,
    gauges: Mutex<HashMap<MetricKey, Gauge>>,
    histograms: Mutex<HashMap<MetricKey, Histogram>>,
}

fn registry() -> &'static Registry {
    static REG: OnceLock<Registry> = OnceLock::new();
    REG.get_or_init(|| Registry {
        counters: Mutex::new(HashMap::new()),
        gauges: Mutex::new(HashMap::new()),
        histograms: Mutex::new(HashMap::new()),
    })
}

/// Increment a counter with labels.
pub fn counter_inc(name: &'static str, labels: &[(&'static str, String)]) {
    counter_add(name, labels, 1);
}

pub fn counter_add(name: &'static str, labels: &[(&'static str, String)], v: u64) {
    let key = MetricKey { name, labels: labels.to_vec() };
    let mut m = registry().counters.lock().unwrap();
    m.entry(key).or_insert_with(|| Counter(AtomicU64::new(0))).0.fetch_add(v, Ordering::Relaxed);
}

pub fn gauge_set(name: &'static str, labels: &[(&'static str, String)], v: i64) {
    let key = MetricKey { name, labels: labels.to_vec() };
    let mut m = registry().gauges.lock().unwrap();
    m.entry(key).or_insert_with(|| Gauge(AtomicI64::new(0))).0.store(v, Ordering::Relaxed);
}

pub fn gauge_add(name: &'static str, labels: &[(&'static str, String)], v: i64) {
    let key = MetricKey { name, labels: labels.to_vec() };
    let mut m = registry().gauges.lock().unwrap();
    m.entry(key).or_insert_with(|| Gauge(AtomicI64::new(0))).0.fetch_add(v, Ordering::Relaxed);
}

/// Default time histogram buckets (ms): 1, 5, 10, 25, 50, 100, 250, 500,
/// 1000, 2500, 5000, 10000, +Inf.
pub const TIME_BOUNDS_MS: [u64; 12] = [1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000];

/// Observe a duration (milliseconds) on a time histogram.
pub fn observe_duration_ms(name: &'static str, labels: &[(&'static str, String)], d: Duration) {
    observe_value(name, labels, d.as_millis() as u64, &TIME_BOUNDS_MS);
}

/// Observe an arbitrary value against custom bounds.
pub fn observe_value(
    name: &'static str,
    labels: &[(&'static str, String)],
    value: u64,
    bounds: &[u64],
) {
    let key = MetricKey { name, labels: labels.to_vec() };
    let mut m = registry().histograms.lock().unwrap();
    m.entry(key).or_insert_with(|| Histogram::new(bounds)).observe(value);
}

/// Render the whole registry in Prometheus text format.
pub fn render() -> String {
    let mut out = String::with_capacity(4096);
    let reg = registry();

    let counters_guard = reg.counters.lock().unwrap();
    let mut counters: Vec<(&MetricKey, &Counter)> = counters_guard.iter().map(|(k, v)| (k, v)).collect();
    counters.sort_by(|a, b| a.0.cmp(b.0));
    for (k, c) in counters {
        out.push_str(&format!(
            "# TYPE {} counter\n{} {}\n",
            k.name,
            k.render(),
            c.0.load(Ordering::Relaxed)
        ));
    }
    drop(counters_guard);

    let gauges_guard = reg.gauges.lock().unwrap();
    let mut gauges: Vec<(&MetricKey, &Gauge)> = gauges_guard.iter().map(|(k, v)| (k, v)).collect();
    gauges.sort_by(|a, b| a.0.cmp(b.0));
    for (k, g) in gauges {
        out.push_str(&format!(
            "# TYPE {} gauge\n{} {}\n",
            k.name,
            k.render(),
            g.0.load(Ordering::Relaxed)
        ));
    }
    drop(gauges_guard);

    let hists_guard = reg.histograms.lock().unwrap();
    let mut hists: Vec<(&MetricKey, &Histogram)> = hists_guard.iter().map(|(k, v)| (k, v)).collect();
    hists.sort_by(|a, b| a.0.cmp(b.0));
    for (k, h) in hists {
        let count = h.count.load(Ordering::Relaxed);
        let sum = h.sum.load(Ordering::Relaxed);
        out.push_str(&format!("# TYPE {} histogram\n", k.name));
        for (i, b) in h.bounds.iter().enumerate() {
            out.push_str(&format!("{}_bucket{{le=\"{}\"}} {}\n", k.render(), b, h.counts[i].load(Ordering::Relaxed)));
        }
        out.push_str(&format!("{}_bucket{{le=\"+Inf\"}} {}\n", k.render(), count));
        out.push_str(&format!("{}_sum {}\n", k.render(), sum));
        out.push_str(&format!("{}_count {}\n", k.render(), count));
    }
    drop(hists_guard);
    out
}

/// Well-known metric names.
pub mod names {
    pub const OPS_TOTAL: &str = "flint_ops_total";
    pub const SANDBOXES_ACTIVE: &str = "flint_sandboxes_active";
    pub const SANDBOXES_PAUSED: &str = "flint_sandboxes_paused";
    pub const EXEC_DURATION_MS: &str = "flint_exec_duration_ms";
    pub const WS_CONNECTIONS: &str = "flint_ws_connections";
    pub const SNAPSHOT_DURATION_MS: &str = "flint_snapshot_duration_ms";
    pub const WAL_BYTES: &str = "flint_journal_wal_bytes";
    pub const TOOL_CALLS_TOTAL: &str = "flint_tool_calls_total";
    pub const WORKER_HEARTBEATS: &str = "flint_worker_heartbeats_total";
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn renders_prometheus_text() {
        counter_inc("flint_test_total", &[("op", "exec".into()), ("result", "ok".into())]);
        gauge_set("flint_test_gauge", &[], 42);
        observe_duration_ms("flint_test_ms", &[], Duration::from_millis(7));
        let text = render();
        assert!(text.contains("flint_test_total{op=\"exec\",result=\"ok\"}"));
        assert!(text.contains("flint_test_gauge 42"));
        assert!(text.contains("flint_test_ms_bucket{le=\"10\"}"));
    }
}
