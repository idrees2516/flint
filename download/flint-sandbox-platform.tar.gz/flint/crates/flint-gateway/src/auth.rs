//! Gateway auth: API-key extraction, quota + rate-limit enforcement.

use flint_core::{FlintError, Result};
use flint_store::{ApiKeyRow, KeyQuotas, MetaStore};
use std::collections::HashMap;
use std::sync::Arc;
pub struct Auth {
    pub store: Arc<MetaStore>,
    pub limits: flint_core::config::LimitsConfig,
    buckets: flint_core::ratelimit::KeyedBuckets<String>,
}

impl Auth {
    pub fn new(store: Arc<MetaStore>, limits: flint_core::config::LimitsConfig) -> Self {
        let rate = limits.max_req_per_sec_per_key.max(0.1);
        Self {
            store,
            limits,
            buckets: flint_core::ratelimit::KeyedBuckets::new(rate, rate, 10_000),
        }
    }

    /// Extract the raw key from `Authorization: Bearer ...` or
    /// `x-api-key: ...`.
    pub fn extract_key(headers: &axum::http::HeaderMap) -> Option<String> {
        if let Some(auth) = headers.get("authorization").and_then(|v| v.to_str().ok()) {
            if let Some(token) = auth.strip_prefix("Bearer ").or_else(|| auth.strip_prefix("bearer ")) {
                let t = token.trim();
                if !t.is_empty() {
                    return Some(t.to_string());
                }
            }
        }
        headers
            .get("x-api-key")
            .and_then(|v| v.to_str().ok())
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
    }

    pub fn authenticate(&self, headers: &axum::http::HeaderMap) -> Result<ApiKeyRow> {
        let key = Self::extract_key(headers)
            .ok_or(FlintError::Unauthenticated { msg: "missing API key (Authorization: Bearer or x-api-key)".into() })?;
        let hash = flint_core::tokens::hash_api_key(&key);
        let row = self
            .store
            .find_api_key_by_hash(&hash)?
            .ok_or(FlintError::Unauthenticated { msg: "invalid API key".into() })?;
        if !self.buckets.allow(&row.key_id) {
            return Err(FlintError::RateLimited { retry_after_ms: 1000 });
        }
        Ok(row)
    }

    /// Effective quotas for a key (per-key override or platform default).
    pub fn quotas_for(&self, row: &ApiKeyRow) -> KeyQuotas {
        let d = &self.limits;
        KeyQuotas {
            max_concurrent_sandboxes: if row.quotas.max_concurrent_sandboxes > 0 {
                row.quotas.max_concurrent_sandboxes
            } else {
                d.max_concurrent_sandboxes_per_key as i64
            },
            max_req_per_sec: if row.quotas.max_req_per_sec > 0.0 { row.quotas.max_req_per_sec } else { d.max_req_per_sec_per_key },
            max_tool_calls_per_day: if row.quotas.max_tool_calls_per_day > 0 {
                row.quotas.max_tool_calls_per_day
            } else {
                d.max_tool_calls_per_day_per_key as i64
            },
        }
    }

    pub fn enforce_sandbox_quota(&self, row: &ApiKeyRow) -> Result<()> {
        let quotas = self.quotas_for(row);
        let active = self.store.count_active_sandboxes(&row.key_id)?;
        if active >= quotas.max_concurrent_sandboxes {
            return Err(FlintError::QuotaExceeded {
                quota: format!("max_concurrent_sandboxes ({})", quotas.max_concurrent_sandboxes),
            });
        }
        Ok(())
    }

    pub fn enforce_tool_quota(&self, row: &ApiKeyRow) -> Result<()> {
        let quotas = self.quotas_for(row);
        let today = self.store.tool_calls_today(&row.key_id)?;
        if today >= quotas.max_tool_calls_per_day {
            return Err(FlintError::QuotaExceeded {
                quota: format!("max_tool_calls_per_day ({})", quotas.max_tool_calls_per_day),
            });
        }
        self.store.record_tool_call(&row.key_id)?;
        Ok(())
    }
}

/// Map a FlintError to an axum response with the platform error body.
pub fn error_response(e: &FlintError) -> axum::response::Response {
    use axum::http::StatusCode;
    let status = StatusCode::from_u16(e.http_status()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    let body = serde_json::json!({
        "error": {
            "code": e.code(),
            "message": e.to_string(),
        }
    });
    let retry = if let FlintError::RateLimited { retry_after_ms } = e {
        Some(retry_after_ms.to_string())
    } else {
        None
    };
    let mut resp = axum::Json(body).into_response();
    *resp.status_mut() = status;
    if let Some(r) = retry {
        resp.headers_mut().insert("Retry-After", r.parse().unwrap_or_else(|_| "1".parse().unwrap()));
    }
    resp
}

use axum::response::IntoResponse;

/// Simple in-memory event bus for sandbox events (WS /events).
pub struct EventBus {
    subs: tokio::sync::RwLock<HashMap<String, Vec<tokio::sync::mpsc::Sender<serde_json::Value>>>>,
}

impl Default for EventBus {
    fn default() -> Self {
        Self { subs: tokio::sync::RwLock::new(HashMap::new()) }
    }
}

impl EventBus {
    pub async fn publish(&self, sandbox_id: &str, event: serde_json::Value) {
        let mut subs = self.subs.write().await;
        if let Some(list) = subs.get_mut(sandbox_id) {
            list.retain(|tx| {
                tx.try_send(event.clone()).is_ok()
            });
        }
    }

    pub async fn subscribe(&self, sandbox_id: &str) -> tokio::sync::mpsc::Receiver<serde_json::Value> {
        let (tx, rx) = tokio::sync::mpsc::channel(64);
        self.subs.write().await.entry(sandbox_id.to_string()).or_default().push(tx);
        rx
    }

}
