//! `flint-worker` — node daemon binary.

use clap::Parser;
use flint_core::config::{env_path, env_str, load_toml, WorkerConfig};

#[derive(Parser, Debug)]
#[command(name = "flint-worker", about = "Flint node daemon")]
struct Cli {
    /// Path to flint-worker.toml.
    #[arg(long)]
    config: Option<String>,
    /// Dev mode: process driver + localhost defaults.
    #[arg(long)]
    dev: bool,
    /// Override node id.
    #[arg(long)]
    node_id: Option<String>,
    /// Override gateway gRPC address.
    #[arg(long)]
    gateway: Option<String>,
    /// Override worker bind address.
    #[arg(long)]
    bind: Option<String>,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()),
        )
        .init();

    let cli = Cli::parse();
    let cfg_path = cli
        .config
        .map(std::path::PathBuf::from)
        .or_else(|| env_path("FLINT_CONFIG"))
        .or_else(|| std::path::PathBuf::from("flint-worker.toml").exists().then(|| std::path::PathBuf::from("flint-worker.toml")));
    let mut cfg: WorkerConfig = load_toml(cfg_path.as_deref())?;
    if cli.dev {
        cfg.driver = flint_core::config::DriverConfig::Process {
            guest_agent_bin: env_str("FLINT_GUEST_AGENT_BIN"),
            sandbox_root: None,
        };
    }
    if let Some(id) = cli.node_id {
        cfg.node_id = id;
    }
    if let Some(g) = cli.gateway {
        cfg.gateway_addr = g;
    }
    if let Some(b) = cli.bind {
        cfg.worker_bind = b;
    }
    if let Some(d) = env_path("FLINT_WORK_DIR") {
        cfg.work_dir = d;
    }

    let _worker = flint_worker::WorkerRuntime::start(cfg).await?;

    tokio::signal::ctrl_c().await?;
    tracing::info!("shutting down");
    Ok(())
}
