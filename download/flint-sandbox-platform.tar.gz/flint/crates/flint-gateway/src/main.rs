//! `flint-gateway` — the control plane binary.
//!
//! Serves REST + WebSocket on `bind_http`, and gRPC (public API + fleet)
//! on `bind_grpc`. `--dev` embeds a local process-driver worker so the
//! entire platform runs as a single binary on laptops and CI (no KVM
//! needed) — production splits the worker out onto microVM nodes.

mod auth;
mod grpc_api;
mod ops;
mod rest;
mod worker_rpc;

use clap::Parser;
use flint_core::config::{env_path, env_str, load_toml, GatewayConfig};
use std::sync::Arc;

#[derive(Parser, Debug)]
#[command(name = "flint-gateway", about = "Flint control plane")]
struct Cli {
    /// Path to flint-gateway.toml.
    #[arg(long)]
    config: Option<String>,
    /// Embed a local process-driver worker (dev/CI mode; no isolation).
    #[arg(long)]
    dev: bool,
    /// Override REST bind.
    #[arg(long)]
    bind: Option<String>,
    /// Override gRPC bind.
    #[arg(long)]
    bind_grpc: Option<String>,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()),
        )
        .init();

    let cli = Cli::parse();
    let cfg_path = cli
        .config
        .map(std::path::PathBuf::from)
        .or_else(|| env_path("FLINT_CONFIG"))
        .or_else(|| std::path::PathBuf::from("flint-gateway.toml").exists().then(|| std::path::PathBuf::from("flint-gateway.toml")));
    let mut cfg: GatewayConfig = load_toml(cfg_path.as_deref())?;
    if let Some(b) = cli.bind {
        cfg.bind_http = b;
    }
    if let Some(b) = cli.bind_grpc {
        cfg.bind_grpc = b;
    }
    if let Some(d) = env_path("FLINT_DATA_DIR") {
        cfg.data_dir = d;
    }
    std::fs::create_dir_all(&cfg.data_dir)?;

    // Meta store + gateway core.
    let store = Arc::new(flint_store::open_meta_store(&cfg.data_dir)?);
    let gw = ops::Gateway::new(cfg.clone(), store.clone())?;

    // Bootstrap API key on first boot.
    if let Some(secret) = gw.bootstrap_key()? {
        tracing::warn!("first boot: bootstrap API key (shown ONCE): {secret}");
        println!("FLINT_BOOTSTRAP_API_KEY={secret}");
    }

    // Dev mode: embedded worker registering with this gateway over real
    // gRPC (loopback) — the exact production protocol path.
    if cli.dev {
        let grpc_bind = cfg.bind_grpc.clone();
        let mut worker_cfg = flint_core::config::WorkerConfig {
            gateway_addr: format!("http://{grpc_bind}"),
            driver: flint_core::config::DriverConfig::Process {
                guest_agent_bin: env_str("FLINT_GUEST_AGENT_BIN"),
                sandbox_root: None,
            },
            work_dir: cfg.data_dir.join("dev-worker"),
            object_store: cfg.object_store.clone(),
            ..Default::default()
        };
        // Pick a free worker port to avoid collisions.
        let probe = std::net::TcpListener::bind("127.0.0.1:0")?;
        let port = probe.local_addr()?.port();
        drop(probe);
        worker_cfg.worker_bind = format!("127.0.0.1:{port}");
        let worker = flint_worker::WorkerRuntime::start(worker_cfg).await?;
        let _ = worker; // kept alive by its tasks
        tracing::info!(addr = %format!("127.0.0.1:{port}"), "embedded dev worker started (process driver, NO isolation)");
    }

    // REST + WS.
    let rest_bind: std::net::SocketAddr = cfg.bind_http.parse()?;
    let rest_listener = tokio::net::TcpListener::bind(rest_bind).await?;
    tracing::info!(addr = %rest_bind, "REST+WS listening");
    let app = rest::router(gw.clone());
    let rest_task = tokio::spawn(async move {
        axum::serve(rest_listener, app)
            .await
            .map_err(|e| anyhow::anyhow!("rest serve: {e}"))
    });

    // gRPC (public API + fleet).
    let grpc_bind: std::net::SocketAddr = cfg.bind_grpc.parse()?;
    let grpc_listener = tokio::net::TcpListener::bind(grpc_bind).await?;
    tracing::info!(addr = %grpc_bind, "gRPC listening");
    use flint_proto::api::exec_service_server::ExecServiceServer;
    use flint_proto::api::file_service_server::FileServiceServer;
    use flint_proto::api::sandbox_service_server::SandboxServiceServer;
    use flint_proto::api::template_service_server::TemplateServiceServer;
    use flint_proto::api::tool_service_server::ToolServiceServer;
    use flint_proto::fleet::fleet_report_server::FleetReportServer;
    use flint_proto::fleet::fleet_service_server::FleetServiceServer;
    let api = grpc_api::ApiServer { gw: gw.clone() };
    let fleet = grpc_api::FleetServer { gw: gw.clone() };
    let grpc_task = tokio::spawn(async move {
        tonic::transport::Server::builder()
            .add_service(SandboxServiceServer::new(api.clone()))
            .add_service(ExecServiceServer::new(api.clone()))
            .add_service(FileServiceServer::new(api.clone()))
            .add_service(ToolServiceServer::new(api.clone()))
            .add_service(TemplateServiceServer::new(api))
            .add_service(FleetServiceServer::new(fleet.clone()))
            .add_service(FleetReportServer::new(fleet))
            .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(grpc_listener))
            .await
            .map_err(|e| anyhow::anyhow!("grpc serve: {e}"))
    });

    tokio::select! {
        r = rest_task => {
            r??;
            Ok(())
        }
        r = grpc_task => {
            r??;
            Ok(())
        }
        _ = tokio::signal::ctrl_c() => {
            tracing::info!("shutting down");
            Ok(())
        }
    }
}
