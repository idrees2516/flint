//! Prefixed, sortable, greppable identifiers.
//!
//! Every id is `<prefix>_<hex millis>_<hex rand>`: sortable by creation
//! time, safe in URLs and file names, and instantly recognizable in logs
//! (research: E2B / Daytona / Morph all use prefixed ids for this reason).

use rand::Rng;
use std::time::{SystemTime, UNIX_EPOCH};

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// Generate a new prefixed id, e.g. `sbx_18f3a1b2c3d4_9a1c2d3e4f5a6b7c`.
pub fn new_id(prefix: &str) -> String {
    let ms = now_ms();
    let rand: u128 = rand::thread_rng().gen();
    format!("{prefix}_{ms:012x}{rand:016x}")
}

/// Extract the prefix of an id (the part before the first `_`), if any.
pub fn id_prefix(id: &str) -> Option<&str> {
    id.split('_').next().filter(|s| !s.is_empty())
}

/// Well-known id prefixes.
pub mod prefixes {
    pub const SANDBOX: &str = "sbx";
    pub const TEMPLATE: &str = "tpl";
    pub const SNAPSHOT: &str = "snap";
    pub const WORKER: &str = "wrk";
    pub const PROCESS: &str = "prc";
    pub const API_KEY: &str = "key";
    pub const OP: &str = "op";
    pub const EXEC: &str = "ex_";
    pub const FORK: &str = "frk";
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ids_are_prefixed_and_unique() {
        let a = new_id("sbx");
        let b = new_id("sbx");
        assert!(a.starts_with("sbx_"));
        assert_ne!(a, b);
        assert_eq!(id_prefix(&a), Some("sbx"));
    }
}
