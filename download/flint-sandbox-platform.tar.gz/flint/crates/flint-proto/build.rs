fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Use the vendored protoc so builds work without a system install.
    let protoc = protoc_bin_vendored::protoc_bin_path()?;
    std::env::set_var("PROTOC", protoc);
    tonic_build::configure()
        .build_server(true)
        .build_client(true)
        .compile_protos(&["../../proto/api.proto", "../../proto/fleet.proto"], &["../../proto"])?;
    Ok(())
}
