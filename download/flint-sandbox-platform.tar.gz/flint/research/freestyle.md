# Freestyle (freestyle.sh) — full Linux VMs for AI agents

## Overview
Freestyle ("a cloud for coding agents") sells **full Linux virtual machines** — up to 32 vCPU / 64 GB — positioned as "real VMs, not toy sandboxes": complete Debian/Ubuntu machines with systemd, multiple users, FUSE, eBPF and nested virtualization ("the OS is the interface"; blog: *Why AI Sandboxes Suck*). Tagline: "A full Linux machine, ready in 65 ms. Copy a running VM, memory included." Customers are platforms (Bloom, Onlook, Wordware, a0) rather than individual devs. History: they first shipped an **open-source, self-hostable Docker-sandbox server** (npm `freestyle-sh`, 2024) and then pivoted to a hosted, bare-metal microVM platform; on HN (thread 47663147) the founders note the new stack "is unfriendly to small nodes" (optimizations kick in above ~2 TB storage / ~500 GB RAM per host), so the hosted product is the path today.

## Isolation & Architecture
- **KVM full VMs on Freestyle-owned bare-metal racks** (they bought hardware after quoting hyperscaler bare metal) — not containers, not gVisor.
- Provisioning from warm **base snapshots**: full machine ready in **65 ms** (p99 < 400 ms; "boot under 600 ms with restored memory" in third-party profiles).
- **Live fork of a running VM with whole memory**: copy-on-write on memory itself, **< 400 ms pause**, and — the headline claim — **fork time is O(1) in both VM size and number of forks** (vs snapshots, which impose a 2–4 s IO interruption). Demo: fork a running Minecraft server mid-game; every fork resumes at the same animation frame.
- **Default-deny firewall** — rules are mandatory at creation; a VM "reaches nothing it has not been allowed to". Private VPCs, WireGuard tunnels from your laptop into the private network, outbound/inbound TLS policy, optional per-VM public IP, forward-auth at the edge.

## API Surface
TypeScript SDK (`freestyle`), Python SDK, CLI, plus REST at `api.freestyle.sh`; **Rust SDKs live in the open `freestyle-sh/sandbox_sdks` repo**. Core objects: `freestyle.vms.create({ firewall, slug, metadata, snapshotId, networks, idleTimeoutSeconds })`; `vm.exec()` (max 5 min; use PTY sessions for interactive/long); `vm.fs.*` including resumable large uploads, streaming downloads and **read/browse files while the VM stays paused**; `vm.pause()/start()/delete()/data()/update()`; `vm.resize({cpu, memory, storage})` — **grow-only and live** (CPU/memory hot-add without reboot); scoped SSH identity tokens; **client sessions** letting end users operate a VM with scoped tokens; domains: free `*.style.dev` or verified custom domains + wildcards, TLS rules routing `domain → vm:port`.

## Persistence & Lifecycle
Explicit state machine: `running → paused → stopped → snapshot → deleted` ("durable runtime objects"). **Paused** freezes the VM with memory intact (same processes, open files; "come back weeks later"), does **not** count against concurrency limits and bills **storage only**. **Stopped** keeps disk, discards memory. Lifecycle policies: `ttlSeconds`, `maxRunSeconds` (pause after N running seconds; budget resets per start), `maxRunTotalSeconds`, `autoDeleteSeconds`. Idle timeout auto-pauses on network inactivity; the next request wakes the VM (after forward-auth for protected domains). **Snapshots** capture memory+disk for branching/cloning; public **base snapshots** (`freestyle/busybox` 1c/128MiB … `freestyle/ubuntu-3xl` 64c/128GiB/256GB) boot in ~1 s and don't count against snapshot limits.

## Agent-Specific Features
Guides for Claude Code (baked into a snapshot, driven over PTY / one-off prompts / Agent SDK `SandboxClient`), Copilot, OpenAI Agents SDK, Mastra `Workspace`, Chromium automation, GNOME desktop + noVNC, Docker/Compose, Postgres/Redis/Mongo/Supabase/Neon/Convex, credential injection, private git repos, Jupyter, mitmproxy inspection. Multi-tenancy: slug-keyed VMs + identity system + per-tenant network isolation. Freestyle Sync offloads a local dev environment in one command. Docs are aggressively agent-native: llms.txt, markdown pages, and a "freestyle-docs skill" onboarding file that asks AI agents to read before summarizing.

## Pricing & Limits
Plans set **minimums that are fully usable as usage credits**: Free $0 (up to 10 concurrent VMs; hard stops, no overage; $1 card check refunded), **Hobby $50/mo** (40 concurrent), **Pro $500/mo** (400 concurrent), Enterprise (SAML/SCIM, audit logs, 99.99% SLA). Usage, metered per second and billed per allocated-resource-hour ("a reserved core is yours whether or not the guest is busy"): **vCPU $0.04032/hr, memory $0.0129/GiB-hr, storage $0.000086/GiB-hr, transfer $0.02/GB**. Free included monthly (every plan, resets): 200 vCPU-hr, 400 GiB-hr memory, 60,000 GiB-hr storage, 50 GB transfer. Paused VMs bill storage only.

## Open-Source & Engineering Notes (URLs)
- github.com/freestyle-sh — `sandbox_sdks` (Rust), `sandbox-sdks-py`, `rigkit`, `freestyle-kubernetes` (k8s across Freestyle VMs via KIND), `freestyle-sync`; the original self-hostable Docker sandbox server is retired. Core VM stack is closed.
- Docs: www.freestyle.sh/docs (+ /docs/llms.txt, onboard.md), www.freestyle.sh/pricing.md.
- HN launch: news.ycombinator.com/item?id=47663147 (CoW forking mechanics, bare-metal economics, DIY alternatives: sysbox/gVisor/bubblewrap/firecracker/cloud-hypervisor).
- Blog: freestyle.sh/blog (*Version control for AI agents*, *Checkpoints not syncs*, *Private networking for AI agents*, …).

## Lessons for a Rust implementation
1. **O(1) copy-on-write fork of live memory** is achievable outside hyperscalers — fork-the-machine is *the* primitive for agent exploration/eval trees; design the snapshot layer CoW-first.
2. **Pause = free compute, paid storage**, and paused VMs shouldn't consume concurrency budget — separates two user-facing budgets cleanly.
3. **Default-deny networking declared at creation** (not opt-in) is the right secure default for untrusted agent code.
4. **Read files out of a paused VM** (mount the snapshot) avoids paying compute for artifact retrieval.
5. **Live grow-only resize** (CPU/mem without reboot) is sticky for platforms.
6. **Agent-native docs as a distribution channel** (llms.txt + markdown + an onboarding "skill" file) cost little and market to the exact audience choosing tools.
