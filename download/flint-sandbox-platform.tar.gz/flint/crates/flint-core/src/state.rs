//! The sandbox lifecycle state machine.
//!
//! Research note (Daytona): an *explicit, typed* state machine with a
//! published transition table + a reconciler beats ad-hoc status flags.
//! Every mutating call in the platform is validated with
//! [`can_transition`] before any work happens, and the worker reconciler
//! drives drift (crashed VM, worker restart) toward the recorded desired
//! state instead of inventing new states.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SandboxState {
    /// Provisioning (restoring snapshot / booting / creating dirs).
    Creating,
    /// Running and serving requests.
    Running,
    /// Transitioning into Paused (freezing + exporting layers).
    Pausing,
    /// VM memory + disk snapshotted; storage-only billing; resumable.
    Paused,
    /// Transitioning out of Paused.
    Resuming,
    /// Transitioning into Stopped.
    Stopping,
    /// Disk persisted, processes lost; cheap; restartable (resume ≢ state).
    Stopped,
    /// Taking an explicit snapshot (still Running afterwards).
    Snapshotting,
    /// Creating a fork/branch clone.
    Forking,
    /// Unrecoverable local error (e.g. driver failure); restartable.
    Error,
    /// Terminal.
    Deleted,
}

impl SandboxState {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Creating => "creating",
            Self::Running => "running",
            Self::Pausing => "pausing",
            Self::Paused => "paused",
            Self::Resuming => "resuming",
            Self::Stopping => "stopping",
            Self::Stopped => "stopped",
            Self::Snapshotting => "snapshotting",
            Self::Forking => "forking",
            Self::Error => "error",
            Self::Deleted => "deleted",
        }
    }

    /// States that keep resources on a worker.
    pub fn is_active(&self) -> bool {
        matches!(
            self,
            Self::Creating | Self::Running | Self::Pausing | Self::Resuming | Self::Snapshotting | Self::Forking
        )
    }

    /// States billed storage-only (research: paused sandboxes must be
    /// indefinite + cheap — E2B/Morph semantics).
    pub fn is_hibernated(&self) -> bool {
        matches!(self, Self::Paused | Self::Stopped)
    }
}

impl std::fmt::Display for SandboxState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// The single source of truth for legal transitions.
pub fn can_transition(from: SandboxState, to: SandboxState) -> bool {
    use SandboxState::*;
    if from == to {
        return true; // idempotent no-op transitions are allowed
    }
    match from {
        Creating => matches!(to, Running | Error | Deleted),
        Running => {
            matches!(to, Pausing | Stopping | Snapshotting | Forking | Error | Deleted)
        }
        Pausing => matches!(to, Paused | Running | Error | Deleted),
        Paused => matches!(to, Resuming | Stopping | Forking | Error | Deleted),
        Resuming => matches!(to, Running | Error | Deleted),
        Stopping => matches!(to, Stopped | Running | Error | Deleted),
        Stopped => matches!(to, Creating | Forking | Error | Deleted),
        Snapshotting => matches!(to, Running | Error | Deleted),
        Forking => matches!(to, Running | Paused | Stopped | Error | Deleted),
        Error => matches!(to, Creating | Deleted),
        Deleted => false,
    }
}

/// What happens when the TTL / expiry fires.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum ExpiryAction {
    /// Pause (memory-preserving) — the recommended default.
    #[default]
    Pause,
    /// Stop (disk-only, processes lost).
    Stop,
    /// Delete entirely.
    Delete,
}

/// Timeout / lifecycle policy (research: Daytona auto-stop/pause/archive
/// intervals + Morph TTL expiry-action + Runloop idle-suspend + E2B
/// wake-on-traffic all collapse into this one struct).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TimeoutPolicy {
    /// Idle → auto-pause. `None` disables.
    #[serde(default = "default_auto_pause_ms")]
    pub auto_pause_after_idle_ms: Option<u64>,
    /// Idle → auto-stop (overrides pause if both set and stop is sooner).
    pub auto_stop_after_idle_ms: Option<u64>,
    /// Hard wall-clock cap regardless of activity.
    #[serde(default = "default_max_ttl_ms")]
    pub max_ttl_ms: Option<u64>,
    /// Action taken when `max_ttl_ms` fires.
    #[serde(default)]
    pub expiry_action: ExpiryAction,
    /// Auto-resume when a request arrives while paused (wake-on-traffic).
    #[serde(default = "default_true")]
    pub wake_on_request: bool,
}

fn default_auto_pause_ms() -> Option<u64> {
    Some(15 * 60 * 1000)
}
fn default_max_ttl_ms() -> Option<u64> {
    Some(24 * 60 * 60 * 1000)
}
fn default_true() -> bool {
    true
}

impl Default for TimeoutPolicy {
    fn default() -> Self {
        Self {
            auto_pause_after_idle_ms: default_auto_pause_ms(),
            auto_stop_after_idle_ms: None,
            max_ttl_ms: default_max_ttl_ms(),
            expiry_action: ExpiryAction::Pause,
            wake_on_request: default_true(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transitions_match_architecture_diagram() {
        assert!(can_transition(SandboxState::Creating, SandboxState::Running));
        assert!(can_transition(SandboxState::Running, SandboxState::Pausing));
        assert!(can_transition(SandboxState::Pausing, SandboxState::Paused));
        assert!(can_transition(SandboxState::Paused, SandboxState::Resuming));
        assert!(can_transition(SandboxState::Resuming, SandboxState::Running));
        assert!(can_transition(SandboxState::Stopped, SandboxState::Creating));
        assert!(can_transition(SandboxState::Running, SandboxState::Forking));
        // illegal
        assert!(!can_transition(SandboxState::Creating, SandboxState::Paused));
        assert!(!can_transition(SandboxState::Deleted, SandboxState::Running));
    }
}
