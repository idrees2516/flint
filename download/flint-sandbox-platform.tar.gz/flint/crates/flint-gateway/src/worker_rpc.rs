//! Worker RPC client: lifecycle calls + the generic Operate pipe.

use flint_core::{FlintError, Result};
use flint_proto::fleet::worker_service_client::WorkerServiceClient;
use flint_proto::fleet::{
    DeleteSandboxLocalRequest, OpEnvelope, OpEvent, PauseSandboxRequest, ResumeSandboxRequest,
    SnapshotSandboxRequest, StartSandboxRequest, StopSandboxRequest,
};
use serde_json::Value;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use tonic::transport::Channel;

/// Cached, lazily-(re)connected clients per worker address.
#[derive(Clone)]
pub struct WorkerRpcPool {
    clients: Arc<RwLock<HashMap<String, WorkerServiceClient<Channel>>>>,
}

impl Default for WorkerRpcPool {
    fn default() -> Self {
        Self { clients: Arc::new(RwLock::new(HashMap::new())) }
    }
}

impl WorkerRpcPool {
    pub fn new() -> Self {
        Self::default()
    }

    async fn client(&self, addr: &str) -> Result<WorkerServiceClient<Channel>> {
        {
            let map = self.clients.read().await;
            if let Some(c) = map.get(addr) {
                return Ok(c.clone());
            }
        }
        let c = WorkerServiceClient::connect(addr.to_string())
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("worker {addr}: {e}") })?;
        self.clients.write().await.insert(addr.to_string(), c.clone());
        Ok(c)
    }

    async fn drop_client(&self, addr: &str) {
        self.clients.write().await.remove(addr);
    }

    pub async fn start_sandbox(&self, addr: &str, req: StartSandboxRequest) -> Result<()> {
        for attempt in 0..3 {
            let mut c = self.client(addr).await?;
            match c.start_sandbox(tonic::Request::new(req.clone())).await {
                Ok(resp) => {
                    let r = resp.into_inner();
                    if r.ok {
                        return Ok(());
                    }
                    return Err(FlintError::Internal(format!("worker start: {}", r.error)));
                }
                Err(e) => {
                    self.drop_client(addr).await;
                    if attempt == 2 {
                        return Err(FlintError::Unavailable { msg: format!("worker start rpc: {e}") });
                    }
                }
            }
        }
        Err(FlintError::Unavailable { msg: "worker unreachable".into() })
    }

    pub async fn pause_sandbox(&self, addr: &str, sandbox_id: &str) -> Result<String> {
        let mut c = self.client(addr).await?;
        let resp = c
            .pause_sandbox(PauseSandboxRequest { sandbox_id: sandbox_id.into() })
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("pause rpc: {e}") })?
            .into_inner();
        if resp.ok {
            Ok(resp.snapshot_id)
        } else {
            Err(FlintError::Internal(format!("pause: {}", resp.error)))
        }
    }

    pub async fn resume_sandbox(&self, addr: &str, sandbox_id: &str) -> Result<()> {
        let mut c = self.client(addr).await?;
        let resp = c
            .resume_sandbox(ResumeSandboxRequest { sandbox_id: sandbox_id.into() })
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("resume rpc: {e}") })?
            .into_inner();
        if resp.ok {
            Ok(())
        } else {
            Err(FlintError::Internal(format!("resume: {}", resp.error)))
        }
    }

    pub async fn stop_sandbox(&self, addr: &str, sandbox_id: &str, keep_state: bool) -> Result<String> {
        let mut c = self.client(addr).await?;
        let resp = c
            .stop_sandbox(StopSandboxRequest { sandbox_id: sandbox_id.into(), keep_state })
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("stop rpc: {e}") })?
            .into_inner();
        if resp.ok {
            Ok(resp.snapshot_id)
        } else {
            Err(FlintError::Internal(format!("stop: {}", resp.error)))
        }
    }

    pub async fn delete_sandbox_local(&self, addr: &str, sandbox_id: &str) -> Result<()> {
        let mut c = self.client(addr).await?;
        c.delete_sandbox_local(DeleteSandboxLocalRequest { sandbox_id: sandbox_id.into() })
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("delete rpc: {e}") })?;
        Ok(())
    }

    pub async fn snapshot_sandbox(&self, addr: &str, sandbox_id: &str, kind: &str) -> Result<String> {
        let mut c = self.client(addr).await?;
        let resp = c
            .snapshot_sandbox(SnapshotSandboxRequest { sandbox_id: sandbox_id.into(), kind: kind.into() })
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("snapshot rpc: {e}") })?
            .into_inner();
        if resp.ok {
            Ok(resp.snapshot_id)
        } else {
            Err(FlintError::Internal(format!("snapshot: {}", resp.error)))
        }
    }

    /// Unary op through the Operate pipe: send one envelope, wait for the
    /// final event, return its payload.
    pub async fn op(&self, addr: &str, sandbox_id: &str, kind: &str, payload: &Value) -> Result<Value> {
        let op_id = flint_core::ids::new_id("op");
        let (tx, rx) = tokio::sync::mpsc::channel::<OpEnvelope>(4);
        let mut c = self.client(addr).await?;
        let mut resp = c
            .operate(tokio_stream::wrappers::ReceiverStream::new(rx))
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("operate rpc: {e}") })?;
        tx.send(OpEnvelope {
            sandbox_id: sandbox_id.into(),
            op_id: op_id.clone(),
            kind: kind.into(),
            payload_json: payload.to_string(),
        })
        .await
        .map_err(|_| FlintError::Unavailable { msg: "operate stream closed".into() })?;
        drop(tx); // half-close after one op
        let mut out = Value::Null;
        let mut out_err = String::new();
        use tokio_stream::StreamExt as _;
        while let Some(msg) = resp.get_mut().next().await {
            let ev: OpEvent = msg.map_err(|e| FlintError::Unavailable { msg: format!("operate stream: {e}") })?;
            if ev.op_id != op_id {
                continue;
            }
            if !ev.error.is_empty() {
                out_err = ev.error;
            } else if !ev.payload_json.is_empty() {
                out = serde_json::from_str(&ev.payload_json).unwrap_or(Value::Null);
            }
            if ev.r#final {
                if !out_err.is_empty() {
                    return Err(FlintError::Internal(format!("op {kind}: {out_err}")));
                }
                return Ok(out);
            }
        }
        Err(FlintError::Unavailable { msg: "operate stream ended without final".into() })
    }

    /// Open a long-lived Operate pipe for streaming ops (terminal, exec
    /// streaming, port tunnels). Returns a handle to send envelopes and
    /// receive events.
    pub async fn open_pipe(&self, addr: &str) -> Result<OpPipe> {
        let (tx, rx) = tokio::sync::mpsc::channel::<OpEnvelope>(64);
        let mut c = self.client(addr).await?;
        let resp = c
            .operate(tokio_stream::wrappers::ReceiverStream::new(rx))
            .await
            .map_err(|e| FlintError::Unavailable { msg: format!("operate rpc: {e}") })?;
        let mut inbound = resp.into_inner();
        let (ev_tx, ev_rx) = tokio::sync::mpsc::channel::<OpEvent>(256);
        tokio::spawn(async move {
            use tokio_stream::StreamExt as _;
            while let Some(Ok(ev)) = inbound.next().await {
                if ev_tx.send(ev).await.is_err() {
                    break;
                }
            }
        });
        Ok(OpPipe { tx, events: ev_rx })
    }
}

/// An open Operate bidi pipe.
pub struct OpPipe {
    pub tx: tokio::sync::mpsc::Sender<OpEnvelope>,
    pub events: tokio::sync::mpsc::Receiver<OpEvent>,
}
