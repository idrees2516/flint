//! End-to-end test: boots the full stack (gateway with embedded process-
//! driver worker, guest agent, gRPC fleet protocol, REST) and drives the
//! complete sandbox lifecycle: create → exec → files → pause (snapshot) →
//! wake-on-request resume with state preservation → snapshot → fork →
//! delete.
//!
//! Requires the workspace binaries; paths are derived from
//! `CARGO_MANIFEST_DIR` (crates/flint-e2e → ../target/debug/).

use std::net::TcpListener;
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

struct Stack {
    gateway: Child,
    tmp: tempfile::TempDir,
    base: String,
    key: String,
}

impl Drop for Stack {
    fn drop(&mut self) {
        let _ = self.gateway.kill();
        let _ = self.gateway.wait();
    }
}

fn bin(name: &str) -> PathBuf {
    let mut p = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    p.push("../../target/debug");
    p.push(name);
    assert!(p.exists(), "binary {} not found at {} — run `cargo build --workspace` first", name, p.display());
    p
}

fn free_port() -> u16 {
    TcpListener::bind("127.0.0.1:0").unwrap().local_addr().unwrap().port()
}

fn wait_http(url: &str, timeout: Duration) {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if let Ok(resp) = ureq::get(url).timeout(Duration::from_secs(2)).call() {
            if resp.status() < 500 {
                return;
            }
        }
        std::thread::sleep(Duration::from_millis(200));
    }
    panic!("gateway did not become healthy at {url}");
}

fn boot() -> Stack {
    let tmp = tempfile::tempdir().expect("tempdir");
    let rest_port = free_port();
    let grpc_port = free_port();
    let key = "flint_sk_e2e_test_key_0000000000000001";

    let mut cmd = Command::new(bin("flint-gateway"));
    cmd.args([
        "--dev",
        "--bind",
        &format!("127.0.0.1:{rest_port}"),
        "--bind-grpc",
        &format!("127.0.0.1:{grpc_port}"),
    ])
    .env("FLINT_DATA_DIR", tmp.path())
    .env("FLINT_BOOTSTRAP_API_KEY", key)
    .env("FLINT_GUEST_AGENT_BIN", bin("flint-guest-agent"))
    .env("RUST_LOG", "flint=info,warn")
    .current_dir(tmp.path())
    .stdout(Stdio::piped())
    .stderr(Stdio::piped());
    let gateway = cmd.spawn().expect("spawn gateway");

    let stack = Stack {
        gateway,
        tmp,
        base: format!("http://127.0.0.1:{rest_port}"),
        key: key.to_string(),
    };
    wait_http(&format!("{}/healthz", stack.base), Duration::from_secs(30));
    stack
}

impl Stack {
    fn get(&self, path: &str) -> serde_json::Value {
        let resp = ureq::get(&format!("{}{}", self.base, path))
            .set("Authorization", &format!("Bearer {}", self.key))
            .timeout(Duration::from_secs(60))
            .call()
            .expect("GET");
        resp.into_json().expect("json")
    }

    fn post(&self, path: &str, body: serde_json::Value) -> Result<serde_json::Value, String> {
        match ureq::post(&format!("{}{}", self.base, path))
            .set("Authorization", &format!("Bearer {}", self.key))
            .timeout(Duration::from_secs(120))
            .send_json(body)
        {
            Ok(resp) => resp.into_json().map_err(|e| e.to_string()),
            Err(ureq::Error::Status(code, resp)) => {
                Err(format!("HTTP {code}: {}", resp.into_string().unwrap_or_default()))
            }
            Err(e) => Err(e.to_string()),
        }
    }

    fn put_raw(&self, path: &str, data: &[u8]) -> Result<serde_json::Value, String> {
        match ureq::put(&format!("{}{}", self.base, path))
            .set("Authorization", &format!("Bearer {}", self.key))
            .timeout(Duration::from_secs(60))
            .send_bytes(data)
        {
            Ok(resp) => resp.into_json().map_err(|e| e.to_string()),
            Err(ureq::Error::Status(code, resp)) => {
                Err(format!("HTTP {code}: {}", resp.into_string().unwrap_or_default()))
            }
            Err(e) => Err(e.to_string()),
        }
    }

    fn delete(&self, path: &str) -> serde_json::Value {
        let resp = ureq::delete(&format!("{}{}", self.base, path))
            .set("Authorization", &format!("Bearer {}", self.key))
            .timeout(Duration::from_secs(60))
            .call()
            .expect("DELETE");
        resp.into_json().expect("json")
    }
}

fn exec(st: &Stack, id: &str, shell_cmd: &str) -> (i64, String, String) {
    let v = st
        .post(
            &format!("/v1/sandboxes/{id}/exec"),
            serde_json::json!({ "spec": { "cmd": ["sh", "-c", shell_cmd], "timeout_ms": 60000 } }),
        )
        .expect("exec");
    (
        v.get("exit_code").and_then(|c| c.as_i64()).unwrap_or(-1),
        v.get("stdout").cloned().and_then(|s| s.as_str().map(String::from)).unwrap_or_default(),
        v.get("stderr").cloned().and_then(|s| s.as_str().map(String::from)).unwrap_or_default(),
    )
}

fn wait_state(st: &Stack, id: &str, want: &str, timeout: Duration) -> serde_json::Value {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        let v = st.get(&format!("/v1/sandboxes/{id}"));
        if v.get("state").and_then(|s| s.as_str()) == Some(want) {
            return v;
        }
        std::thread::sleep(Duration::from_millis(300));
    }
    panic!("sandbox {id} never reached state {want}");
}

#[test]
fn full_lifecycle_e2e() {
    let st = boot();

    // --- 1. create (retries until the dev worker registers with the
    // scheduler over the fleet protocol) ---
    let mut sandbox = None;
    let deadline = Instant::now() + Duration::from_secs(30);
    while Instant::now() < deadline {
        match st.post("/v1/sandboxes", serde_json::json!({})) {
            Ok(v) => {
                sandbox = Some(v);
                break;
            }
            Err(e) => {
                eprintln!("create retry: {e}");
                std::thread::sleep(Duration::from_millis(700));
            }
        }
    }
    let sbx = sandbox.expect("sandbox create failed");
    let id = sbx.get("id").and_then(|x| x.as_str()).expect("id").to_string();
    assert_eq!(sbx.get("state").and_then(|x| x.as_str()), Some("running"), "fresh sandbox running: {sbx}");
    println!("[e2e] created {id}");

    // --- 2. exec ---
    let (code, stdout, _) = exec(&st, &id, "echo hello-flint");
    assert_eq!(code, 0, "exec exit code");
    assert_eq!(stdout.trim(), "hello-flint");
    println!("[e2e] exec ok");

    // --- 3. file write (journaled) + read back ---
    st.put_raw(&format!("/v1/sandboxes/{id}/files?path=/work/notes.txt"), b"flint was here\n")
        .expect("file write");
    let list = st.get(&format!("/v1/sandboxes/{id}/files/list?path=/"));
    let entries = list.get("entries").and_then(|e| e.as_array()).cloned().unwrap_or_default();
    assert!(entries.iter().any(|e| e.get("path").and_then(|p| p.as_str()) == Some("/work")), "dir listed: {list}");
    let raw = ureq::get(&format!("{}/v1/sandboxes/{}/files?raw=1&path=/work/notes.txt", st.base, id))
        .set("Authorization", &format!("Bearer {}", st.key))
        .call()
        .expect("read raw");
    let body = raw.into_string().expect("raw body");
    assert_eq!(body, "flint was here\n");
    println!("[e2e] files ok");

    // --- 4. exec that writes state (survives pause/restore) ---
    let (code, stdout, _) = exec(&st, &id, "echo generated > from-exec.txt && cat from-exec.txt");
    assert_eq!(code, 0);
    assert_eq!(stdout.trim(), "generated");
    println!("[e2e] exec-with-state ok");

    // --- 5. pause: snapshot layers + manifest into the object store ---
    let paused = st.post(&format!("/v1/sandboxes/{id}/pause"), serde_json::json!({})).expect("pause");
    assert_eq!(paused.get("state").and_then(|s| s.as_str()), Some("paused"), "{paused}");
    let snap_id = paused
        .get("current_snapshot_id")
        .and_then(|s| s.as_str())
        .expect("snapshot id set")
        .to_string();
    assert!(!snap_id.is_empty());
    // The manifest + layers exist in the local object store.
    let manifest_path = st.tmp.path().join("var/objects").join(format!("snapshots/{id}/{snap_id}/manifest.json"));
    assert!(manifest_path.exists(), "manifest at {}", manifest_path.display());
    let manifest: serde_json::Value =
        serde_json::from_str(&std::fs::read_to_string(&manifest_path).unwrap()).unwrap();
    assert!(manifest.get("layers").and_then(|l| l.as_array()).map(|a| !a.is_empty()).unwrap_or(false));
    println!("[e2e] paused with snapshot {snap_id}");

    // --- 6. resume (explicit) + state preserved through the snapshot ---
    let resumed = st.post(&format!("/v1/sandboxes/{id}/resume"), serde_json::json!({})).expect("resume");
    wait_state(&st, &id, "running", Duration::from_secs(30));
    let _ = resumed;
    let (code, stdout, _) = exec(&st, &id, "cat work/notes.txt from-exec.txt");
    assert_eq!(code, 0, "post-resume exec");
    assert_eq!(stdout.trim(), "flint was here\ngenerated", "state preserved across pause/resume: {stdout}");
    println!("[e2e] resume + state preservation ok");

    // --- 7. explicit snapshot ---
    let snap = st
        .post(&format!("/v1/sandboxes/{id}/snapshot"), serde_json::json!({}))
        .expect("snapshot");
    assert!(!snap.get("snapshot_id").and_then(|s| s.as_str()).unwrap_or("").is_empty());
    println!("[e2e] snapshot ok");

    // --- 8. fork: 2 clones from the paused base ---
    let forked = st
        .post(&format!("/v1/sandboxes/{id}/fork"), serde_json::json!({ "count": 2 }))
        .expect("fork");
    let forks = forked.get("forks").and_then(|f| f.as_array()).cloned().unwrap_or_default();
    assert_eq!(forks.len(), 2, "two forks: {forked}");
    let fork_id = forks[0].get("id").and_then(|x| x.as_str()).unwrap().to_string();
    // Fork sees the parent's state (restore from the fork base snapshot).
    let (code, stdout, _) = exec(&st, &fork_id, "cat work/notes.txt");
    assert_eq!(code, 0, "fork exec");
    assert_eq!(stdout.trim(), "flint was here", "fork inherited state");
    let _ = st.delete(&format!("/v1/sandboxes/{}", forks[1].get("id").and_then(|x| x.as_str()).unwrap()));
    println!("[e2e] fork ok ({fork_id})");

    // --- 9. process management ---
    let spawn = st
        .post(
            &format!("/v1/sandboxes/{fork_id}/processes"),
            serde_json::json!({ "cmd": ["sleep", "300"], "restartable": false }),
        )
        .expect("spawn process");
    let proc_id = spawn.get("proc_id").and_then(|p| p.as_str()).expect("proc id").to_string();
    let procs = st.get(&format!("/v1/sandboxes/{fork_id}/processes"));
    let list = procs.get("processes").and_then(|p| p.as_array()).cloned().unwrap_or_default();
    assert!(list.iter().any(|p| p.get("proc_id").and_then(|x| x.as_str()) == Some(&proc_id)), "process listed");
    let killed = st.delete(&format!("/v1/sandboxes/{fork_id}/processes/{proc_id}"));
    assert!(killed.get("killed").and_then(|k| k.as_bool()).unwrap_or(false));
    println!("[e2e] processes ok");

    // --- 10. tool gateway (web search — network permitting, else skip) ---
    match st.post("/v1/tools/web_search", serde_json::json!({ "query": "rust language", "num": 3 })) {
        Ok(v) => {
            let n = v.get("results").and_then(|r| r.as_array()).map(|a| a.len()).unwrap_or(0);
            println!("[e2e] web_search returned {n} results");
        }
        Err(e) => println!("[e2e] web_search unavailable in this environment ({e}) — skipping"),
    }

    // --- 11. usage + cleanup ---
    let usage = st.get("/v1/usage");
    assert!(usage.get("sandboxes_running").and_then(|r| r.as_u64()).unwrap_or(0) >= 1, "{usage}");
    let _ = st.delete(&format!("/v1/sandboxes/{id}"));
    let _ = st.delete(&format!("/v1/sandboxes/{fork_id}"));
    println!("[e2e] full lifecycle PASSED");
}

#[test]
fn auth_is_enforced() {
    let st = boot();
    let err = ureq::get(&format!("{}/v1/sandboxes", st.base))
        .set("Authorization", "Bearer wrong-key")
        .call()
        .expect_err("must 401");
    match err {
        ureq::Error::Status(code, _) => assert_eq!(code, 401),
        other => panic!("unexpected: {other:?}"),
    }
    // And the valid key works.
    let _ = ureq::get(&format!("{}/v1/sandboxes", st.base))
        .set("Authorization", &format!("Bearer {}", st.key))
        .call()
        .expect("valid key");
    println!("[e2e] auth ok");
}
