//! Snapshot manifests: the artifact shared by paused sandboxes, explicit
//! snapshots, forks and templates (research: "a paused sandbox and a
//! template are the same artifact shape so resume ≡ create").

use flint_core::VmSpec;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SnapshotKind {
    /// Cut by a pause (memory-preserving in prod).
    Pause,
    /// Explicit user snapshot.
    Explicit,
    /// Base of forked clones.
    Fork,
    /// A template's pre-booted base.
    TemplateBase,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum LayerKind {
    /// tar.gz of the sandbox writable layer (overlay upperdir / home dir).
    FsTarGz,
    /// Firecracker memory file (raw RAM, mmap-shared).
    Memory,
    /// Firecracker device/VM state file (snapfile).
    DeviceState,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Layer {
    /// Object-store key of the layer blob.
    pub key: String,
    pub kind: LayerKind,
    pub sha256: String,
    pub size_b: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SnapshotManifest {
    pub snap_id: String,
    pub sandbox_id: String,
    pub kind: SnapshotKind,
    pub created_at_ms: i64,
    /// Journal is durable through this WAL seq; replay everything after.
    pub wal_seq: u64,
    pub layers: Vec<Layer>,
    pub vm: VmSpec,
    pub template_id: Option<String>,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    #[serde(default)]
    pub metadata: BTreeMap<String, String>,
    /// Recorded spawn specs of `restartable` processes (crash recovery
    /// restarts them; process memory is NOT restored — Journal+FS tier).
    #[serde(default)]
    pub restartable: Vec<flint_core::ExecSpec>,
}

impl SnapshotManifest {
    pub fn total_size_b(&self) -> u64 {
        self.layers.iter().map(|l| l.size_b).sum()
    }

    pub fn find(&self, kind: LayerKind) -> Option<&Layer> {
        self.layers.iter().find(|l| l.kind == kind)
    }
}
