//! Fleet placement (ARCHITECTURE §8).
//!
//! Research-derived: E2B's best-of-K sampling with a `max()` pressure
//! score plus uniform jitter avoids the herd-thundering of greedy
//! least-loaded placement, and full-jitter retry on exhaustion. Node
//! admission also reserves disk headroom so a pause always fits.

use flint_core::{FlintError, Result};
use rand::Rng;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::RwLock;
use std::time::Duration;

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Capacity {
    pub vcpu_total: u32,
    pub mem_mib_total: u32,
    pub max_sandboxes: u32,
    pub pause_headroom_mib: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Load {
    pub running: u32,
    pub paused: u32,
    pub cpu_pressure: f64,
    pub mem_pressure: f64,
    pub slot_pressure: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkerState {
    pub node_id: String,
    pub addr: String,
    pub driver_kind: String,
    pub capacity: Capacity,
    pub load: Load,
    pub drained: bool,
    pub last_heartbeat_ms: i64,
}

#[derive(Debug, Clone)]
pub struct PlaceRequest {
    pub vcpu: u32,
    pub mem_mib: u32,
    /// Paused sandboxes consume disk; admission reserves headroom.
    pub reserve_pause_headroom: bool,
    /// Driver filter ("firecracker", "process", "" = any).
    pub driver_kind: String,
}

pub struct Scheduler {
    workers: RwLock<HashMap<String, WorkerState>>,
    k: usize,
    #[allow(dead_code)]
    jitter: f64,
}

impl Scheduler {
    pub fn new(k: usize) -> Self {
        Self {
            workers: RwLock::new(HashMap::new()),
            k: k.max(1),
            jitter: 0.05,
        }
    }

    pub fn register(&self, w: WorkerState) {
        self.workers.write().unwrap().insert(w.node_id.clone(), w);
    }

    pub fn heartbeat(&self, node_id: &str, load: Load) {
        let mut ws = self.workers.write().unwrap();
        if let Some(w) = ws.get_mut(node_id) {
            w.load = load;
            w.last_heartbeat_ms = flint_core::util::now_ms();
        }
    }

    pub fn set_drained(&self, node_id: &str, drained: bool) {
        if let Some(w) = self.workers.write().unwrap().get_mut(node_id) {
            w.drained = drained;
        }
    }

    pub fn remove_stale(&self, older_than: Duration) -> Vec<String> {
        let cutoff = flint_core::util::now_ms() - older_than.as_millis() as i64;
        let mut ws = self.workers.write().unwrap();
        let stale: Vec<String> = ws
            .iter()
            .filter(|(_, w)| w.last_heartbeat_ms < cutoff)
            .map(|(k, _)| k.clone())
            .collect();
        for id in &stale {
            ws.remove(id);
        }
        stale
    }

    pub fn list(&self) -> Vec<WorkerState> {
        self.workers.read().unwrap().values().cloned().collect()
    }

    pub fn get(&self, node_id: &str) -> Option<WorkerState> {
        self.workers.read().unwrap().get(node_id).cloned()
    }

    /// Score a worker: worst pressure + jitter (lower is better).
    fn score(w: &WorkerState) -> f64 {
        let pressure = w
            .load
            .cpu_pressure
            .max(w.load.mem_pressure)
            .max(w.load.slot_pressure)
            .max(0.0)
            .min(1.0);
        pressure + rand::thread_rng().gen::<f64>() * 0.05
    }

    fn eligible(w: &WorkerState, req: &PlaceRequest) -> bool {
        if w.drained {
            return false;
        }
        if !req.driver_kind.is_empty() && w.driver_kind != req.driver_kind {
            return false;
        }
        let slots_left = w.capacity.max_sandboxes.saturating_sub(w.load.running + w.load.paused);
        if slots_left == 0 {
            return false;
        }
        // Rough fit on vcpu/mem (pressures carry the fine-grained truth).
        if w.load.cpu_pressure >= 0.95 || w.load.mem_pressure >= 0.95 {
            return false;
        }
        true
    }

    /// Best-of-K placement. Returns the chosen `node_id`.
    pub fn place(&self, req: &PlaceRequest) -> Result<String> {
        let ws = self.workers.read().unwrap();
        let eligible: Vec<&WorkerState> = ws.values().filter(|w| Self::eligible(w, req)).collect();
        if eligible.is_empty() {
            return Err(FlintError::ResourceExhausted {
                msg: "no eligible worker for placement".into(),
            });
        }
        let k = self.k.min(eligible.len());
        let mut picks: Vec<&WorkerState> = Vec::with_capacity(k);
        let mut seen: Vec<usize> = Vec::with_capacity(k);
        let mut rng = rand::thread_rng();
        while picks.len() < k {
            let idx = rng.gen_range(0..eligible.len());
            if !seen.contains(&idx) {
                seen.push(idx);
                picks.push(eligible[idx]);
            }
        }
        let best = picks.into_iter().min_by(|a, b| Self::score(a).total_cmp(&Self::score(b)));
        best.map(|w| w.node_id.clone()).ok_or(FlintError::ResourceExhausted {
            msg: "placement failed after sampling".into(),
        })
    }
}

/// Warm pool bookkeeping per template (research: Modal min/buffer
/// containers; Tensorlake sandbox pools as first-class resources).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WarmPool {
    pub template_id: String,
    pub target: usize,
    pub current: usize,
}

#[derive(Default)]
pub struct WarmPools {
    pools: RwLock<HashMap<String, WarmPool>>,
}

impl WarmPools {
    pub fn set_target(&self, template_id: &str, target: usize) {
        let mut p = self.pools.write().unwrap();
        let e = p.entry(template_id.to_string()).or_insert(WarmPool {
            template_id: template_id.to_string(),
            target: 0,
            current: 0,
        });
        e.target = target;
    }

    pub fn on_claim(&self, template_id: &str) -> usize {
        let mut p = self.pools.write().unwrap();
        if let Some(e) = p.get_mut(template_id) {
            e.current = e.current.saturating_sub(1);
            return e.target.saturating_sub(e.current);
        }
        0
    }

    pub fn on_warm(&self, template_id: &str) {
        if let Some(e) = self.pools.write().unwrap().get_mut(template_id) {
            e.current += 1;
        }
    }

    pub fn snapshot(&self) -> Vec<WarmPool> {
        self.pools.read().unwrap().values().cloned().collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn worker(id: &str, cpus: u32, mem: u32, slots: u32, cpu_p: f64) -> WorkerState {
        WorkerState {
            node_id: id.into(),
            addr: format!("http://{id}:7500"),
            driver_kind: "process".into(),
            capacity: Capacity {
                vcpu_total: cpus,
                mem_mib_total: mem,
                max_sandboxes: slots,
                pause_headroom_mib: 4096,
            },
            load: Load {
                running: 0,
                paused: 0,
                cpu_pressure: cpu_p,
                mem_pressure: 0.1,
                slot_pressure: 0.1,
            },
            drained: false,
            last_heartbeat_ms: flint_core::util::now_ms(),
        }
    }

    #[test]
    fn places_on_least_loaded_of_k() {
        let s = Scheduler::new(5);
        s.register(worker("a", 32, 65536, 100, 0.9));
        s.register(worker("b", 32, 65536, 100, 0.2));
        s.register(worker("c", 32, 65536, 100, 0.1));
        let mut counts = HashMap::new();
        for _ in 0..50 {
            let chosen = s.place(&PlaceRequest { vcpu: 2, mem_mib: 2048, reserve_pause_headroom: false, driver_kind: String::new() }).unwrap();
            *counts.entry(chosen).or_insert(0) += 1;
        }
        // Heavily-loaded "a" must never win.
        assert!(!counts.contains_key("a"), "placement picked overloaded node: {counts:?}");
    }

    #[test]
    fn respects_drain_and_capacity() {
        let s = Scheduler::new(5);
        s.register(worker("a", 8, 8192, 10, 0.1));
        s.set_drained("a", true);
        assert!(s.place(&PlaceRequest { vcpu: 2, mem_mib: 2, reserve_pause_headroom: false, driver_kind: String::new() }).is_err());
        s.set_drained("a", false);
        assert!(s.place(&PlaceRequest { vcpu: 2, mem_mib: 2, reserve_pause_headroom: false, driver_kind: String::new() }).is_ok());
    }

    #[test]
    fn driver_filter() {
        let s = Scheduler::new(5);
        s.register(worker("p", 8, 8192, 10, 0.1));
        assert!(s
            .place(&PlaceRequest { vcpu: 2, mem_mib: 2, reserve_pause_headroom: false, driver_kind: "firecracker".into() })
            .is_err());
    }

    #[test]
    fn stale_workers_evicted() {
        let s = Scheduler::new(5);
        let mut w = worker("a", 8, 8192, 10, 0.1);
        w.last_heartbeat_ms = flint_core::util::now_ms() - 120_000;
        s.register(w);
        let removed = s.remove_stale(Duration::from_secs(60));
        assert_eq!(removed, vec!["a".to_string()]);
        assert!(s.list().is_empty());
    }

    #[test]
    fn warm_pool_refill_math() {
        let wp = WarmPools::default();
        wp.set_target("tpl_1", 3);
        wp.on_warm("tpl_1");
        wp.on_warm("tpl_1");
        wp.on_warm("tpl_1");
        assert_eq!(wp.snapshot()[0].current, 3);
        assert_eq!(wp.on_claim("tpl_1"), 1); // one to refill
        assert_eq!(wp.snapshot()[0].current, 2);
    }
}
