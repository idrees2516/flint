//! flint-store: metadata catalog (SQLite) + object storage for the Flint
//! sandbox platform.

pub mod meta;
pub mod object;

pub use meta::{
    ApiKeyRow, KeyQuotas, MetaStore, SandboxRow, SnapshotRow, TemplateRow, WorkerRow,
};
pub use object::{LocalObjectStore, ObjectStore, S3ObjectStore};

use flint_core::config::ObjectStoreConfig;
use flint_core::{FlintError, Result};
use std::path::Path;
use std::sync::Arc;

/// Build an object store from config.
pub fn build_object_store(cfg: &ObjectStoreConfig) -> Result<Arc<dyn ObjectStore>> {
    match cfg.kind.as_str() {
        "local" => Ok(Arc::new(LocalObjectStore::new(&cfg.local_dir)?)),
        "s3" => {
            let endpoint = cfg.s3_endpoint.clone().unwrap_or_default();
            let region = cfg.s3_region.clone().unwrap_or_else(|| "us-east-1".into());
            let bucket = cfg.s3_bucket.clone().unwrap_or_default();
            if endpoint.is_empty() || bucket.is_empty() {
                return Err(FlintError::InvalidParam { msg: "s3 object store requires endpoint + bucket".into() });
            }
            let store = match (
                cfg.s3_access_key_id.clone(),
                cfg.s3_secret_access_key.clone(),
            ) {
                (Some(a), Some(s)) => S3ObjectStore::new(&endpoint, &region, &bucket, &a, &s, cfg.s3_path_style),
                _ => S3ObjectStore::from_env(&endpoint, &region, &bucket, cfg.s3_path_style).ok_or(
                    FlintError::InvalidParam { msg: "s3 credentials missing (config or AWS_* env)".into() },
                )?,
            };
            Ok(Arc::new(store))
        }
        other => Err(FlintError::InvalidParam { msg: format!("unknown object store kind: {other}") }),
    }
}

/// Open the metadata store at the conventional `data_dir/flint.sqlite3`.
pub fn open_meta_store(data_dir: &Path) -> Result<MetaStore> {
    MetaStore::open(&data_dir.join("flint.sqlite3"))
}
