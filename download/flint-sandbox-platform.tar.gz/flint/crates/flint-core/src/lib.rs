//! Flint core: shared foundation for the whole platform.
//!
//! Everything in here is dependency-light and used by multiple crates:
//! identifiers, the error model, the sandbox lifecycle state machine,
//! resource specs, configuration, a Prometheus-style metrics registry,
//! token-bucket rate limiting and HMAC token auth.

pub mod agent_proto;
pub mod config;
pub mod error;
pub mod minhttp;
pub mod ids;
pub mod metrics;
pub mod ratelimit;
pub mod spec;
pub mod state;
pub mod tokens;
pub mod util;

pub use error::{FlintError, Result};
pub use spec::{DriverKind, ExecSpec, PtySize, SandboxCreateSpec, VmSpec};
pub use state::{can_transition, SandboxState, TimeoutPolicy};
