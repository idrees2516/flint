# Flint — Architecture

**Firecracker microVM sandboxes for AI agents — control plane, worker fleet, guest agent, and tooling, all in Rust.**

Flint is a production-shaped implementation of the "sandbox-for-AI-agents" platform category
(E2B, Daytona, Morph, Modal, Runloop, Cloudflare, CodeSandbox, Vercel, Freestyle, Beam,
Blaxel, Boat.dev, Tensorlake). This document records what we learned from researching those
systems and how each lesson became a design decision. Research notes live in `research/`.

---

## 1. What the research says → what Flint does

| Lesson (source) | Flint decision |
|---|---|
| Creation must be a **snapshot restore, never a cold boot** (E2B ~150ms, Blaxel 25ms resume, Freestyle 65ms) | Templates are pre-booted Firecracker snapshot stacks (memfile + snapfile + read-only rootfs). `Sandbox::create` = restore path. |
| Explicit **lifecycle state machine** with reconciler (Daytona) | `SandboxState` enum + typed transition table + a reconciler loop per sandbox (§5). |
| **Pause is the killer persistence primitive** — memory-preserving pause vs disk-only suspend are two different tiers (E2B/Morph vs Runloop) | Two tiers: `Pause` (Firecracker full snapshot + diff export) and `Stop` (disk-only, processes lost, documented loudly). Paused sandboxes bill storage-only. |
| **Fork/branch as a first-class primitive** (Morph Infinibranch <250ms, E2B 100 forks, Freestyle O(1) CoW) | `fork(count)` = pause → snapshot → N restores. Snapshot artifact shape is identical for templates, paused sandboxes, and forks. |
| **Timeout policies** are a product surface: TTL + expiry action + idle triggers + wake-on-traffic (Daytona/Morph/Runloop/E2B) | `TimeoutPolicy { auto_pause_after_idle, auto_stop_after, max_ttl, expiry_action, wake_on_request }` enforced by the reconciler. |
| **mmap MAP_SHARED memory files** make snapshots 30–100ms instead of 8–12s (CodeSandbox) | Worker maps memfiles `MAP_SHARED` and serves restore via file backend; documented as the hot-path trick. |
| **Journal-based durability** (our chosen tier): overlayfs upperdir + op-log, CRIU-free | Host-side fsync'd WAL per sandbox + guest journal + snapshot manifests (§6). Crash = restore last snapshot + deterministic replay of journaled FS ops. |
| **Best-of-K placement with jittered backoff**, node-local admission on disk headroom (E2B) | Scheduler samples K workers, scores `max(cpu_pressure, mem_pressure, slot_pressure) + jitter` (§8). |
| **Warm pools** as a scheduler concern (Modal `min_containers`/`buffer_containers`, Tensorlake Sandbox Pools) | WarmPool manager per template: `warm_target`, refill on claim. |
| **Routing table with TTL + auto-resume on miss** (E2B edge, Morph wake-on-http) | `sandbox:{id} → worker` routing in the meta store; gateway 404-path triggers resume. |
| **Per-sandbox egress firewall with SNI allowlists + credential proxying** so agents never see keys (Runloop Gateways, Freestyle default-deny) | `EgressPolicy { ip_allow/ip_deny, domain_allow (SNI), default }` enforced by nftables + a policy proxy; tool calls (web_search, http_fetch) are brokered by the worker so the guest never needs egress. |
| **Guest agent over vsock** with `CONNECT port\n` UDS framing, CID ≥ 3 host-managed (E2B envd, R4 research) | `flint-guest-agent`: AF_VSOCK listener :5252 (prod) + localhost TCP (dev), length-prefixed JSON protocol (§7). |
| **Networking slot** model: netns + veth + TAP `169.254.0.22/30`, guest `.21/30` via kernel cmdline, one shared host-side MAC (E2B) | `flint-net` slot pool, `/31` veth pair space = 32k slots/node, nftables per-slot chain (§9). |
| **Actor-per-sandbox supervision** (Cloudflare Durable Objects) | Worker runs one `SandboxSupervisor` actor per sandbox (own channel + timers). |
| **Named sandbox spans many sessions; FS persists across sessions** (Vercel) | `Sandbox` is the durable identity; `start`/`stop` are cheap; FS + metadata survive. |
| **Per-second metering, active-only** (everyone; Beam bills ms and never bills cold-start) | Usage meter (active_seconds, paused_storage_byte_seconds, tool_calls) with `/v1/usage`. |
| **In-VM agent harness + steer/interrupt** (Boat.dev) | Tool gateway exposed *to* the agent inside the sandbox (`tools.invoke` over the agent channel) with per-key quotas. |
| **Durable execution / replay** (Tensorlake) | WAL is the op-log: every op has an idempotency key; FS ops are replayable, exec ops are audit-logged. |

## 2. System overview

```
             ┌──────────────────────────────────────────────────────────────┐
             │                     flint-gateway (control plane)            │
             │  REST /v1/* ── WS terminal+exec+events ── gRPC :7473         │
             │  auth (API keys + HMAC sandbox tokens) · quotas · ratelimit  │
             │  scheduler ── meta store (SQLite) ── routing table ── usage  │
             └───────────────┬──────────────────────────────┬───────────────┘
                             │ gRPC fleet protocol          │ snapshot objects
              ┌──────────────┴──────────────┐   ┌───────────▼───────────────┐
              │      flint-worker (node)    │   │  object store (local / S3)│
              │  SandboxSupervisor actor    │   └───────────▲───────────────┘
              │   ├─ VmDriver (firecracker/ │               │
              │   │   process-dev)          │   ┌───────────┴───────────────┐
              │   ├─ WAL journal + snapshots┼──►│  templates (pre-booted    │
              │   ├─ guest-agent mux        │   │  FC snapshot stacks)      │
              │   └─ net slot + egress nft  │   └───────────────────────────┘
              └──────────────┬──────────────┘
                             │ vsock UDS "CONNECT 5252\n" (prod) / TCP (dev)
              ┌──────────────▼──────────────┐
              │   flint-guest-agent (in VM) │  exec · PTY · files · processes
              │   + flint-tools broker      │  web_search / http_fetch (proxied)
              └─────────────────────────────┘
```

**Binaries:** `flint-gateway`, `flint-worker`, `flint-guest-agent`, `flint-cli`.
**Libraries:** `flint-core`, `flint-journal`, `flint-store`, `flint-net`, `flint-vm`,
`flint-proto`, `flint-scheduler`, `flint-tools`.

## 3. Data model

- **ApiKeKey** → hashed key, scopes, quotas {max_concurrent_sandboxes, max_total_vcpu, max_total_mem_mib, req/s, tool_calls/day}.
- **Template** → `{ id, name, base snapshot stack (memfile+snapfile+rootfs refs), kernel ref, boot_args, vm_config, env, size_b }`. Created from a paused sandbox (`/v1/templates/from-sandbox/:id`).
- **Sandbox** → `{ id (sbx_*), template_id, project, state, vm_spec {vcpu, mem_mib, disk_mib}, timeout_policy, env, metadata, worker_id, created_at, last_activity_at, usage counters, current snapshot ref }`.
- **Snapshot** → `{ id (snap_*), sandbox_id, kind (Pause|Explicit|Fork|TemplateBase), manifest {layers, sha256s, wal_seq, vm_config}, size_b }`.
- **ProcessHandle** (ephemeral, in worker memory) → `{ proc_id (prc_*), spec, status, exit }`.
- **UsageRecord** → per-sandbox per-minute counters appended to store.

IDs are prefixed ULIDs-ish (`sbx_`, `tpl_`, `snap_`, `wrk_`, `prc_`, `key_`), sortable and greppable.

## 4. Lifecycle state machine

```
                ┌──────────┐  start   ┌─────────┐   pause    ┌────────┐
   create ──►  │ Creating │ ───────► │ Running │ ──────────► │Paused✻ │
                └────┬─────┘          └────┬────┘   resume    └───┬────┘
                     │ error               │ stop                 │ stop / fork / expire
                     ▼                     ▼                      ▼
                ┌──────────┐          ┌─────────┐  start   ┌──────────┐
                │  Error   │          │ Stopped │ ◄──────  │Archived✻ │
                └──────────┘          └─────────┘          └──────────┘
   any ──delete──► Deleted (terminal)      ✻ = storage-only billing, indefinite
```

Transitions are a typed table (`state.rs::can_transition`); every mutating call is checked
against it, and the worker reconciler drives drift (worker restart, crashed VM) toward the
recorded desired state. `fork` = snapshot + N parallel restores (same artifact shape as
create-from-template — resume ≡ create).

## 5. SandboxSupervisor (worker actor)

One task per sandbox owning: `VmHandle`, `GuestAgentClient`, `Wal`, timers (idle, ttl,
heartbeat), and a command channel (`Exec`, `FilesOp`, `TerminalOpen`, `Pause`, `Resume`,
`Stop`, `Snapshot`, `Fork`, `Tick`). All external interactions bump `last_activity_at`
(background compute does not — Daytona semantics). Idle → auto-pause; TTL → expiry action;
heartbeat loss from guest agent → liveness probe → restart-from-journal on failure.

## 6. Durability model (Journal+FS, crash semantics stated honestly)

1. **Host WAL** (`crates/flint-journal`): every mutating op is appended with CRC32 framing
   and an op-id (idempotency key), fsync'd *before* dispatch to the VM. Records:
   `OpApplied{op_id, Op}`, `Barrier`, `SnapshotRef{manifest, wal_seq}`, `StateChange`.
2. **Guest journal**: guest agent mirrors FS ops into `/var/lib/flint/journal.log` inside the
   sandbox root (travels with the disk), fsync'd on `barrier`.
3. **Snapshots**: on pause/stop — freeze VM → `barrier` → pack overlay upperdir to the object
   store (tar+gz, sharded, sha256 per layer) + (prod) Firecracker memfile/snapfile diff.
   Manifest records `wal_seq` at snapshot.
4. **Crash recovery** (worker or VM death):
   - FS state: replay WAL `FileWrite/Mkdir/Remove/Move` ops with `op_id > snapshot wal_seq`
     onto the restored upperdir — deterministic (payloads are full contents), dedup by op_id.
   - Process state: not restored after crash (no CRIU by design). Restarts of "restartable"
     services are re-spawned from recorded `ProcessSpawnSpec`s. Documented loudly.
   - VM memory: preserved only across *clean* pause (Firecracker snapshot); a crash resumes
     from the last snapshot + journal replay (process state lost), matching the chosen
     Journal+FS tier.
5. **Templates** are snapshots with `kind=TemplateBase`; creation from template restores the
   stack and replays nothing.

## 7. Guest agent protocol (`flint-guest-agent`)

Transports: **AF_VSOCK :5252** (prod; host dials FC vsock UDS, sends `CONNECT 5252\n`,
reads `OK\n`, then a byte pipe) and **127.0.0.1 TCP** (dev / ProcessDriver). Both speak
identical `[u32 BE len][JSON]` frames. Requests carry `{id, method, params}`; replies
`{id, ok, result|error}`; long-lived ops (exec, PTY, port tunnel) push `{id, event}`
frames. Methods: `ping/version`, `exec`, `process.{spawn,list,kill,signal,input,wait}`,
`fs.{write,read,list,mkdir,remove,move,stat}`, `env.{set,get}`, `term.{open,input,resize,close}`,
`barrier`, `tools.invoke`, `port.connect`, `journal.status`. The agent is a
`PR_SET_CHILD_SUBREAPER` process supervisor with per-process cgroups (prod) and rlimits.
Exec supports optional PTY (openpty), timeout, env merge, cwd, and streams
stdout/stderr/exit events. Auth: per-sandbox token pushed via MMDS (prod) or argv (dev).

## 8. Scheduling & fleet

Workers register over gRPC (`fleet.proto`) and stream heartbeats: capacity {vcpu, mem_mib,
slots, disk_mib} + load {running, paused, cpu_pressure, mem_pressure}. Placement = sample
K workers (K=5), filter by hard constraints (template cached? disk headroom ≥
`pause_headroom_mib`, slots free), score `max(cpu_pressure, mem_pressure, slot_pressure)
+ U(0,jitter)`, pick min; `ResourceExhausted` → full-jitter backoff and retry. WarmPool
manager keeps `warm_target` pre-rested sandboxes per template (claim → refill). Routing
table `sbx → worker` with TTL = max sandbox life; gateway auto-resume on miss (§1).

## 9. Networking (`flint-net`)

Per-sandbox **slot**: dedicated netns `flint-<slot>`; veth pair (`10.12.x.y/31` pool,
32k slots); TAP `tap0` `169.254.0.22/30` inside netns; guest `169.254.0.21/30` from kernel
cmdline (no DHCP); single shared host-side TAP MAC so snapshot-restored guests' ARP caches
stay valid; MASQUERADE at host egress. Egress policy per sandbox: nftables inet table with
ip allow/deny sets + domain allowlist enforced by an SNI-inspecting TCP proxy; default-deny
is one flag (Freestyle semantics). Provisioned via `ip`/`nft` shell-outs, torn down on
delete; all state idempotent and re-drivable by the reconciler. Dev mode (ProcessDriver)
uses the agent-channel `port.connect` tunnel instead — no netns needed.

## 10. Security

- **Isolation**: Firecracker microVM (KVM), jailer'd (chroot, cgroups v2, seccomp, no
  devices beyond virtio net/blk/vsock). SMT off, `track_dirty_pages` on, CPU template pinned
  per template for snapshot compat.
- **Control plane**: API keys (hashed, constant-time compare), HMAC-SHA256 signed sandbox
  tokens (short TTL, scoped to one sandbox), per-key quotas + token-bucket rate limits.
- **Guest↔worker**: per-sandbox token in MMDS; agent rejects unauthenticated frames.
- **Egress**: default-deny capable per-sandbox firewall + brokered tool calls so guests
  never need credentials.
- **Worker**: every sandbox is a separate jailer cgroup + netns; the dev ProcessDriver is
  explicitly *not* an isolation boundary (labeled `dev-only`).

## 11. APIs

REST (`/v1/...`), WebSocket (`/v1/sandboxes/{id}/terminal`, `.../exec/{call}`,
`.../events`, `.../preview/{port}` HTTP proxy), gRPC (`api.proto`: Sandbox, Exec, Files,
Terminal, Tools, Templates, Usage; `fleet.proto`: Worker registry + `Operate` bidi stream
carrying op envelopes). REST and gRPC share the same handler core; WS maps onto agent
event streams. See `docs/API.md`.

## 12. What is *not* in v1 (honest limits)

Live migration (nobody has it; pause-snapshot-restore is the story), GPU snapshots
(Modal-only today), memory-snapshot crash recovery (clean-pause only), S3 diff-layer
compaction daemon (full layers only), per-tenant VPC peering. All have extension seams.
