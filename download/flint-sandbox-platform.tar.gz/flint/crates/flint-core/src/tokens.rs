//! API keys and HMAC-signed sandbox tokens.
//!
//! - API keys: `flint_sk_<rand>` shown once, stored as SHA-256 hashes.
//! - Sandbox tokens: compact `v1.<payload_b64>.<sig_b64>` HMAC-SHA256
//!   signatures carrying `{sub, scope, exp, iat, nonce}` — used for
//!   scoped, short-lived access to a single sandbox (research: Runloop
//!   scoped per-sandbox agent tokens).

use crate::{FlintError, Result};
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use hmac::{Hmac, Mac};
use rand::RngCore;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};

type HmacSha256 = Hmac<Sha256>;

pub fn now_unix() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn rand_hex(n_bytes: usize) -> String {
    let mut buf = vec![0u8; n_bytes];
    rand::thread_rng().fill_bytes(&mut buf);
    hex::encode(buf)
}

/// Generate a new API key. Returns `(key_id, secret)`; store the hash of
/// the secret, show the secret exactly once.
pub fn generate_api_key() -> (String, String) {
    let id = format!("key_{}", rand_hex(8));
    let secret = format!("flint_sk_{}", rand_hex(24));
    (id, secret)
}

/// SHA-256 hash of an API key secret (hex).
pub fn hash_api_key(secret: &str) -> String {
    let mut h = Sha256::new();
    h.update(secret.as_bytes());
    hex::encode(h.finalize())
}

/// Constant-time comparison of two byte strings.
pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

pub fn verify_api_key(secret: &str, stored_hash_hex: &str) -> bool {
    match hex::decode(stored_hash_hex) {
        Ok(stored) => ct_eq(hash_api_key(secret).as_bytes(), hex::encode(stored).as_bytes()),
        Err(_) => false,
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct TokenClaims {
    /// Subject: sandbox id or api key id.
    pub sub: String,
    /// Scope string, e.g. `sandbox:rw` or `key:admin`.
    pub scope: String,
    pub iat: u64,
    pub exp: u64,
    pub nonce: String,
}

fn b64(data: &[u8]) -> String {
    URL_SAFE_NO_PAD.encode(data)
}

fn b64d(s: &str) -> Option<Vec<u8>> {
    URL_SAFE_NO_PAD.decode(s).ok()
}

/// Sign claims into a compact token with an HMAC-SHA256 key.
pub fn sign_token(claims: &TokenClaims, key: &[u8]) -> String {
    let payload = serde_json::to_vec(claims).expect("claims serialize");
    let mut mac = HmacSha256::new_from_slice(key).expect("hmac key");
    mac.update(&payload);
    let sig = mac.finalize().into_bytes();
    format!("v1.{}.{}", b64(&payload), b64(&sig))
}

/// Verify + decode a token. Checks signature and expiry.
pub fn verify_token(token: &str, key: &[u8]) -> Result<TokenClaims> {
    let mut parts = token.splitn(3, '.');
    let ver = parts.next().unwrap_or_default();
    let payload = parts.next().unwrap_or_default();
    let sig = parts.next().unwrap_or_default();
    if ver != "v1" || payload.is_empty() || sig.is_empty() {
        return Err(FlintError::Unauthenticated { msg: "malformed token".into() });
    }
    let payload = b64d(payload).ok_or(FlintError::Unauthenticated { msg: "bad payload b64".into() })?;
    let sig = b64d(sig).ok_or(FlintError::Unauthenticated { msg: "bad sig b64".into() })?;
    let mut mac = HmacSha256::new_from_slice(key).map_err(|_| FlintError::Internal("bad hmac key".into()))?;
    mac.update(&payload);
    if !ct_eq(&sig, &mac.finalize().into_bytes()) {
        return Err(FlintError::Unauthenticated { msg: "bad signature".into() });
    }
    let claims: TokenClaims = serde_json::from_slice(&payload)
        .map_err(|e| FlintError::Unauthenticated { msg: format!("bad claims: {e}") })?;
    if claims.exp < now_unix() {
        return Err(FlintError::Unauthenticated { msg: "token expired".into() });
    }
    Ok(claims)
}

/// Random signing key (hex) for dev / first boot.
pub fn generate_signing_key() -> String {
    rand_hex(32)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_roundtrip_and_expiry() {
        let key = [b'k'; 32];
        let claims = TokenClaims {
            sub: "sbx_1".into(),
            scope: "sandbox:rw".into(),
            iat: now_unix(),
            exp: now_unix() + 60,
            nonce: rand_hex(8),
        };
        let tok = sign_token(&claims, &key);
        assert!(tok.starts_with("v1."));
        let got = verify_token(&tok, &key).unwrap();
        assert_eq!(got.sub, "sbx_1");
        // wrong key
        let bad = [b'j'; 32];
        assert!(verify_token(&tok, &bad).is_err());
        // expired
        let expired = TokenClaims { exp: now_unix() - 1, ..claims };
        assert!(verify_token(&sign_token(&expired, &key), &key).is_err());
    }

    #[test]
    fn api_key_hash_verify() {
        let (_, secret) = generate_api_key();
        let h = hash_api_key(&secret);
        assert!(verify_api_key(&secret, &h));
        assert!(!verify_api_key("flint_sk_wrong", &h));
    }
}
