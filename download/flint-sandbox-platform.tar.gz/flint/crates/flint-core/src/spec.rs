//! Resource and request specs shared by the gateway, scheduler, worker,
//! drivers and the guest agent.

use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

/// Which VM driver to use.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum DriverKind {
    /// Production: Firecracker microVM via jailer + UDS API + vsock agent.
    Firecracker,
    /// Development / CI: no isolation, plain child processes + a guest
    /// agent over TCP. **Never an isolation boundary.**
    #[default]
    Process,
}

/// Compute resources of a sandbox.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct VmSpec {
    pub vcpu_count: u32,
    pub mem_mib: u32,
    /// Writable layer size (overlay upperdir / scratch disk).
    pub disk_mib: u32,
}

impl Default for VmSpec {
    fn default() -> Self {
        Self { vcpu_count: 2, mem_mib: 2048, disk_mib: 10_240 }
    }
}

/// PTY geometry for interactive execs and terminals.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct PtySize {
    pub cols: u16,
    pub rows: u16,
}

impl Default for PtySize {
    fn default() -> Self {
        Self { cols: 80, rows: 24 }
    }
}

/// A fully specified execution request (sync exec, background process,
/// terminal session or journalled spawn — all share this shape).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ExecSpec {
    /// argv, e.g. `["sh","-c","cargo test"]`. Never a shell string.
    pub cmd: Vec<String>,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    pub cwd: Option<String>,
    /// Kill + report `timed_out` after this.
    pub timeout_ms: Option<u64>,
    /// Attach a PTY (required for terminals).
    pub pty: Option<PtySize>,
    /// Long-running processes marked restartable are re-spawned from this
    /// spec after crash recovery (Journal+FS tier: process state is not
    /// restored, only restarted).
    #[serde(default)]
    pub restartable: bool,
    /// Run as this user inside the sandbox (agent-side resolution).
    pub user: Option<String>,
}

impl ExecSpec {
    pub fn shell(cmd_line: impl Into<String>) -> Self {
        Self {
            cmd: vec!["/bin/sh".into(), "-c".into(), cmd_line.into()],
            env: BTreeMap::new(),
            cwd: None,
            timeout_ms: None,
            pty: None,
            restartable: false,
            user: None,
        }
    }
}

/// Request payload for `POST /v1/sandboxes`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SandboxCreateSpec {
    /// Template to restore from; `None` → default template.
    pub template_id: Option<String>,
    /// Project/namespace grouping (multi-tenancy-lite).
    pub project: Option<String>,
    #[serde(default)]
    pub vm: VmSpec,
    /// Env vars baked into the sandbox environment.
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    /// Free-form metadata, preserved in the store + snapshots.
    #[serde(default)]
    pub metadata: BTreeMap<String, String>,
    #[serde(default)]
    pub timeouts: crate::state::TimeoutPolicy,
    /// Override the node's default driver (dev/test).
    pub driver: Option<DriverKind>,
    /// Start paused instead of running (rare; used by restore-tests).
    #[serde(default)]
    pub start_paused: bool,
}

impl Default for SandboxCreateSpec {
    fn default() -> Self {
        Self {
            template_id: None,
            project: None,
            vm: VmSpec::default(),
            env: BTreeMap::new(),
            metadata: BTreeMap::new(),
            timeouts: crate::state::TimeoutPolicy::default(),
            driver: None,
            start_paused: false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exec_spec_shell_builds_argv() {
        let s = ExecSpec::shell("echo hi");
        assert_eq!(s.cmd, vec!["/bin/sh", "-c", "echo hi"]);
    }
}
