//! flint-worker library: the node daemon, usable embedded (gateway dev
//! mode) or standalone (`flint-worker` binary).

pub mod supervisor;

use anyhow::Result;
use flint_core::{FlintError, SandboxState};
use flint_proto::fleet::fleet_service_client::FleetServiceClient;
use flint_proto::fleet::worker_service_server::WorkerServiceServer;
use flint_proto::fleet::{
    DeleteSandboxLocalRequest, DeleteSandboxLocalResponse, EnsureSandboxRequest,
    EnsureSandboxResponse, HeartbeatMessage, OpEnvelope, OpEvent, PauseSandboxRequest,
    PauseSandboxResponse, RegisterRequest, ResumeSandboxRequest, ResumeSandboxResponse,
    SnapshotSandboxRequest, SnapshotSandboxResponse, StartSandboxRequest,
    StartSandboxResponse, StopSandboxRequest, StopSandboxResponse,
};
use flint_proto::fleet::worker_service_server::WorkerService;
use flint_store::{build_object_store, ObjectStore};
use flint_tools::ToolGateway;
use flint_vm::VmDriver;
use serde_json::json;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;
use supervisor::{SupCmd, SupHandle};
use tokio::sync::{mpsc, oneshot, RwLock};
use tokio_stream::StreamExt as _;
use tonic::transport::Server;
use tonic::{Request, Response, Status, Streaming};

pub struct WorkerRuntime {
    pub cfg: flint_core::config::WorkerConfig,
    pub node_id: String,
    pub driver: Arc<dyn VmDriver>,
    pub objects: Arc<dyn ObjectStore>,
    pub tools: Arc<ToolGateway>,
    pub net: Arc<flint_net::NetProvisioner>,
    pub sandboxes: Arc<RwLock<HashMap<String, SupHandle>>>,
    fleet_tx: mpsc::Sender<flint_proto::fleet::HeartbeatMessage>,
}

impl WorkerRuntime {
    /// Boot the worker: driver init, gRPC server, fleet registration +
    /// heartbeat loop. Returns once the server is listening.
    pub async fn start(cfg: flint_core::config::WorkerConfig) -> Result<Arc<Self>> {
        let work_dir = cfg.work_dir.clone();
        std::fs::create_dir_all(&work_dir)?;

        let driver = flint_vm::build_driver(&cfg.driver, &work_dir)?;
        driver.init().await?;

        let objects = build_object_store(&cfg.object_store)?;
        let tools = Arc::new(ToolGateway::from_config(&Default::default()));
        let net = Arc::new(flint_net::NetProvisioner::new(
            cfg.net.enabled,
            &cfg.net.veth_subnet,
            cfg.net.slots,
            &cfg.net.default_policy,
        )?);

        let (fleet_tx, fleet_rx) = mpsc::channel(64);
        let rt = Arc::new(Self {
            cfg: cfg.clone(),
            node_id: cfg.node_id.clone(),
            driver,
            objects,
            tools,
            net,
            sandboxes: Arc::new(RwLock::new(HashMap::new())),
            fleet_tx,
        });

        // Pick a free port for the worker gRPC server.
        let bind: std::net::SocketAddr = match cfg.worker_bind.parse() {
            Ok(a) => a,
            Err(_) => return Err(anyhow::anyhow!("invalid worker bind: {}", cfg.worker_bind)),
        };
        let listener = tokio::net::TcpListener::bind(bind).await?;
        let actual = listener.local_addr()?;

        let svc = WorkerServiceImpl { rt: rt.clone() };
        let node_id = rt.node_id.clone();
        tokio::spawn(async move {
            if let Err(e) = Server::builder()
                .add_service(WorkerServiceServer::new(svc))
                .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(listener))
                .await
            {
                tracing::error!(error = %e, "worker gRPC server failed");
            }
        });

        // Fleet client: register + heartbeat.
        let fleet = FleetRunner {
            cfg: cfg.clone(),
            addr: format!("http://{actual}"),
            sandboxes: rt.sandboxes.clone(),
            capacity: cfg.capacity.clone(),
        };
        tokio::spawn(fleet.run(fleet_rx));

        tracing::info!(node = %node_id, addr = %actual, "flint-worker up");
        Ok(rt)
    }

    pub fn worker_addr(&self) -> String {
        format!("http://{}", self.cfg.worker_bind)
    }

    // ----- supervisor management -----

    pub async fn get_or_spawn(self: &Arc<Self>, req: StartSandboxRequest) -> Result<SupHandle> {
        {
            let map = self.sandboxes.read().await;
            if let Some(h) = map.get(&req.sandbox_id) {
                return Ok(h.clone());
            }
        }
        let info = supervisor::parse_start(&req)?;
        let handle = self.spawn_from_start(info).await?;
        self.sandboxes.write().await.insert(req.sandbox_id, handle.clone());
        Ok(handle)
    }

    pub async fn handle(&self, sandbox_id: &str) -> std::result::Result<SupHandle, FlintError> {
        self.sandboxes
            .read()
            .await
            .get(sandbox_id)
            .cloned()
            .ok_or(FlintError::NotFound { resource: "sandbox on worker", id: sandbox_id.to_string() })
    }

    pub async fn send_report(&self, sandbox_id: &str, state: &str, snapshot_id: &str, error: &str) {
        let _ = self.fleet_tx.try_send(HeartbeatMessage {
            node_id: self.node_id.clone(),
            running: 0,
            paused: 0,
            cpu_pressure: 0.0,
            mem_pressure: 0.0,
            slot_pressure: 0.0,
            sandbox_ids: vec![],
            load_json: json!({
                "report": { "sandbox_id": sandbox_id, "state": state, "snapshot_id": snapshot_id, "error": error }
            })
            .to_string(),
        });
    }
}

// ---------------------------------------------------------------------------
// WorkerService gRPC (gateway → worker)
// ---------------------------------------------------------------------------

struct WorkerServiceImpl {
    rt: Arc<WorkerRuntime>,
}

#[tonic::async_trait]
impl WorkerService for WorkerServiceImpl {
    async fn start_sandbox(
        &self,
        request: Request<StartSandboxRequest>,
    ) -> std::result::Result<Response<StartSandboxResponse>, Status> {
        let req = request.into_inner();
        match self.rt.get_or_spawn(req).await {
            Ok(_) => Ok(Response::new(StartSandboxResponse { ok: true, error: String::new() })),
            Err(e) => Ok(Response::new(StartSandboxResponse { ok: false, error: e.to_string() })),
        }
    }

    async fn ensure_sandbox(
        &self,
        request: Request<EnsureSandboxRequest>,
    ) -> std::result::Result<Response<EnsureSandboxResponse>, Status> {
        let req = request.into_inner();
        // Reconcile: if we don't hold this sandbox, report that so the
        // gateway can re-schedule.
        let held = self.rt.sandboxes.read().await.contains_key(&req.sandbox_id);
        Ok(Response::new(EnsureSandboxResponse {
            ok: held,
            error: if held { String::new() } else { "not held".into() },
        }))
    }

    async fn pause_sandbox(
        &self,
        request: Request<PauseSandboxRequest>,
    ) -> std::result::Result<Response<PauseSandboxResponse>, Status> {
        let req = request.into_inner();
        let h = match self.rt.handle(&req.sandbox_id).await {
            Ok(h) => h,
            Err(e) => {
                return Ok(Response::new(PauseSandboxResponse {
                    ok: false,
                    snapshot_id: String::new(),
                    error: e.to_string(),
                }))
            }
        };
        match h.pause(Duration::from_secs(120)).await {
            Ok(snap) => Ok(Response::new(PauseSandboxResponse { ok: true, snapshot_id: snap, error: String::new() })),
            Err(e) => Ok(Response::new(PauseSandboxResponse { ok: false, snapshot_id: String::new(), error: e.to_string() })),
        }
    }

    async fn resume_sandbox(
        &self,
        request: Request<ResumeSandboxRequest>,
    ) -> std::result::Result<Response<ResumeSandboxResponse>, Status> {
        let req = request.into_inner();
        let h = match self.rt.handle(&req.sandbox_id).await {
            Ok(h) => h,
            Err(e) => {
                return Ok(Response::new(ResumeSandboxResponse { ok: false, error: e.to_string() }))
            }
        };
        match h.resume().await {
            Ok(_) => Ok(Response::new(ResumeSandboxResponse { ok: true, error: String::new() })),
            Err(e) => Ok(Response::new(ResumeSandboxResponse { ok: false, error: e.to_string() })),
        }
    }

    async fn stop_sandbox(
        &self,
        request: Request<StopSandboxRequest>,
    ) -> std::result::Result<Response<StopSandboxResponse>, Status> {
        let req = request.into_inner();
        let h = match self.rt.handle(&req.sandbox_id).await {
            Ok(h) => h,
            Err(e) => {
                return Ok(Response::new(StopSandboxResponse { ok: false, snapshot_id: String::new(), error: e.to_string() }))
            }
        };
        match h.stop(req.keep_state).await {
            Ok(snap) => Ok(Response::new(StopSandboxResponse { ok: true, snapshot_id: snap, error: String::new() })),
            Err(e) => Ok(Response::new(StopSandboxResponse { ok: false, snapshot_id: String::new(), error: e.to_string() })),
        }
    }

    async fn delete_sandbox_local(
        &self,
        request: Request<DeleteSandboxLocalRequest>,
    ) -> std::result::Result<Response<DeleteSandboxLocalResponse>, Status> {
        let req = request.into_inner();
        if let Some(h) = self.rt.sandboxes.read().await.get(&req.sandbox_id).cloned() {
            let _ = h.stop(false).await;
        }
        self.rt.sandboxes.write().await.remove(&req.sandbox_id);
        Ok(Response::new(DeleteSandboxLocalResponse { ok: true }))
    }

    async fn snapshot_sandbox(
        &self,
        request: Request<SnapshotSandboxRequest>,
    ) -> std::result::Result<Response<SnapshotSandboxResponse>, Status> {
        let req = request.into_inner();
        let h = match self.rt.handle(&req.sandbox_id).await {
            Ok(h) => h,
            Err(e) => {
                return Ok(Response::new(SnapshotSandboxResponse { ok: false, snapshot_id: String::new(), error: e.to_string() }))
            }
        };
        match h.snapshot(&req.kind).await {
            Ok(snap) => Ok(Response::new(SnapshotSandboxResponse { ok: true, snapshot_id: snap, error: String::new() })),
            Err(e) => Ok(Response::new(SnapshotSandboxResponse { ok: false, snapshot_id: String::new(), error: e.to_string() })),
        }
    }

    type OperateStream = std::pin::Pin<Box<dyn tokio_stream::Stream<Item = std::result::Result<OpEvent, Status>> + Send>>;

    async fn operate(
        &self,
        request: Request<Streaming<OpEnvelope>>,
    ) -> std::result::Result<Response<Self::OperateStream>, Status> {
        let mut inbound = request.into_inner();
        let rt = self.rt.clone();
        let (tx, rx) = mpsc::channel::<std::result::Result<OpEvent, Status>>(256);

        tokio::spawn(async move {
            while let Some(Ok(env)) = inbound.next().await {
                let rt = rt.clone();
                let tx = tx.clone();
                tokio::spawn(async move {
                    if let Err(e) = handle_envelope(&rt, env, tx).await {
                        tracing::warn!(error = %e, "op failed");
                    }
                });
            }
        });

        let stream = tokio_stream::wrappers::ReceiverStream::new(rx);
        Ok(Response::new(Box::pin(stream) as Self::OperateStream))
    }
}

/// Route one op envelope: tools handled at the worker; everything else is
/// forwarded to the sandbox supervisor → guest agent.
async fn handle_envelope(
    rt: &Arc<WorkerRuntime>,
    env: OpEnvelope,
    tx: mpsc::Sender<std::result::Result<OpEvent, Status>>,
) -> Result<()> {
    fn mk_event(op_id: &str, kind: &str, payload: String, final_: bool, error: String) -> OpEvent {
        OpEvent { op_id: op_id.to_string(), kind: kind.to_string(), r#final: final_, payload_json: payload, error }
    }

    // Tools never touch the sandbox.
    if env.kind == "tools.invoke" {
        let result = worker_tool_invoke(rt, &env.payload_json).await;
        let (payload, error) = match result {
            Ok(v) => (v.to_string(), String::new()),
            Err(e) => (String::new(), e.to_string()),
        };
        let _ = tx.send(Ok(mk_event(&env.op_id, "tools.result", payload, true, error))).await;
        return Ok(());
    }

    let h = rt.handle(&env.sandbox_id).await?;
    let (ev_tx, mut ev_rx) = mpsc::channel::<supervisor::SupEvent>(256);
    let (cmd_tx, cmd_rx) = oneshot::channel();
    let streaming = matches!(
        env.kind.as_str(),
        "exec.stream" | "term.open" | "port.connect" | "process.attach"
    );
    let cmd = if streaming {
        SupCmd::OpStream { kind: env.kind.clone(), payload: env.payload_json.clone(), events: ev_tx, resp: cmd_tx }
    } else {
        SupCmd::Op { kind: env.kind.clone(), payload: env.payload_json.clone(), resp: cmd_tx }
    };
    h.send(cmd).await?;
    {
        let tx = tx.clone();
        let op_id = env.op_id.clone();
        tokio::spawn(async move {
            while let Some(ev) = ev_rx.recv().await {
                let _ = tx
                    .send(Ok(OpEvent {
                        op_id: op_id.clone(),
                        kind: ev.kind.clone(),
                        r#final: ev.final_,
                        payload_json: ev.payload.clone(),
                        error: ev.error.clone().unwrap_or_default(),
                    }))
                    .await;
            }
        });
    }
    match cmd_rx.await {
        Ok(Ok(result)) => {
            let _ = tx
                .send(Ok(mk_event(&env.op_id, &env.kind, result.to_string(), !streaming, String::new())))
                .await;
        }
        Ok(Err(e)) => {
            let _ = tx.send(Ok(mk_event(&env.op_id, &env.kind, String::new(), true, e.to_string()))).await;
        }
        Err(_) => {
            let _ = tx.send(Ok(mk_event(&env.op_id, &env.kind, String::new(), true, "supervisor gone".into()))).await;
        }
    }
    Ok(())
}

async fn worker_tool_invoke(rt: &Arc<WorkerRuntime>, payload_json: &str) -> Result<serde_json::Value> {
    let v: serde_json::Value = serde_json::from_str(payload_json)?;
    match v.get("tool").and_then(|t| t.as_str()).unwrap_or("") {
        "web_search" => {
            let q = v.get("query").and_then(|q| q.as_str()).unwrap_or("");
            let n = v.get("num").and_then(|n| n.as_u64()).unwrap_or(5) as usize;
            Ok(serde_json::to_value(rt.tools.web_search(q, n)? )?)
        }
        "http_fetch" => {
            let url = v.get("url").and_then(|u| u.as_str()).unwrap_or("");
            Ok(serde_json::to_value(rt.tools.http_fetch(url)? )?)
        }
        other => Err(anyhow::anyhow!("unknown tool: {other}")),
    }
}

// ---------------------------------------------------------------------------
// Fleet client: register + heartbeats (worker → gateway)
// ---------------------------------------------------------------------------

struct FleetRunner {
    cfg: flint_core::config::WorkerConfig,
    addr: String,
    sandboxes: Arc<RwLock<HashMap<String, SupHandle>>>,
    capacity: flint_core::config::CapacityConfig,
}

impl FleetRunner {
    async fn run(self, mut report_rx: mpsc::Receiver<HeartbeatMessage>) {
        loop {
            if let Err(e) = self.run_once(&mut report_rx).await {
                tracing::warn!(error = %e, "fleet connection failed; retrying in 3s");
                tokio::time::sleep(Duration::from_secs(3)).await;
            }
        }
    }

    async fn run_once(&self, report_rx: &mut mpsc::Receiver<HeartbeatMessage>) -> Result<()> {
        let mut client = FleetServiceClient::connect(self.cfg.gateway_addr.clone()).await?;
        client
            .register(Request::new(RegisterRequest {
                node_id: self.cfg.node_id.clone(),
                addr: self.addr.clone(),
                vcpu_total: self.capacity.vcpu_total,
                mem_mib_total: self.capacity.mem_mib_total,
                max_sandboxes: self.capacity.max_sandboxes as u32,
                pause_headroom_mib: self.capacity.pause_headroom_mib,
                driver_kind: format!("{:?}", self.cfg.driver).to_lowercase(),
            }))
            .await?;

        loop {
            // Compute load from live supervisors.
            let map = self.sandboxes.read().await;
            let mut running = 0u32;
            let mut paused = 0u32;
            let mut cpu_used = 0u32;
            let mut mem_used = 0u32;
            for h in map.values() {
                match h.state().await {
                    SandboxState::Paused | SandboxState::Stopped => paused += 1,
                    SandboxState::Running | SandboxState::Creating => {
                        running += 1;
                        cpu_used += h.vm_spec().vcpu_count;
                        mem_used += h.vm_spec().mem_mib;
                    }
                    _ => {}
                }
            }
            drop(map);
            let cpu_pressure = if self.capacity.vcpu_total > 0 {
                cpu_used as f64 / self.capacity.vcpu_total as f64
            } else {
                0.0
            };
            let mem_pressure = if self.capacity.mem_mib_total > 0 {
                mem_used as f64 / self.capacity.mem_mib_total as f64
            } else {
                0.0
            };
            let slot_pressure = if self.capacity.max_sandboxes > 0 {
                (running + paused) as f64 / self.capacity.max_sandboxes as f64
            } else {
                0.0
            };

            let hb = HeartbeatMessage {
                node_id: self.cfg.node_id.clone(),
                running,
                paused,
                cpu_pressure: cpu_pressure.clamp(0.0, 1.0),
                mem_pressure: mem_pressure.clamp(0.0, 1.0),
                slot_pressure: slot_pressure.clamp(0.0, 1.0),
                sandbox_ids: vec![],
                load_json: String::new(),
            };

            tokio::select! {
                report = report_rx.recv() => {
                    let report = match report {
                        Some(r) => r,
                        None => return Ok(()),
                    };
                    // Send heartbeat with the piggybacked report.
                    let _ = client.heartbeat(Request::new(tokio_stream::iter(vec![hb, report]))).await?;
                }
                _ = tokio::time::sleep(Duration::from_secs(5)) => {
                    let _ = client.heartbeat(Request::new(tokio_stream::iter(vec![hb]))).await?;
                }
            }
        }
    }
}
