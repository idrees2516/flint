# Flint Security Model

## Isolation boundary

**Production (Firecracker driver):** each sandbox is a KVM microVM with
its own kernel, memory, and block device, started through the jailer
(chroot, cgroups, seccomp, no extra devices beyond virtio
net/blk/vsock). VM-to-VM and VM-to-host escape requires a kernel or KVM
bug — the same boundary E2B/Modal/Freestyle ship. SMT is disabled per
VM (`smt: false`), dirty-page tracking is on for snapshot work, and CPU
templates are pinned for snapshot compatibility.

**Dev (Process driver): NO isolation.** The sandbox is a process group
with a directory. It exists to run the full platform on laptops/CI and
must never be exposed to untrusted code.

## Control plane

- **API keys**: `flint_sk_...` shown once, stored as SHA-256 hashes,
  constant-time comparison, revocable. Bootstrap key printed once on
  first boot (or pinned via `FLINT_BOOTSTRAP_API_KEY`).
- **Rate limits**: token bucket per key (`limits.max_req_per_sec_per_key`).
- **Quotas**: concurrent sandboxes, tool calls/day per key.
- **Tenant isolation**: sandboxes are keyed; cross-key reads 404 rather
  than 403 to avoid existence leaks.

## Guest ↔ worker channel

- vsock (prod) or localhost TCP (dev): host-dialed, so only the worker
  can reach the agent. The per-sandbox agent token is pushed via MMDS
  (prod) and used for the `shutdown` method gate.
- The agent never trusts sandbox-absolute paths: `safe_join` rejects
  escapes; the same check runs again during host-side WAL replay.

## Egress

- Per-sandbox netns + nftables policy: default-allow or default-deny,
  IP allow/deny sets, SNI domain allowlist path.
- **Brokered tools**: agents get `web_search`/`http_fetch` through the
  platform API, so the guest needs no egress and never sees provider
  keys (Runloop gateway pattern). `http_fetch` blocks internal targets
  (localhost/169.254.*/RFC1918) and caps body size.

## File/protocol hygiene

- Tar extraction (snapshot restore) is escape-proof: no absolute paths,
  no `..` escapes, symlinks must be lexically in-root, hardlinks only
  inside the archive root.
- WAL records are CRC32-framed and length-capped; corrupt tails are
  truncated at recovery.
- Agent frames are length-capped (64 MiB) with a read-buffer overflow
  kill-switch; output per exec is capped (`limits.max_output_bytes`).
- `exec` takes argv (never a host-side shell string); timeouts kill the
  whole process group; PTY sessions get a controlling-terminal kill on
  close.

## Known gaps (be honest)

- Single active gateway (no HA failover); the meta store is SQLite.
- No per-sandbox seccomp profiles for exec'd processes inside the guest.
- S3 path uses SigV4 with env/config credentials; no IAM role support.
- WS auth happens at upgrade time; sessions don't re-authenticate.
- gRPC exec streaming is aggregated; WS/SSE carry the streaming paths.
