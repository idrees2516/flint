# Daytona (daytona.io) — Research Report

*Researched: Task R1. Sources: daytona.io docs (fetched as markdown via /docs/en/*.md and llms.txt), github.com/daytonaio/daytona, third-party comparisons.*

## Overview

Daytona describes itself as **"a secure and elastic infrastructure for running AI-generated code"**. Sandboxes are "full composable computers": isolated runtime environments with dedicated kernel (for VM classes), filesystem, network stack, and reserved vCPU/RAM/disk that agents manage programmatically via **SDKs (Python, TypeScript, Ruby, Go, Java), REST API, CLI, MCP server, dashboard, SSH, and a web terminal**. Headline metrics: **<90ms** from create to execution (fastest cold start among major sandbox platforms — third-party benchmarks: Daytona ~90ms vs E2B ~150ms), OCI/Docker-compatible images, "massive parallelization, and unlimited persistence." Daytona began as an open-source **standardized development environment orchestrator** (the `daytona` CLI that spun up dev environments on any infra — the repo has **71.6k GitHub stars**, making it one of the most-starred infra repos) and **pivoted to AI code-execution sandboxes**; as of June 2026 core development moved to a **private codebase** (the OSS repo is archived/unmaintained but forkable, Apache-licensed at v0.190.0). Docs and Helm charts/terraform modules remain public.

## Isolation & Architecture

Docs: https://www.daytona.io/docs/en/architecture.md, /isolation.md. Three-plane architecture:

- **Interface plane**: SDKs, CLI, Dashboard, MCP server, SSH.
- **Control plane**: a NestJS REST API (auth via Auth0/OIDC + SSO/SAML, org-level multi-tenancy; **PostgreSQL** metadata, **Redis** cache/session/distributed locking, PostHog analytics, SMTP) containing in-process **Sandbox manager** (schedules sandboxes onto runners, reconciles state, enforces lifecycle policies — a controller/reconciler pattern) and **Snapshot builder** (orchestrates image builds from Dockerfiles/registries). A dedicated **Proxy** does host-based routing: every sandbox reachable at `{port}-{sandboxId}.{proxy-domain}`, injecting auth headers; HTTP + WebSocket.
- **Compute plane**: **runners** (compute nodes) that *poll the control plane API for jobs* and execute sandbox operations (create/start/stop/destroy/resize/backup), pulling snapshot images from an internal **OCI-compliant snapshot registry** backed by S3-compatible object storage. Each sandbox runs with its own Linux namespaces (process, network, mount, IPC) and cgroup-enforced reserved resources. Inside every sandbox a **sandbox daemon** exposes the "Toolbox API" (fs, git, process/code exec, computer use, log streaming, terminal sessions).

**Sandbox classes are tiered by isolation** (key differentiator vs E2B): **Container** (default; Linux namespaces + cgroups; root inside sandbox; <90ms start; supports archive, cold snapshots only), **Linux VM / Windows VM** (full VM, own kernel → enables pause/resume with memory, fork, hot snapshots, nested virtualization/KVM passthrough), **GPU containers** (exclusive NVIDIA H100/H200/RTX/AMD MI355X allocation; ephemeral on stop), **macOS** (dedicated Apple silicon for computer-use automation). Historical note: earlier open-source Daytona used gVisor in some paths; today's production tech is namespaces-based containers plus VMs.

## API Surface

- Control-plane REST (`app.daytona.io/api`): `POST /sandbox` (from snapshot / image / Dockerfile via `buildInfo.dockerfileContent`), list/get/label/resize, lifecycle ops (`start`, `stop`, `pause`, `resume`, `archive`, `fork`, `recover`, `autostop/{interval}`), snapshots CRUD + activate/deactivate, volumes, organizations, API keys (with permissions & scopes, managed child keys), webhooks, audit logs. OpenAPI specs published at /docs/openapi.json (API, Toolbox, Analytics).
- **Toolbox API (in-sandbox daemon)**: `process` module (code run stateless & stateful with persistent interpreter context, command execution, **sessions** = independent persistent shells that survive across commands and host long-lived background processes), filesystem ops (incl. find, search, upload/download, watch), **Git operations** (clone/pull/branch/add-commits/push — first-class), **LSP** (Language Server Protocol — diagnostics, completions, hover, go-to-definition), **PTY** (pseudo-terminal sessions), computer use (screenshots, click/type), log streaming (long-running session commands), secrets service, object storage, volume service.
- SDK surface: `daytona.create(params)`, `sandbox.process.code_run/command_execution/sessions`, `sandbox.fs`, `sandbox.git`, `sandbox.lsp`, `sandbox.pty`, `sandbox.computer_use`, `sandbox.set_preview_proxy`, lifecycle methods. Ruby/Go/Java SDKs alongside Python/TS.
- Human access: **web terminal** (browser shell), SSH (token-authed), VNC (macOS/Windows), VPN connections, authenticated preview URLs with `public` opt-out.

## Persistence & Lifecycle

Daytona has the most explicit **state machine** of the four (docs/en/sandboxes.md): states include `Unknown, Pulling Snapshot, Building Snapshot, Pending Build, Build Failed, Creating, Starting, Started, Stopping, Stopped, Pausing, Paused, Resuming, Archiving, Archived, Restoring, Resizing, Snapshotting, Forking, Deleting, Deleted, Error` — with a published transition table (e.g. `Started → Pausing` on auto-pause interval expiry; `Error → Restoring` on recover; `Error → Archiving` to preserve state of errored sandboxes with completed backups).

- **Class-dependent persistence**: Container stop clears memory but **filesystem persists on the runner**; **archive** moves container filesystem to object storage (frees quota & billing). VM stop **offloads filesystem state to nearby storage**; **pause** freezes VM with filesystem + memory intact (paused state offloaded to storage, memory not billed). Resume restores processes from the frozen point.
- **Snapshots** are the template mechanism (note: Daytona's "snapshot" = E2B's "template"): built from public/private OCI images or Dockerfiles (any OCI registry supported: Docker Hub, GAR, GHCR, ECR, private w/ credentials), or **captured from a sandbox**: *cold snapshot* (filesystem only, stopped sandbox — works even for containers) or *hot snapshot* (filesystem + memory, VM only). Any number of sandboxes can start from one snapshot ("snapshot fan-out" for fleet scale). Snapshot states: Pending, Building/Pulling, Snapshotting, Active, Inactive, Error, Build Failed, Removing.
- **Fork** (VM only): duplicates filesystem+memory into an independent sandbox; **fork-tree lineage tracking**; forks of forks allowed; parent can't be deleted while children active.
- **Automated lifecycle management**: `auto_stop_interval` (default **15 min** inactivity; 0 = run indefinitely), `auto_pause_interval` (VM-only, mutually exclusive with auto-stop), `auto_archive_interval`, `auto_delete_interval`, plus **wall-clock TTL** (destroy at fixed deadline regardless of state) and an explicit "update last activity" API. Crucial policy detail: the inactivity timer resets **only on external interactions** (lifecycle ops, preview traffic, SSH sessions, Toolbox API calls) — *background scripts and long-running compute do NOT count as activity*, so agents must send keep-alive signals for long jobs.
- **Ephemeral sandboxes** auto-delete on stop (also the behavior for GPU sandboxes).
- **Warm pools**: pre-created running sandboxes per (snapshot, region); create request that matches snapshot+region+default resources+default user+no custom env "claims" a warm sandbox instantly; auto-replenishment keeps pool size.

## Agent-Specific Features

Stateful code interpreters (persistent Python context), sessions, PTY, LSP integration (unique — enables code-aware agents), Git operations (unique), computer use (incl. macOS), MCP server, linked sandboxes (sandbox-to-sandbox DNS-aliased link networks — parent/children can talk by name; default no shared network), network egress control (block-all / CIDR allowlist / domain allowlist / outbound proxy), env vars, secrets service, volumes (S3-backed, multi-mount shared storage), webhooks, audit logs, OTel collection, regions incl. a GPU "Earth" region, bring-your-own-compute, log streaming. Extensive integration guides (Claude Code/OpenAI/Codex/Cursor/Devin/CopilotKit/LangGraph/OpenClaw/RL frameworks incl. TRL-GRPO, verl).

## Pricing & Limits

Pay-as-you-go wallet, billed on **reserved** vCPU/RAM/disk by state: Started/transitioning = all resources; Stopped = disk only; Paused = disk only (memory free); Archived = nothing. Unit rates ≈ E2B ($0.0504/vCPU-hr, $0.0162/GiB-hr per third-party comparisons). Tier system (by verification status) governs compute pool, rate limits, and network restrictions (Tier 1–2 have restricted egress; essential package registries reachable by default). Default sandbox 1 vCPU/1GiB RAM/3GiB disk; org max 4 vCPU/8GiB RAM/10GiB disk per sandbox (customizable). Resize: CPU/mem up live; down (and disk up) requires stop; disk only grows.

## Open-Source & Engineering Notes

- **github.com/daytonaio/daytona** — original OSS platform (71.6k stars; unmaintained since June 2026, development private). https://github.com/daytonaio/daytona
- **github.com/daytonaio/docs** (Apache/AGPL-style docs), **helm-charts**, **terraform-modules**, **sandbox-network-whitelist**, integration plugins (langchain, Google ADK, AgentKit).
- Docs are LLM-friendly: full markdown at `/docs/en/*.md`, index at `/llms.txt`, OpenAPI JSONs — a deliberate AI-agent-distribution strategy worth copying.
- Docs: https://www.daytona.io/docs/en/sandboxes.md (lifecycle), /persistence.md, /snapshots.md, /isolation.md, /architecture.md, /scale.md, /warm-pools.md, /billing.md, /limits.md.

## Lessons for a Rust Implementation

1. **Publish an explicit state machine** (states + transition table + per-class capability matrix). Daytona's table is the clearest spec in the industry; implement it as a Rust enum + typed transitions with reconcile loops (their sandbox manager is a Kubernetes-style reconciler — idiomatic to replicate with a Rust controller).
2. **Split pause (VM) vs stop (containers) vs archive (fs → object storage)** as three orthogonal persistence tiers with **state-dependent billing** (memory free when paused; nothing billed when archived).
3. **Inactivity semantics matter**: define exactly what resets the idle timer (external interactions only), expose an explicit `update last activity` API, and add wall-clock TTL separate from idle timers.
4. **Warm pools** (pre-provisioned, match-on-create claim + auto-replenish) are a simpler alternative/complement to snapshot-restore for instant availability — especially for container-class sandboxes.
5. **Toolbox inside the sandbox should be a superset of exec**: sessions, PTY, fs, git, LSP, computer-use, log streaming — LSP and Git support are standout agent features nobody else ships natively.
6. **OCI compatibility as the template format** (any registry, Dockerfile, hot/cold capture from running sandbox) lowers adoption friction vs bespoke template systems.
7. Runner-pull job model (nodes poll control plane) is simpler than E2B's gRPC push; fine at Daytona's scale, and pairs with an edge proxy for `{port}-{id}.{domain}` routing.

**Most differentiating idea:** the **explicitly documented sandbox state machine with automated lifecycle policies (auto-stop/pause/archive/delete + wall-clock TTL)** and **multi-class sandboxes (container/VM/GPU/macOS/Windows)** under one API — plus best-in-class developer/agent ergonomics (5 SDKs, MCP, LSP, Git, llms.txt docs).
