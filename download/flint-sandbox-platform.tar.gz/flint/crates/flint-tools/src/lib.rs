//! Agent tool gateway (ARCHITECTURE §1 "brokered tool calls").
//!
//! Agents running inside locked-down sandboxes call tools through the
//! worker (over the agent channel) so the guest never needs egress
//! credentials. Providers: DuckDuckGo (keyless), Brave (API key), Tavily
//! (API key). `http_fetch` is a size-capped fetch. Results are cached and
//! quota-enforced by the gateway.

use flint_core::{FlintError, Result};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::{Duration, Instant};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SearchResult {
    pub title: String,
    pub url: String,
    pub snippet: String,
    pub host: String,
    #[serde(default)]
    pub date: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FetchResult {
    pub status: u16,
    pub content_type: String,
    pub body_b64: String,
    pub size_b: u64,
}

pub trait WebSearchProvider: Send + Sync {
    fn name(&self) -> &'static str;
    fn search(&self, query: &str, num: usize) -> Result<Vec<SearchResult>>;
}

// ---------------------------------------------------------------------------
// DuckDuckGo (keyless, HTML lite endpoint)
// ---------------------------------------------------------------------------

pub struct DuckDuckGoProvider;

impl WebSearchProvider for DuckDuckGoProvider {
    fn name(&self) -> &'static str {
        "duckduckgo"
    }

    fn search(&self, query: &str, num: usize) -> Result<Vec<SearchResult>> {
        let url = format!("https://lite.duckduckgo.com/lite/?q={}", urlencode(query));
        let resp = ureq::get(&url)
            .set("User-Agent", "flint/0.1 (+https://example.invalid)")
            .timeout(Duration::from_secs(15))
            .call()
            .map_err(|e| FlintError::Internal(format!("ddg: {e}")))?;
        if resp.status() >= 300 {
            return Err(FlintError::Internal(format!("ddg status {}", resp.status())));
        }
        let body = resp
            .into_string()
            .map_err(|e| FlintError::Internal(format!("ddg read: {e}")))?;
        Ok(parse_ddg_lite(&body, num))
    }
}

fn urlencode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => out.push(b as char),
            b' ' => out.push('+'),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

/// Minimal parse of the DDG lite HTML table: rows alternate result-link /
/// snippet. Keeps the dependency tree scraper-free.
fn parse_ddg_lite(html: &str, num: usize) -> Vec<SearchResult> {
    let mut results = Vec::new();
    let mut current_link: Option<String> = None;
    let mut current_title: Option<String> = None;
    for line in html.lines() {
        let line = line.trim();
        if let Some((href, title)) = extract_link(line) {
            if let Some(link) = current_link.take() {
                if let Some(t) = current_title.take() {
                    results.push(mk_result(t, link));
                }
            }
            if !href.starts_with("http://duckduckgo.com/y.js") && !href.contains("/l/?uddg=") && href.starts_with("http") {
                current_link = Some(href);
                current_title = Some(title);
            }
        }
        if line.contains("class=\"result-snippet\"") || line.contains("class='result-snippet'") {
            if current_link.is_some() {
                let snippet = strip_tags(line);
                if let (Some(l), Some(t)) = (current_link.take(), current_title.take()) {
                    let mut r = mk_result(t, l);
                    r.snippet = snippet;
                    results.push(r);
                    if results.len() >= num {
                        break;
                    }
                }
            }
        }
    }
    results
}

fn extract_link(line: &str) -> Option<(String, String)> {
    let start = line.find("href=\"")? + 6;
    let href_end = line[start..].find('"')? + start;
    let href = &line[start..href_end];
    let after = &line[href_end..];
    let tstart = after.find('>')? + 1;
    let tend = after[tstart..].find("</a>")? + tstart;
    let title = strip_tags(&after[tstart..tend]);
    if href.is_empty() || title.is_empty() {
        return None;
    }
    Some((href.to_string(), title))
}

fn strip_tags(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut in_tag = false;
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '<' => in_tag = true,
            '>' => in_tag = false,
            '&' if !in_tag => {
                // Minimal entity decode.
                let mut ent = String::new();
                ent.push(c);
                while let Some(&nc) = chars.peek() {
                    ent.push(nc);
                    chars.next();
                    if nc == ';' {
                        break;
                    }
                    if ent.len() > 8 {
                        break;
                    }
                }
                out.push_str(match ent.as_str() {
                    "&amp;" => "&",
                    "&lt;" => "<",
                    "&gt;" => ">",
                    "&quot;" => "\"",
                    "&#x27;" | "&#39;" => "'",
                    "&nbsp;" => " ",
                    other => other,
                });
            }
            c if !in_tag => out.push(c),
            _ => {}
        }
    }
    out.trim().to_string()
}

fn mk_result(title: String, url: String) -> SearchResult {
    let host = url
        .split("//")
        .nth(1)
        .and_then(|rest| rest.split('/').next())
        .unwrap_or("")
        .to_string();
    SearchResult { title, url, host, snippet: String::new(), date: String::new() }
}

// ---------------------------------------------------------------------------
// Brave
// ---------------------------------------------------------------------------

pub struct BraveProvider { pub api_key: String }

#[derive(Deserialize)]
struct BraveResponse {
    #[serde(default)]
    web: Option<BraveWeb>,
}

#[derive(Deserialize)]
struct BraveWeb {
    #[serde(default)]
    results: Vec<BraveResult>,
}

#[derive(Deserialize)]
struct BraveResult {
    #[serde(default)]
    title: String,
    #[serde(default)]
    url: String,
    #[serde(default)]
    description: String,
}

impl WebSearchProvider for BraveProvider {
    fn name(&self) -> &'static str {
        "brave"
    }

    fn search(&self, query: &str, num: usize) -> Result<Vec<SearchResult>> {
        let url = format!("https://api.search.brave.com/res/v1/web/search?q={}&count={}", urlencode(query), num.max(1));
        let resp = ureq::get(&url)
            .set("X-Subscription-Token", &self.api_key)
            .set("Accept", "application/json")
            .timeout(Duration::from_secs(15))
            .call()
            .map_err(|e| FlintError::Internal(format!("brave: {e}")))?;
        let parsed: BraveResponse = resp
            .into_json()
            .map_err(|e| FlintError::Internal(format!("brave json: {e}")))?;
        Ok(parsed
            .web
            .map(|w| w.results)
            .unwrap_or_default()
            .into_iter()
            .take(num)
            .map(|r| SearchResult {
                title: r.title,
                url: r.url.clone(),
                snippet: r.description,
                host: mk_host(&r.url),
                date: String::new(),
            })
            .collect())
    }
}

fn mk_host(url: &str) -> String {
    url.split("//").nth(1).and_then(|r| r.split('/').next()).unwrap_or("").to_string()
}

// ---------------------------------------------------------------------------
// Tavily
// ---------------------------------------------------------------------------

pub struct TavilyProvider { pub api_key: String }

#[derive(Serialize)]
struct TavilyRequest<'a> {
    api_key: &'a str,
    query: &'a str,
    max_results: usize,
}

#[derive(Deserialize)]
struct TavilyResponse {
    #[serde(default)]
    results: Vec<TavilyResult>,
}

#[derive(Deserialize)]
struct TavilyResult {
    #[serde(default)]
    title: String,
    #[serde(default)]
    url: String,
    #[serde(default)]
    content: String,
}

impl WebSearchProvider for TavilyProvider {
    fn name(&self) -> &'static str {
        "tavily"
    }

    fn search(&self, query: &str, num: usize) -> Result<Vec<SearchResult>> {
        let req = TavilyRequest { api_key: &self.api_key, query, max_results: num.max(1) };
        let resp = ureq::post("https://api.tavily.com/search")
            .timeout(Duration::from_secs(20))
            .send_json(serde_json::to_value(req)?)
            .map_err(|e| FlintError::Internal(format!("tavily: {e}")))?;
        let parsed: TavilyResponse = resp
            .into_json()
            .map_err(|e| FlintError::Internal(format!("tavily json: {e}")))?;
        Ok(parsed
            .results
            .into_iter()
            .take(num)
            .map(|r| SearchResult {
                title: r.title,
                url: r.url.clone(),
                snippet: r.content,
                host: mk_host(&r.url),
                date: String::new(),
            })
            .collect())
    }
}

// ---------------------------------------------------------------------------
// Gateway
// ---------------------------------------------------------------------------

pub struct ToolGateway {
    provider: Box<dyn WebSearchProvider>,
    cache: Mutex<HashMap<String, (Vec<SearchResult>, Instant)>>,
    cache_ttl: Duration,
    fetch_max_bytes: usize,
}

impl ToolGateway {
    pub fn new(provider: Box<dyn WebSearchProvider>, cache_ttl: Duration, fetch_max_bytes: usize) -> Self {
        Self { provider, cache: Mutex::new(HashMap::new()), cache_ttl, fetch_max_bytes }
    }

    pub fn from_config(cfg: &flint_core::config::ToolsConfig) -> Self {
        let provider: Box<dyn WebSearchProvider> = match cfg.web_search_provider.as_str() {
            "brave" if cfg.brave_api_key.is_some() => Box::new(BraveProvider {
                api_key: cfg.brave_api_key.clone().unwrap(),
            }),
            "tavily" if cfg.tavily_api_key.is_some() => Box::new(TavilyProvider {
                api_key: cfg.tavily_api_key.clone().unwrap(),
            }),
            _ => Box::new(DuckDuckGoProvider),
        };
        Self::new(provider, Duration::from_secs(cfg.cache_ttl_s), cfg.fetch_max_bytes)
    }

    pub fn provider_name(&self) -> &'static str {
        self.provider.name()
    }

    pub fn web_search(&self, query: &str, num: usize) -> Result<Vec<SearchResult>> {
        let num = num.clamp(1, 20);
        {
            let cache = self.cache.lock().unwrap();
            if let Some((results, at)) = cache.get(query) {
                if at.elapsed() < self.cache_ttl && results.len() >= num {
                    return Ok(results.iter().take(num).cloned().collect());
                }
            }
        }
        let results = self.provider.search(query, num)?;
        self.cache.lock().unwrap().insert(query.to_string(), (results.clone(), Instant::now()));
        flint_core::metrics::counter_inc(
            flint_core::metrics::names::TOOL_CALLS_TOTAL,
            &[("tool", "web_search".into()), ("provider", self.provider.name().into())],
        );
        Ok(results)
    }

    pub fn http_fetch(&self, url: &str) -> Result<FetchResult> {
        if !url.starts_with("http://") && !url.starts_with("https://") {
            return Err(FlintError::InvalidParam { msg: "only http(s) URLs allowed".into() });
        }
        // Block obvious internal targets (SSRF hygiene for the broker).
        if let Some(host) = url.split("//").nth(1).map(|h| h.split(['/', ':']).next().unwrap_or("")) {
            const BLOCKED: [&str; 5] = ["localhost", "127.0.0.1", "0.0.0.0", "169.254.169.254", "metadata"];
            if BLOCKED.contains(&host) || host.starts_with("10.") || host.starts_with("192.168.") {
                return Err(FlintError::Forbidden { msg: format!("host not allowed: {host}") });
            }
        }
        let resp = ureq::get(url)
            .set("User-Agent", "flint/0.1")
            .timeout(Duration::from_secs(20))
            .call()
            .map_err(|e| FlintError::Internal(format!("fetch: {e}")))?;
        let status = resp.status();
        let content_type = resp.header("content-type").unwrap_or("").to_string();
        let mut reader = resp.into_reader();
        let mut body = Vec::new();
        let mut chunk = [0u8; 16 * 1024];
        let mut total: u64 = 0;
        loop {
            use std::io::Read;
            let n = reader.read(&mut chunk).map_err(|e| FlintError::Internal(format!("fetch read: {e}")))?;
            if n == 0 {
                break;
            }
            total += n as u64;
            if total > self.fetch_max_bytes as u64 {
                return Err(FlintError::InvalidParam {
                    msg: format!("response exceeds {} bytes", self.fetch_max_bytes),
                });
            }
            body.extend_from_slice(&chunk[..n]);
        }
        flint_core::metrics::counter_inc(
            flint_core::metrics::names::TOOL_CALLS_TOTAL,
            &[("tool", "http_fetch".into()), ("provider", "direct".into())],
        );
        Ok(FetchResult {
            status,
            content_type,
            body_b64: flint_core::util::b64_encode(&body),
            size_b: total,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ddg_parser_extracts_results() {
        let html = r#"
<table>
<tr><td><a rel="nofollow" href="https://example.com/page" class='result-link'>Example <b>Page</b></a></td></tr>
<tr><td class="result-snippet">The <b>example</b> page snippet &amp; more</td></tr>
<tr><td><a rel="nofollow" href="https://another.org/x" class='result-link'>Another Result</a></td></tr>
<tr><td class="result-snippet">Second snippet</td></tr>
</table>
"#;
        let results = parse_ddg_lite(html, 10);
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].title, "Example Page");
        assert_eq!(results[0].url, "https://example.com/page");
        assert_eq!(results[0].snippet, "The example page snippet & more");
        assert_eq!(results[0].host, "example.com");
    }

    #[test]
    fn url_encoding() {
        assert_eq!(urlencode("rust lang & more"), "rust+lang+%26+more");
    }

    #[test]
    fn fetch_blocks_internal_hosts() {
        let gw = ToolGateway::new(Box::new(DuckDuckGoProvider), Duration::from_secs(60), 1024);
        assert!(gw.http_fetch("http://127.0.0.1:8080/x").is_err());
        assert!(gw.http_fetch("http://169.254.169.254/latest/meta-data").is_err());
        assert!(gw.http_fetch("ftp://example.com/f").is_err());
    }
}
