//! flint-guest-agent: the in-sandbox agent binary.
//!
//! Runs inside every sandbox (microVM in production, child process in
//! dev) and speaks the length-prefixed JSON protocol from
//! `flint_core::agent_proto`. Transports: AF_VSOCK :5252 (production,
//! `--vsock`) and localhost TCP (dev, `serve --port`). Sandbox-absolute
//! paths are mapped under `--home` (which is `/` inside a real VM).
//!
//! Responsibilities (research: E2B envd / CodeSandbox sandblock agent):
//! exec with optional PTY + timeout, background process supervision
//! (subreaper so orphaned grandchildren are reaped), file ops mirrored
//! to a guest journal, env overlay, port tunnels for ingress, and
//! durability barriers.

mod agent;
mod exec;
mod fsops;
mod journal;
mod vsock;

use anyhow::Result;
use clap::Parser;
use std::path::PathBuf;
use std::sync::Arc;

#[derive(Parser, Debug)]
#[command(name = "flint-guest-agent", about = "Flint in-sandbox agent")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(clap::Subcommand, Debug)]
enum Cmd {
    /// Serve the agent protocol over TCP (dev mode).
    Serve {
        /// 0 = ephemeral (prints `READY <port>`).
        #[arg(long, default_value = "0")]
        port: u16,
        #[arg(long)]
        home: PathBuf,
        #[arg(long)]
        sandbox_id: String,
        #[arg(long)]
        token: Option<String>,
    },
    /// Serve over AF_VSOCK (production microVM mode). Also accepts TCP
    /// on --port for tooling.
    ServeVsock {
        #[arg(long, default_value = "5252")]
        vsock_port: u32,
        #[arg(long, default_value = "0")]
        port: u16,
        #[arg(long, default_value = "/")]
        home: PathBuf,
        #[arg(long)]
        sandbox_id: String,
        #[arg(long)]
        token: Option<String>,
    },
}

fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info".into()),
        )
        .with_target(false)
        .init();
    let cli = Cli::parse();
    // Become a subreaper so exec'd orphans are reaped by us (research:
    // PR_SET_CHILD_SUBREAPER in envd / sandblock).
    unsafe {
        libc::prctl(libc::PR_SET_CHILD_SUBREAPER, 1u64, 0, 0, 0);
    }
    let rt = tokio::runtime::Builder::new_multi_thread().enable_all().build()?;
    rt.block_on(async_main(cli))
}

async fn async_main(cli: Cli) -> Result<()> {
    match cli.cmd {
        Cmd::Serve { port, home, sandbox_id, token } => {
            agent::serve_tcp(port, home, sandbox_id, token, None).await
        }
        Cmd::ServeVsock { vsock_port, port, home, sandbox_id, token } => {
            agent::serve_tcp(port, home, sandbox_id, token, Some(vsock_port)).await
        }
    }
}

// Re-export for exec.rs convenience.
pub(crate) fn now_ms() -> i64 {
    flint_core::util::now_ms()
}

pub type Shared<T> = Arc<std::sync::Mutex<T>>;
