# Cloudflare — Sandboxes / Containers / Dynamic Workers (Workers isolates)

## Overview
Cloudflare ships a *spectrum* of isolation behind one umbrella ("Sandboxes on Cloudflare", docs last updated Sep 30 2026): **Workers** (V8 isolates), **Dynamic Workers** (Workers instantiated at runtime for AI-generated JS), and **Containers** (OCI images in Firecracker microVMs), all driven through a single SDK (`@cloudflare/sandbox`, 0.x docs still up with a migration guide). Positioning: your Worker *is* the control plane — "Execute untrusted or generated code in Linux virtual machines or isolated Workers" for "agent-written code, user-uploaded applications, data analysis, development previews, build pipelines". Docs ship agent-first tutorials: a coding-agent runner (clone a repo, run Claude Code in the background, return a diff) and an AI code interpreter over Dynamic Workers.

## Isolation & Architecture
- **Workers / Dynamic Workers**: V8 isolates — language-level isolation, massive multi-tenancy per host, hardened against Spectre-class attacks; Dynamic Workers spin up an unlimited number of Workers *at runtime*, claimed ~100x faster startup and far more memory-efficient than containers. Also the substrate of **Kitesurf**, Cloudflare's agent-first browser written in V8 (not Chromium), where page scripts run as sandboxed "PageScript" Workers behind a `SandboxOutbound` network boundary.
- **Containers**: each instance runs in its own **Firecracker microVM** with its own kernel and network — "no other workload shares it". A **Durable Object (DO)** owns each container: the DO is a globally routable singleton managing routing, persistent state, alarms and lifecycle; the newer `durable_object` scheduling policy co-locates the container right next to its DO. The Oct 2026 "rebuilt to scale agent sandboxes" post: **6x faster starts**, agent chooses image + instance type *at runtime*, and **filesystem snapshots**. Root disks are writable, provisioned from a Linux **device-mapper thin pool** (revealed in InfoQ's Oct 2026 coverage of a cross-tenant exposure fix — a cautionary tale for thin-provision bookkeeping).

## API Surface
`@cloudflare/sandbox` 1.x: `exec()` (streamed output, background processes), Files API (read/write/mkdir + git clone automation), Sessions (independent cwd/env per shell), browser **Terminals** (interactive PTY over WebSocket), "run a server once and reuse it" patterns, ports with public preview URLs, S3/R2 mounts, code interpreter (Python/JS with rich output), `createSandboxTools()` to expose the sandbox to an LLM as tools (cloudflare/agents#1319 tracks hardening it), and an HTTP API bridge for non-Worker callers. Transport subtlety: the default HTTP transport spends one Workers *subrequest* per SDK call (50 free / 1,000 paid); the RPC transport multiplexes everything over one persistent connection.

## Persistence & Lifecycle
Containers sleep after a `sleep_after` idle window; the DO alarm re-wakes them transparently on the next request. **Filesystem snapshots** capture the FS so a later instance (after sleep, restart, or handoff to another DO) starts where the old one left off — implicit 30-day TTL refreshed on each restore, max 20 GB per snapshot. Directory-level backup to R2 is also offered. The "Sandbox lifetime" doc defines exactly what keeps a sandbox running and which files the next instance sees.

## Agent-Specific Features
First-class coding-agent recipes (Claude Code, Codex, OpenCode, Devin, Cursor, OpenAI Agents SDK); credential brokering via **AI Gateway** (sandbox egress may only reach your gateway token, never raw API keys); **Code Mode** (`@cloudflare/codemode`): MCP tools compiled into a TypeScript API the model *writes code against*, executed in a Dynamic Worker; Kitesurf for browser agents; background processes + preview hostnames per port.

## Pricing & Limits
Workers Paid plan required ($5/mo). Billed per **10ms of active runtime**: CPU **$0.000020/vCPU-second** (~$0.072/vCPU-hr; 375 vCPU-min/month included), memory **$0.0000025/GiB-second** (25 GiB-hr included), disk **$0.00000007/GB-second** (200 GB-hr included). Instance types: lite (1/16 vCPU, 256 MiB, 2 GB disk) up to standard-4 (4 vCPU, 12 GiB, 20 GB); custom types capped at 4 vCPU / 12 GiB / 20 GB. Account-level concurrent caps (~1,500 vCPU). Not aimed at 24/7 VM hosting.

## Open-Source & Engineering Notes (URLs)
- github.com/cloudflare/sandbox-sdk — open-source SDK ("a sandbox is a Durable Object and the Container it starts")
- github.com/cloudflare/agents — `packages/shell` (sandboxed JS+fs runtime) and `packages/codemode`
- github.com/cloudflare/workerd — open-source Workers runtime (C++)
- Blogs: blog.cloudflare.com/dynamic-workers ("Sandboxing AI agents, 100x faster"), /kitesurf + /kitesurf-update, /faster-agent-sandboxes
- Docs as markdown: developers.cloudflare.com/sandbox/ + /sandbox/llms.txt (any page via `Accept: text/markdown` header; AI Search API for agents)
- Security: infoq.com/news/2026/10/cloudflare-cross-tenant-exposure (device-mapper thin pool bug)

## Lessons for a Rust implementation
1. **Actor-per-sandbox supervision**: the DO pattern (globally addressable singleton owning a microVM's lifecycle, routing and wake alarms) maps directly to a per-sandbox tokio actor supervising a Firecracker process — the cleanest control-plane design in this survey.
2. **One multiplexed connection beats per-op HTTP** — their subrequest accounting forced an RPC transport; design a single streaming channel (WS/gRPC) for exec/files/events from day one.
3. **Tier isolation to the workload**: isolates for interpreted agent snippets, microVMs for full Linux — behind one API.
4. **Filesystem-only snapshots with TTL+refresh** are a deliberately simple persistence model that avoids memory-snapshot machinery entirely — a legitimate product choice for agent workloads that re-run setup.
5. **Credential brokering at the edge** (gateway-only model access from inside the sandbox) is cheap and highly differentiating.
6. Thin-provisioned root disks need hardened teardown + tests — the 2026 cross-tenant incident shows the failure mode.

Sources: developers.cloudflare.com/sandbox · developers.cloudflare.com/containers/platform/pricing · blog.cloudflare.com/faster-agent-sandboxes · blog.cloudflare.com/dynamic-workers · blog.cloudflare.com/kitesurf · github.com/cloudflare/sandbox-sdk · www.cloudflare.com/products/sandboxes
