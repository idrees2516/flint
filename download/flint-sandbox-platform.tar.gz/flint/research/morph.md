# Morph / Morph Cloud (morph.so, cloud.morph.so; formerly morphvm.io) — Research Report

*Researched: Task R1. Sources: cloud.morph.so/docs (fetched directly), morph.so, sandbox.watch/p/morph, third-party comparisons. Note: distinct from "Morph" the LLM-migration company (morphllm.com) and YC "Morph" (coding models). The AI-sandbox company is **Morph Labs** (CEO Jesse Han), product **Morph Cloud**.*

## Overview

Morph Cloud brands itself **"Infrastructure for AI agents with instant environment branching and burst scalability."** Its core technology, **Infinibranch**, lets you "snapshot, branch, and restore entire computational environments in under 250ms," which the company markets as **"non-linear computing"** — agents can checkpoint a VM, explore many parallel futures from that state, and time-travel between states. Two product layers: **Instances** (raw VM primitives for power users: RL environments, test-time scaling, bespoke orchestration) and **Devboxes** (the recommended user-facing object: programmable cloud dev environments for humans *and* CLI agents — VS Code/Cursor/SSH + tmux automation, preview URLs, live sharing within orgs, "hundreds of parallel replicas or scale to zero"). Target segments: AI coding agents (Claude Code, Codex, Gemini CLI in the cloud), RL rollouts, and parallel testing. Docker-in-Docker is supported inside VMs.

## Isolation & Architecture

- Every sandbox is a **full VM** ("MorphVM") — sandbox.watch: "Full VMs (hypervisor technology not explicitly named in public docs)", though third-party write-ups (forkast.news, spheron) group Morph with Firecracker-microVM platforms; instance IDs are `morphvm_*`. Docs describe snapshots as capturing "memory, processes, and system state" — i.e., **full VM-state snapshots (memory + disk + device state)**, the Firecracker `CreateSnapshot` model (a snapshot can even be taken with HTTP services running, and they continue running when restored).
- Object model (docs /concepts/mental-model): **Images** (reusable base OS filesystems, e.g. `morphvm-minimal`) → **Snapshots** (immutable, bootable copies of an image or of a running instance; define vcpus/memory/disk_size) → **Instances** (running VMs started from a snapshot) → **Branches** (near-instant copies of instance state for parallel futures). Devboxes = templates (base snapshot + build steps + integrations) + running workspaces with tmux/SSH/HTTP exposure layered on top.
- Claimed performance: **<250ms** snapshot/branch/restore and boot; marketing table contrasts with "traditional VMs: 2–3 min startup, full clones, no native branching." Blog: "Infinibranch is a new distributed cloud computer runtime… <250ms startup times."
- **Layered snapshot builds**: `Snapshot.build()` uses Infinibranch snapshots as a **layered build cache like Docker layers** — run setup steps once, each step cached as a snapshot layer, rebuilds only re-run changed steps, fast rollbacks; this is their answer to E2B/Daytona "templates."

## API Surface

- **REST API** (`cloud.morph.so/api`, `MORPH_API_KEY` bearer auth) with endpoints including: `POST /instance` (start from snapshot), `GET /instance/{id}`, `DELETE /instance/{id}` (stop), `POST /instance/{id}/pause|resume|reboot|exec|exec-sse|branch|snapshot|ssh-key|wake-on|ttl|metadata|metrics`, `POST /snapshot` (create from image), `POST /snapshot/{id}/boot` (boot instance), `POST /snapshot/{id}/token` (shareable snapshot tokens), `POST /image/{id}/boot`, secrets CRUD, organizations/members/invites, API keys, user credits/usage/quota, promo codes. Full auto-generated API reference in docs.
- **SDKs**: Python (`pip install morphcloud`, 3.10+), TypeScript/JS, and a CLI (`morphcloud ...`) that mirrors the SDK. Devbox service has its own REST surface (`devbox.svc.cloud.morph.so`).
- Execution model: `instance.exec("cmd")` returns stdout/stderr; **`exec-sse` endpoint streams command output over SSE**; background processes via plain `nohup` inside the VM (processes survive because the VM is persistent, and survive snapshots too). File transfer over SSH/SFTP or CLI copy. SSH access via **user-managed SSH public keys** (upload your own `.pub` keys; per-instance generated credentials; browser terminal as a separate access path; key rotation endpoint). HTTP services: `expose_http_service(name, port, auth_mode=none|api_key)` → public `*.morphcloud.io` URL; reverse tunnel support (`ssh -R` from laptop through the VM to get a public URL for localhost).

## Persistence & Lifecycle

- **Snapshot = checkpoint**: immutable point-in-time copy of memory+disk; starting instances from it is cheap and repeatable. Snapshots have **TTLs** (`update snapshot TTL`) so stored state can expire; metadata attachable.
- **Pause/resume**: pause suspends the VM preserving memory state — "effectively the same as if you had snapshotted the instance": creates a new snapshot and suspends the VM; compute (MCU) billing stops, only snapshot storage billed. Resume restores exact state.
- **Stop**: full termination, all resources released; state only lives on in any snapshots taken.
- **Instance TTL**: `ttl_seconds` + **`ttl_action` ∈ {stop, pause}** at start; updatable while running (`set_ttl`); TTL info queryable (`ttl_expire_at`, remaining seconds). Devboxes add **auto-sleep** (disable to make a devbox a persistent VPS).
- **Wake-on-request**: per-instance flags `wake_on_http` and `wake_on_ssh` — a paused instance **auto-resumes on inbound HTTP or SSH/exec traffic** (exec uses the SSH wake path; there is no separate wake_on_exec). This is Morph's transparent auto-resume analogue.
- **Branching**: `instance.branch(count=N)` snapshots the live instance and launches N clones from it — checkpoints-and-fans-out in one call; branches of branches allowed. The marketing name for the whole pattern ("checkpoint and fork": instance → snapshot → branch).
- Crash/limits: no documented fixed max runtime; TTLs control stop/pause. Free while idle (paused = no compute billing).

## Agent-Specific Features

- **Agent tokens** (devboxes): least-privilege, scope-bounded tokens (`devbox:summary:read`, `devbox:http:write`, `devbox:snapshot:write`, `devbox:secrets:read|write`, `devbox:notifications:write`) minted via `POST /api/devboxes/{id}/agent-token`, bound to one devbox + user + org, optionally with a `purpose` string for audit. Lets an agent running *inside* a devbox manage that devbox (expose services, snapshot itself, read secrets) **without holding the account-wide API key**. Some agent environments auto-inject a pre-scoped `DEVBOX_AGENT_TOKEN`.
- tmux integration for CLI agents; VS Code/Cursor one-click; browser-based remote desktop; shareable live devbox URLs in-org; **secrets** service (user/org-scoped); **service delegation tokens**; auto-scale-to-zero agent workspaces (example pattern); GitHub Actions CI on Morph; configurable reboot resize (scale up/down); FUSE mountable inside MorphVMs; EFS (elastic filesystem) mounts; **Responses Proxy** (a Claude Code / BYOS LLM-proxy product line); "Morph Actions" onboarding API for headless repo automation.
- Deep-link URLs into specific devboxes/states for collaboration.

## Pricing & Limits

Measured in **Morph Compute Units (MCU)**: **1 MCU = 1 vCPU-hr + 4 GB RAM-hr + 16 GB disk-hr, OR 5 TB snapshot-hours**; standard rate **$0.05/MCU-hr** (third parties: hourly MCUs = max(vCPU, ceil(RAM/4GiB))); billed only while running — **free while paused/idle** (storage charges for snapshots still apply). Plans: Developer $0/mo (buy MCUs), Team $40/mo w/ 1000 MCUs, Scale $250/mo w/ 7500 MCUs; subscribe page lists runner sizes billed hourly from MCU balance ("~30–45% below industry alternatives" claim); small runner = 3 MCU/hr. No GPU instances. Snapshot TTL controls storage lifecycle.

## Open-Source & Engineering Notes

- Docs (cloud.morph.so/docs) include full REST API reference, changelog, and many end-to-end examples: https://cloud.morph.so/docs/developers, /concepts/mental-model, /documentation/instances/* (pause-resume, ttl, wake-on, branch, http-services, reverse-tunnel, fuse, ssh-sharing), /examples/snapshot-build-caching, /examples/auto-scale-agent-workspaces, /devboxes/agent-tokens.
- Blog: https://morph.so/blog (Infinibranch: The Dawn of Non-Linear Computing; "Infrastructure for the Singularity" — Jesse Han talks). SDK repos are published to PyPI/npm (`morphcloud`); no major open-source infrastructure repo (unlike E2B/Daytona).
- Independent profile with cited facts: https://sandbox.watch/p/morph (verified 2026-10-06).

## Lessons for a Rust Implementation

1. **Make branch a first-class primitive** — `branch(count=N)` as a single API call (checkpoint + fan-out) is simpler for agents than separate snapshot + N× boot calls; branches-of-branches enable tree search / RL rollouts naturally.
2. **Immutable snapshots as content-addressed, TTL'd objects** decouple "state" from "compute": pause ≈ snapshot + suspend (one mechanism, two uses); billing = compute while running, storage while snapshotted — a clean economic model to replicate.
3. **TTL with a configurable expiry action (`stop` vs `pause`)** is a better default than a single hard timeout: pause preserves state cheaply; stop frees everything.
4. **Wake-on flags per channel (HTTP / SSH)** — auto-resume should be opt-in per ingress path, not global.
5. **Scoped, per-sandbox agent tokens** (least-privilege, purpose-tagged, bound to one sandbox) are the right security model for agent self-management — much safer than embedding account keys inside VMs.
6. **SSE for exec streaming** (`exec` vs `exec-sse`) is a pragmatic alternative to WebSockets through the control plane.
7. **User-managed SSH keys** (bring your own pubkeys + per-instance generated creds + rotation) simplify human/agent access without long-lived passwords.

**Most differentiating idea:** **Infinibranch — snapshot/branch/restore of full VM state (memory + processes + disk) in <250ms as the platform's central primitive**, turning agent execution into "non-linear computing" (checkpoint, branch into parallel futures, resume any of them).
