//! Flint Rust example: build AI-generated Rust code *inside* a sandbox
//! (exec-any) and run it. Run with:
//!
//! ```sh
//! export FLINT_URL=http://127.0.0.1:8080 FLINT_API_KEY=...
//! cargo run -p flint-cli -- exec <id> "rustc --version"
//! ```
//!
//! Or as a standalone program against the REST API (ureq):

use serde_json::{json, Value};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let base = std::env::var("FLINT_URL").unwrap_or_else(|_| "http://127.0.0.1:8080".into());
    let key = std::env::var("FLINT_API_KEY")?;

    let call = |method: &str, path: &str, body: Option<Value>| -> Result<Value, Box<dyn std::error::Error>> {
        let req = ureq::request(method, &format!("{base}{path}"))
            .set("Authorization", &format!("Bearer {key}"));
        let resp = match body {
            Some(b) => req.send_json(b)?,
            None => req.call()?,
        };
        Ok(resp.into_json()?)
    };

    // 1. Sandbox.
    let sbx = call("POST", "/v1/sandboxes", Some(json!({ "vm": { "vcpu_count": 4, "mem_mib": 4096 } })))?;
    let id = sbx["id"].as_str().unwrap().to_string();
    println!("sandbox: {id}");

    let exec = |cmd: &str| -> Result<(i64, String), Box<dyn std::error::Error>> {
        let r = call(
            "POST",
            &format!("/v1/sandboxes/{id}/exec"),
            Some(json!({ "spec": { "cmd": ["sh", "-c", cmd], "timeout_ms": 120000 } })),
        )?;
        Ok((r["exit_code"].as_i64().unwrap_or(-1), r["stdout"].as_str().unwrap_or("").to_string()))
    };

    let result: Result<(), Box<dyn std::error::Error>> = (|| {
        // 2. Write a Rust program (journaled, replayable).
        let src = r#"fn main() { println!("flint runs rust, in rust"); }"#;
        let _ = ureq::put(&format!("{base}/v1/sandboxes/{id}/files?path=/app/main.rs"))
            .set("Authorization", &format!("Bearer {key}"))
            .send_bytes(src.as_bytes())?;

        // 3. Compile and run (requires rustc in the sandbox image).
        match exec("rustc -O /app/main.rs -o /app/main 2>&1 && /app/main") {
            Ok((0, out)) => println!("{}", out.trim()),
            Ok((code, out)) => println!("rustc/build failed ({code}):\n{out}"),
            Err(e) => return Err(e),
        }
        Ok(())
    })();

    let _ = call("DELETE", &format!("/v1/sandboxes/{id}"), None);
    result?;
    println!("cleaned up");
    Ok(())
}
