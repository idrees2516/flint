//! Agent server: TCP (dev) + AF_VSOCK (prod) transports, frame dispatch,
//! exec/PTY/process/fs/terminal/tunnel handlers.

use crate::exec::{self, ProcHandle, ProcStatus, ProcTable};
use crate::fsops::FsCtx;
use crate::journal::GuestJournal;
use crate::vsock::{vsock_accept, vsock_listen, VsockStream};
use flint_core::agent_proto::{self, WireMsg};
use flint_core::{ExecSpec, PtySize};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::os::fd::AsRawFd;
use std::os::unix::process::ExitStatusExt;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::sync::mpsc;

const MAX_OUTPUT_PER_STREAM: usize = 8 * 1024 * 1024;
const MAX_READ_BYTES: usize = 8 * 1024 * 1024;

pub struct AppState {
    pub sandbox_id: String,
    pub token: Option<String>,
    pub fs: FsCtx,
    pub env: Mutex<HashMap<String, String>>,
    pub procs: ProcTable,
    pub restartable: Mutex<Vec<ExecSpec>>,
}

/// Messages routed into open streams (terminals, tunnels).
#[derive(Debug)]
pub enum PushMsg {
    Data(Vec<u8>),
    Resize { cols: u16, rows: u16 },
    Close,
}

struct Conn {
    out: mpsc::Sender<WireMsg>,
    streams: Mutex<HashMap<u64, mpsc::Sender<PushMsg>>>,
}

impl Conn {
    async fn send(&self, msg: WireMsg) {
        let _ = self.out.send(msg).await;
    }
}

/// Entry: bind TCP (and optionally vsock), print READY, serve forever.
pub async fn serve_tcp(
    port: u16,
    home: PathBuf,
    sandbox_id: String,
    token: Option<String>,
    vsock_port: Option<u32>,
) -> anyhow::Result<()> {
    let journal = GuestJournal::open(&home);
    let state = Arc::new(AppState {
        sandbox_id: sandbox_id.clone(),
        token: token.clone(),
        fs: FsCtx::new(home.clone(), journal),
        env: Mutex::new(HashMap::new()),
        procs: ProcTable::default(),
        restartable: Mutex::new(Vec::new()),
    });

    let listener = if port == 0 {
        tokio::net::TcpListener::bind(("127.0.0.1", 0)).await?
    } else {
        tokio::net::TcpListener::bind(("0.0.0.0", port)).await?
    };
    let bound = listener.local_addr()?;
    // Contract with the ProcessDriver: first stdout line is READY <port>.
    println!("READY {}", bound.port());
    tracing::info!(port = bound.port(), sandbox = %sandbox_id, home = %home.display(), "flint-guest-agent serving");

    // Optional vsock listener (production).
    if let Some(vp) = vsock_port {
        match vsock_listen(vp) {
            Ok(fd) => {
                let state = state.clone();
                tokio::spawn(async move {
                    loop {
                        match vsock_accept(fd).await {
                            Ok(stream) => {
                                let state = state.clone();
                                tokio::spawn(handle_conn(stream, state));
                            }
                            Err(e) => {
                                tracing::error!(error = %e, "vsock accept failed; retrying in 1s");
                                tokio::time::sleep(std::time::Duration::from_secs(1)).await;
                            }
                        }
                    }
                });
            }
            Err(e) => {
                tracing::warn!(error = %e, "vsock unavailable (dev mode?) — TCP only");
            }
        }
    }

    loop {
        let (stream, _peer) = listener.accept().await?;
        let state = state.clone();
        tokio::spawn(handle_conn(stream, state));
    }
}

/// Serve one connection over any async duplex stream.
pub async fn handle_conn<S>(mut stream: S, state: Arc<AppState>)
where
    S: AsyncRead + AsyncWrite + Unpin + Send + 'static,
{
    let (out_tx, mut out_rx) = mpsc::channel::<WireMsg>(512);
    let conn = Arc::new(Conn { out: out_tx, streams: Mutex::new(HashMap::new()) });

    let mut decoder = agent_proto::FrameDecoder::default();
    let mut tmp = [0u8; 16384];
    loop {
        tokio::select! {
            out = out_rx.recv() => {
                match out {
                    Some(msg) => {
                        let mut buf = Vec::new();
                        agent_proto::encode(&msg, &mut buf);
                        if stream.write_all(&buf).await.is_err() {
                            break;
                        }
                    }
                    None => break,
                }
            }
            n = stream.read(&mut tmp) => {
                match n {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        decoder.feed(&tmp[..n]);
                        while let Some(msg) = decoder.next() {
                            match msg {
                                WireMsg::Req { id, method, params } => {
                                    let conn = conn.clone();
                                    let state = state.clone();
                                    tokio::spawn(async move {
                                        dispatch(&conn, &state, id, &method, params).await;
                                    });
                                }
                                WireMsg::Push { id, kind, data } => route_push(&conn, id, &kind, data),
                                WireMsg::Resp { .. } | WireMsg::Ev { .. } => {
                                    tracing::debug!("agent: unexpected inbound Resp/Ev (ignored)");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn route_push(conn: &Arc<Conn>, id: u64, kind: &str, data: Value) {
    let sender = conn.streams.lock().unwrap().get(&id).cloned();
    let Some(tx) = sender else { return };
    let msg = match kind {
        "term.input" | "port.data" | "proc.input" => {
            let b64 = data.get("data_b64").and_then(|v| v.as_str()).unwrap_or("");
            let bytes = flint_core::util::b64_decode(b64).unwrap_or_default();
            PushMsg::Data(bytes)
        }
        "term.resize" => PushMsg::Resize {
            cols: data.get("cols").and_then(|v| v.as_u64()).unwrap_or(80) as u16,
            rows: data.get("rows").and_then(|v| v.as_u64()).unwrap_or(24) as u16,
        },
        "term.close" | "port.close" => PushMsg::Close,
        _ => return,
    };
    let _ = tx.try_send(msg);
}

async fn dispatch(conn: &Arc<Conn>, state: &Arc<AppState>, id: u64, method: &str, params: Value) {
    use flint_core::agent_proto::methods as M;
    tracing::debug!(id, method, "agent dispatch");
    match method {
        M::PING => conn.send(ok_resp(id, json!({ "pong": true }))).await,
        M::VERSION => conn
            .send(ok_resp(id, json!({ "version": agent_proto::PROTOCOL_VERSION, "sandbox_id": state.sandbox_id })))
            .await,
        M::BARRIER => {
            let seq = state.fs.journal.barrier();
            conn.send(ok_resp(id, json!({ "journal_seq": seq }))).await;
        }
        M::JOURNAL_STATUS => {
            conn.send(ok_resp(id, json!({ "journal_seq": state.fs.journal.seq(), "path": state.fs.journal.path().display().to_string() }))).await;
        }
        M::EXEC => run_exec(conn, state, id, params).await,
        M::PROCESS_SPAWN => spawn_process(conn, state, id, params).await,
        M::PROCESS_LIST => {
            let procs: Vec<Value> = state
                .procs
                .list()
                .into_iter()
                .map(|p| {
                    json!({
                        "proc_id": p.proc_id,
                        "cmd": p.spec.cmd,
                        "status": match *p.status.lock().unwrap() { ProcStatus::Running => "running", ProcStatus::Exited => "exited", ProcStatus::Failed => "failed" },
                        "exit_code": *p.exit_code.lock().unwrap(),
                        "started_at_ms": p.started_at_ms,
                    })
                })
                .collect();
            conn.send(ok_resp(id, json!({ "processes": procs }))).await;
        }
        M::PROCESS_KILL => {
            let pid = params.get("proc_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let ok = state.procs.kill(&pid, 9);
            state.fs.journal.append(
                &format!("kill_{}", pid),
                &flint_journal::ops::Op::ProcessKill { proc_id: pid, signal: 9 },
            );
            conn.send(ok_resp(id, json!({ "killed": ok }))).await;
        }
        M::PROCESS_SIGNAL => {
            let pid = params.get("proc_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let sig = params.get("signal").and_then(|v| v.as_i64()).unwrap_or(15) as i32;
            let ok = state.procs.kill(&pid, sig);
            conn.send(ok_resp(id, json!({ "ok": ok }))).await;
        }
        M::PROCESS_INPUT => {
            let pid = params.get("proc_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let close = params.get("close_stdin").and_then(|v| v.as_bool()).unwrap_or(false);
            if let Some(p) = state.procs.get(&pid) {
                if let Some(tx) = &p.stdin_tx {
                    if close {
                        // Dropping is handled by sending an empty write +
                        // closing via the writer task when it sees the
                        // sender dropped; here we just try to flush EOF by
                        // sending empty (writer treats empty as EOF).
                        let _ = tx.send(Vec::new()).await;
                    } else {
                        let b64 = params.get("data_b64").and_then(|v| v.as_str()).unwrap_or("");
                        let bytes = flint_core::util::b64_decode(b64).unwrap_or_default();
                        let _ = tx.send(bytes).await;
                    }
                    conn.send(ok_resp(id, json!({ "ok": true }))).await;
                    return;
                }
            }
            conn.send(err_resp(id, "process not found or stdin closed")).await;
        }
        M::PROCESS_WAIT => {
            let pid = params.get("proc_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let timeout = std::time::Duration::from_millis(params.get("timeout_ms").and_then(|v| v.as_u64()).unwrap_or(30_000).min(120_000));
            let deadline = tokio::time::Instant::now() + timeout;
            loop {
                if let Some(p) = state.procs.get(&pid) {
                    let status = p.status.lock().unwrap().clone();
                    if status != ProcStatus::Running {
                        conn.send(ok_resp(id, json!({ "status": serde_json::to_value(&status).unwrap_or_default().as_str().unwrap_or("exited"), "exit_code": *p.exit_code.lock().unwrap() }))).await;
                        return;
                    }
                } else {
                    conn.send(err_resp(id, "process not found")).await;
                    return;
                }
                if tokio::time::Instant::now() >= deadline {
                    conn.send(ok_resp(id, json!({ "status": "running", "exit_code": Value::Null }))).await;
                    return;
                }
                tokio::time::sleep(std::time::Duration::from_millis(100)).await;
            }
        }
        M::FS_WRITE => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let mode = params.get("mode").and_then(|v| v.as_u64()).map(|m| m as u32);
            let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let content = params
                .get("content_b64")
                .and_then(|v| v.as_str())
                .and_then(|s| flint_core::util::b64_decode(s).ok())
                .unwrap_or_default();
            match state.fs.write(&path, &content, mode, &op_id) {
                Ok(()) => conn.send(ok_resp(id, json!({ "ok": true, "op_id": op_id }))).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_READ => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("");
            let max = params.get("max_bytes").and_then(|v| v.as_u64()).unwrap_or(MAX_READ_BYTES as u64) as usize;
            match state.fs.read(path, max) {
                Ok((data, mode)) => conn
                    .send(ok_resp(id, json!({ "content_b64": flint_core::util::b64_encode(&data), "size_b": data.len(), "mode": mode })))
                    .await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_LIST => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("/");
            match state.fs.list(path) {
                Ok(entries) => conn.send(ok_resp(id, json!({ "entries": entries }))).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_MKDIR => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let recursive = params.get("recursive").and_then(|v| v.as_bool()).unwrap_or(false);
            let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            match state.fs.mkdir(&path, recursive, &op_id) {
                Ok(()) => conn.send(ok_resp(id, json!({ "ok": true }))).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_REMOVE => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let recursive = params.get("recursive").and_then(|v| v.as_bool()).unwrap_or(false);
            let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            match state.fs.remove(&path, recursive, &op_id) {
                Ok(()) => conn.send(ok_resp(id, json!({ "ok": true }))).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_MOVE => {
            let from = params.get("from").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let to = params.get("to").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
            match state.fs.mv(&from, &to, &op_id) {
                Ok(()) => conn.send(ok_resp(id, json!({ "ok": true }))).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::FS_STAT => {
            let path = params.get("path").and_then(|v| v.as_str()).unwrap_or("");
            match state.fs.stat(path) {
                Ok(v) => conn.send(ok_resp(id, v)).await,
                Err(e) => conn.send(err_resp(id, &e.to_string())).await,
            }
        }
        M::ENV_SET => {
            let key = params.get("key").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let value = params.get("value").and_then(|v| v.as_str()).unwrap_or("").to_string();
            state.env.lock().unwrap().insert(key.clone(), value.clone());
            state.fs.journal.append(&format!("env_{key}"), &flint_journal::ops::Op::EnvSet { key, value });
            conn.send(ok_resp(id, json!({ "ok": true }))).await;
        }
        M::ENV_GET => {
            let key = params.get("key").and_then(|v| v.as_str()).unwrap_or("");
            let v = state.env.lock().unwrap().get(key).cloned();
            conn.send(ok_resp(id, json!({ "key": key, "value": v }))).await;
        }
        M::TERM_OPEN => open_terminal(conn, state, id, params).await,
        M::PORT_CONNECT => open_tunnel(conn, id, params).await,
        M::TOOLS_INVOKE => {
            conn.send(err_resp(id, "tools are invoked through the platform API (worker brokers them); the sandbox agent does not egress")).await;
        }
        M::SHUTDOWN => {
            let tok_ok = match (&state.token, params.get("token").and_then(|v| v.as_str())) {
                (Some(expect), Some(got)) => expect == got,
                (None, _) => true,
                _ => false,
            };
            if tok_ok {
                conn.send(ok_resp(id, json!({ "ok": true }))).await;
                std::process::exit(0);
            } else {
                conn.send(err_resp(id, "bad token")).await;
            }
        }
        other => {
            let _ = other;
            conn.send(err_resp(id, &format!("unknown method: {method}"))).await;
        }
    }
}

fn ok_resp(id: u64, result: Value) -> WireMsg {
    WireMsg::Resp { id, ok: true, result, error: None }
}

fn err_resp(id: u64, msg: &str) -> WireMsg {
    WireMsg::Resp { id, ok: false, result: Value::Null, error: Some(msg.to_string()) }
}

// ---------------------------------------------------------------------------
// exec (streaming)
// ---------------------------------------------------------------------------

fn parse_spec(params: &Value) -> Result<ExecSpec, String> {
    let spec = params.get("spec").cloned().unwrap_or_else(|| params.clone());
    serde_json::from_value(spec).map_err(|e| format!("bad exec spec: {e}"))
}

async fn run_exec(conn: &Arc<Conn>, state: &Arc<AppState>, id: u64, params: Value) {
    let spec = match parse_spec(&params) {
        Ok(s) => s,
        Err(e) => {
            conn.send(err_resp(id, &e)).await;
            return;
        }
    };
    let op_id = params.get("op_id").and_then(|v| v.as_str()).unwrap_or("").to_string();
    state.fs.journal.append(
        &format!("exec_{op_id}"),
        &flint_journal::ops::Op::Exec { spec: spec.clone() },
    );

    if spec.pty.is_some() {
        run_pty(conn, state, id, spec, None).await;
        return;
    }

    let env_overlay = state.env.lock().unwrap().clone();
    let (mut cmd, mut child) = match exec::spawn_pipes(&spec, &env_overlay, &state.fs.home) {
        Ok(pair) => pair,
        Err(e) => {
            conn.send(err_resp(id, &e)).await;
            return;
        }
    };
    let _ = &mut cmd;
    let pid = child.id().map(|p| p as i32).unwrap_or(-1);
    let proc_id = exec::next_proc_id();
    let (stdin_tx, mut stdin_rx) = mpsc::channel::<Vec<u8>>(64);
    let handle = ProcHandle {
        proc_id: proc_id.clone(),
        spec: spec.clone(),
        pid: Some(pid),
        started_at_ms: crate::now_ms(),
        status: Arc::new(Mutex::new(ProcStatus::Running)),
        exit_code: Arc::new(Mutex::new(None)),
        stdin_tx: Some(stdin_tx),
    };
    state.procs.insert(handle.clone());

    if let Some(out) = child.stdout.take() {
        let conn_out = conn.out.clone();
        tokio::spawn(exec::pump_reader(out, id, "stdout", conn_out, MAX_OUTPUT_PER_STREAM));
    }
    if let Some(err) = child.stderr.take() {
        let conn_err = conn.out.clone();
        tokio::spawn(exec::pump_reader(err, id, "stderr", conn_err, MAX_OUTPUT_PER_STREAM));
    }
    if let Some(mut si) = child.stdin.take() {
        tokio::spawn(async move {
            while let Some(data) = stdin_rx.recv().await {
                if data.is_empty() {
                    break; // EOF request
                }
                if si.write_all(&data).await.is_err() {
                    break;
                }
            }
            // Dropping si closes stdin.
        });
    }

    let timeout = spec.timeout_ms.map(std::time::Duration::from_millis);
    let (exit_code, signal, timed_out) = tokio::select! {
        status = child.wait() => {
            match status {
                Ok(st) => {
                    let code = st.code().unwrap_or(-1);
                    let sig = st.signal();
                    (code, sig, false)
                }
                Err(_) => (-1, None, false),
            }
        }
        _ = async {
            match timeout {
                Some(t) => tokio::time::sleep(t).await,
                None => std::future::pending::<()>().await,
            }
        } => {
            exec::kill_tree(pid, nix::sys::signal::Signal::SIGKILL);
            let st = child.wait().await.ok();
            (st.as_ref().and_then(|s| s.code()).unwrap_or(-1), st.as_ref().and_then(|s| s.signal()), true)
        }
    };

    *handle.status.lock().unwrap() = ProcStatus::Exited;
    *handle.exit_code.lock().unwrap() = Some(exit_code);
    state.procs.remove(&proc_id);

    conn.send(exec::exit_event(id, exit_code, signal, timed_out)).await;
    conn.send(ok_resp(id, json!({ "exit_code": exit_code, "timed_out": timed_out }))).await;
}

async fn spawn_process(conn: &Arc<Conn>, state: &Arc<AppState>, id: u64, params: Value) {
    let mut spec = match parse_spec(&params) {
        Ok(s) => s,
        Err(e) => {
            conn.send(err_resp(id, &e)).await;
            return;
        }
    };
    spec.pty = None; // background processes are non-interactive
    let proc_id = exec::next_proc_id();
    if spec.restartable {
        state.restartable.lock().unwrap().push(spec.clone());
    }
    state.fs.journal.append(
        &format!("spawn_{proc_id}"),
        &flint_journal::ops::Op::ProcessSpawn { spec: spec.clone(), proc_id: proc_id.clone() },
    );

    let env_overlay = state.env.lock().unwrap().clone();
    let (_cmd, mut child) = match exec::spawn_pipes(&spec, &env_overlay, &state.fs.home) {
        Ok(pair) => pair,
        Err(e) => {
            conn.send(err_resp(id, &e)).await;
            return;
        }
    };
    let pid = child.id().map(|p| p as i32).unwrap_or(-1);
    let (stdin_tx, stdin_rx) = mpsc::channel::<Vec<u8>>(64);
    let handle = ProcHandle {
        proc_id: proc_id.clone(),
        spec,
        pid: Some(pid),
        started_at_ms: crate::now_ms(),
        status: Arc::new(Mutex::new(ProcStatus::Running)),
        exit_code: Arc::new(Mutex::new(None)),
        stdin_tx: Some(stdin_tx),
    };
    state.procs.insert(handle.clone());

    // Drain output (background processes: keep pipes from filling, no
    // event streaming unless a stream id is attached).
    if let Some(out) = child.stdout.take() {
        tokio::spawn(async move {
            let mut buf = [0u8; 8192];
            let mut r = out;
            while matches!(r.read(&mut buf).await, Ok(n) if n > 0) {}
        });
    }
    if let Some(err) = child.stderr.take() {
        tokio::spawn(async move {
            let mut buf = [0u8; 8192];
            let mut r = err;
            while matches!(r.read(&mut buf).await, Ok(n) if n > 0) {}
        });
    }
    if let Some(mut si) = child.stdin.take() {
        let mut rx = stdin_rx;
        tokio::spawn(async move {
            while let Some(data) = rx.recv().await {
                if data.is_empty() || si.write_all(&data).await.is_err() {
                    break;
                }
            }
        });
    }

    tokio::spawn(async move {
        if let Ok(st) = child.wait().await {
            *handle.status.lock().unwrap() = ProcStatus::Exited;
            *handle.exit_code.lock().unwrap() = Some(st.code().unwrap_or(-1));
        }
    });

    conn.send(ok_resp(id, json!({ "proc_id": proc_id }))).await;
}

// ---------------------------------------------------------------------------
// terminals (PTY)
// ---------------------------------------------------------------------------

async fn open_terminal(conn: &Arc<Conn>, state: &Arc<AppState>, id: u64, params: Value) {
    let mut spec: ExecSpec = match params.get("spec") {
        Some(s) => match serde_json::from_value(s.clone()) {
            Ok(v) => v,
            Err(e) => {
                conn.send(err_resp(id, &format!("bad spec: {e}"))).await;
                return;
            }
        },
        None => ExecSpec::shell("bash -l 2>/dev/null || sh -l"),
    };
    if spec.cmd.is_empty() {
        spec = ExecSpec::shell("bash -l 2>/dev/null || sh -l");
    }
    let size: PtySize = params
        .get("size")
        .and_then(|s| serde_json::from_value(s.clone()).ok())
        .unwrap_or_default();
    spec.pty = Some(size);

    run_pty(conn, state, id, spec, Some(size)).await;
}

async fn run_pty(
    conn: &Arc<Conn>,
    state: &Arc<AppState>,
    id: u64,
    spec: ExecSpec,
    size: Option<PtySize>,
) {
    let size = size.or(spec.pty).unwrap_or_default();
    let env_overlay = state.env.lock().unwrap().clone();
    let (mut child, master, _slave) = match exec::spawn_pty(&spec, &env_overlay, &state.fs.home, &size) {
        Ok(t) => t,
        Err(e) => {
            conn.send(err_resp(id, &e)).await;
            return;
        }
    };
    let pid = child.id().map(|p| p as i32).unwrap_or(-1);
    let proc_id = exec::next_proc_id();
    let (status, exit_code) = (Arc::new(Mutex::new(ProcStatus::Running)), Arc::new(Mutex::new(None::<i32>)));
    state.procs.insert(ProcHandle {
        proc_id: proc_id.clone(),
        spec: spec.clone(),
        pid: Some(pid),
        started_at_ms: crate::now_ms(),
        status: status.clone(),
        exit_code: exit_code.clone(),
        stdin_tx: None,
    });

    // Master fd stream: shared via clone (reader task + writer router).
    let master_stream = match VsockStream::from_raw(master.as_raw_fd()) {
        Ok(s) => s,
        Err(e) => {
            conn.send(err_resp(id, &format!("fd stream: {e}"))).await;
            return;
        }
    };
    let master_wr = master_stream.try_clone();

    // Output pump → Ev term.out events.
    {
        let conn_out = conn.out.clone();
        let mut stream = master_stream;
        tokio::spawn(async move {
            let mut buf = [0u8; 8192];
            loop {
                match stream.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        let _ = conn_out
                            .send(WireMsg::Ev {
                                id,
                                seq: 0,
                                kind: flint_core::agent_proto::events::TERM_OUT.into(),
                                data: json!({ "data_b64": flint_core::util::b64_encode(&buf[..n]) }),
                            })
                            .await;
                    }
                }
            }
        });
    }

    // Push router (input / resize / close).
    let (push_tx, mut push_rx) = mpsc::channel::<PushMsg>(128);
    conn.streams.lock().unwrap().insert(id, push_tx);
    {
        let pid_copy = pid;
        tokio::spawn(async move {
            let mut master = master_wr;
            while let Some(msg) = push_rx.recv().await {
                match msg {
                    PushMsg::Data(bytes) => {
                        if !bytes.is_empty() {
                            let _ = master.write_all(&bytes).await;
                        }
                    }
                    PushMsg::Resize { cols, rows } => {
                        let ws = nix::pty::Winsize { ws_row: rows, ws_col: cols, ws_xpixel: 0, ws_ypixel: 0 };
                        unsafe {
                            libc::ioctl(master.raw_fd(), 0x5413 /* TIOCSWINSZ */, &ws);
                        }
                    }
                    PushMsg::Close => {
                        exec::kill_tree(pid_copy, nix::sys::signal::Signal::SIGHUP);
                        break;
                    }
                }
            }
        });
    }

    // Wait for exit → final Resp.
    {
        let conn = conn.clone();
        let state = state.clone();
        tokio::spawn(async move {
            let code = match child.wait().await {
                Ok(st) => st.code().unwrap_or(-1),
                Err(_) => -1,
            };
            *status.lock().unwrap() = ProcStatus::Exited;
            *exit_code.lock().unwrap() = Some(code);
            conn.streams.lock().unwrap().remove(&id);
            state.procs.remove(&proc_id);
            conn.send(exec::exit_event(id, code, None, false)).await;
            conn.send(ok_resp(id, json!({ "exit_code": code, "timed_out": false }))).await;
        });
    }
}

// ---------------------------------------------------------------------------
// port tunnels (ingress)
// ---------------------------------------------------------------------------

async fn open_tunnel(conn: &Arc<Conn>, id: u64, params: Value) {
    let port = params.get("port").and_then(|v| v.as_u64()).unwrap_or(80) as u16;
    let tcp = match tokio::net::TcpStream::connect(("127.0.0.1", port)).await {
        Ok(s) => s,
        Err(e) => {
            conn.send(err_resp(id, &format!("connect 127.0.0.1:{port}: {e}"))).await;
            return;
        }
    };
    let (mut rd, mut wr) = tcp.into_split();

    let (push_tx, mut push_rx) = mpsc::channel::<PushMsg>(256);
    conn.streams.lock().unwrap().insert(id, push_tx);

    // Sandbox → host bytes.
    {
        let conn_out = conn.out.clone();
        tokio::spawn(async move {
            let mut buf = [0u8; 8192];
            loop {
                match rd.read(&mut buf).await {
                    Ok(0) | Err(_) => break,
                    Ok(n) => {
                        let _ = conn_out
                            .send(WireMsg::Ev {
                                id,
                                seq: 0,
                                kind: flint_core::agent_proto::events::PORT_DATA.into(),
                                data: json!({ "data_b64": flint_core::util::b64_encode(&buf[..n]) }),
                            })
                            .await;
                    }
                }
            }
            let _ = conn_out
                .send(WireMsg::Resp { id, ok: true, result: json!({ "closed": true }), error: None })
                .await;
        });
    }

    // Host → sandbox bytes.
    tokio::spawn(async move {
        while let Some(msg) = push_rx.recv().await {
            match msg {
                PushMsg::Data(bytes) => {
                    if wr.write_all(&bytes).await.is_err() {
                        break;
                    }
                }
                PushMsg::Close => break,
                PushMsg::Resize { .. } => {}
            }
        }
    });
}
