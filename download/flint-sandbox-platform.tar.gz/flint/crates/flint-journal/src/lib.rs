//! Crash-consistent journaling for sandboxes (ARCHITECTURE §6).
//!
//! Every mutating sandbox operation is written to a CRC-framed
//! write-ahead log *before* it is dispatched to the VM (write-ahead
//! discipline). On recovery we replay the valid prefix of the WAL onto the
//! last restored snapshot, deduplicating by `op_id` (idempotency keys).
//! File ops carry their full payload so replay is deterministic; exec /
//! process spawns are journaled for audit and restart, not byte-replay.

pub mod manifest;
pub mod ops;
pub mod packer;
pub mod wal;

pub use manifest::{Layer, LayerKind, SnapshotKind, SnapshotManifest};
pub use ops::{Op, OpError};
pub use wal::{recover_records, Wal, WalRecord};

use std::io::Write;

/// Sync policy for WAL appends.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FsyncPolicy {
    /// fsync after every record (default; safest).
    Always,
    /// fsync only on explicit barriers (faster; bounded loss window).
    Barrier,
}

impl FsyncPolicy {
    pub fn from_str(s: &str) -> Self {
        if s.eq_ignore_ascii_case("barrier") {
            Self::Barrier
        } else {
            Self::Always
        }
    }
}

pub fn fsync_file(f: &std::fs::File) -> std::io::Result<()> {
    f.sync_all()
}

pub fn fsync_path(p: &std::path::Path) -> std::io::Result<()> {
    let f = std::fs::File::open(p)?;
    f.sync_data()
}

/// Append `bytes` to a file + fsync (small helper used across crates).
pub fn append_and_sync(path: &std::path::Path, bytes: &[u8]) -> std::io::Result<()> {
    use std::fs::OpenOptions;
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    f.write_all(bytes)?;
    f.sync_all()
}
