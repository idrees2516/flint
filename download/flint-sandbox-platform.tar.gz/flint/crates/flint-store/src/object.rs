//! Object storage for snapshot/template blobs.
//!
//! - `LocalObjectStore`: content-addressed files under a root dir
//!   (atomic tmp+rename writes). Default; zero-dependency.
//! - `S3ObjectStore`: minimal S3-compatible client (SigV4-signed) via
//!   `ureq` — works with AWS S3, MinIO, Cloudflare R2, Garage.
//!
//! Both are sync (`ureq` is a blocking client); the worker calls them via
//! `tokio::task::spawn_blocking` because snapshot I/O is large and rare.

use flint_core::{FlintError, Result};
use hmac::{Hmac, Mac};
use sha2::{Digest, Sha256};
use std::io::Read;
use std::path::{Path, PathBuf};

type HmacSha256 = Hmac<Sha256>;

pub trait ObjectStore: Send + Sync {
    fn put(&self, key: &str, data: &[u8]) -> Result<()>;
    /// Stream a large object to storage from a file path.
    fn put_file(&self, key: &str, path: &Path) -> Result<u64>;
    fn get(&self, key: &str) -> Result<Vec<u8>>;
    fn get_to_file(&self, key: &str, dest: &Path) -> Result<u64>;
    fn delete(&self, key: &str) -> Result<()>;
    fn exists(&self, key: &str) -> Result<bool>;
    fn list(&self, prefix: &str) -> Result<Vec<String>>;
}

fn sanitize_key(key: &str) -> Result<String> {
    if key.contains("..") || key.starts_with('/') || key.contains('\0') {
        return Err(FlintError::InvalidParam { msg: format!("bad object key: {key}") });
    }
    Ok(key.to_string())
}

// ---------------------------------------------------------------------------
// Local
// ---------------------------------------------------------------------------

pub struct LocalObjectStore {
    root: PathBuf,
}

impl LocalObjectStore {
    pub fn new(root: &Path) -> Result<Self> {
        std::fs::create_dir_all(root)?;
        Ok(Self { root: root.to_path_buf() })
    }

    fn path_for(&self, key: &str) -> Result<PathBuf> {
        let key = sanitize_key(key)?;
        let p = self.root.join(&key);
        if let Some(parent) = p.parent() {
            std::fs::create_dir_all(parent)?;
        }
        Ok(p)
    }
}

impl ObjectStore for LocalObjectStore {
    fn put(&self, key: &str, data: &[u8]) -> Result<()> {
        let p = self.path_for(key)?;
        let tmp = p.with_extension("tmp.part");
        std::fs::write(&tmp, data)?;
        std::fs::rename(&tmp, &p)?;
        flint_journal::fsync_path(&p)?;
        Ok(())
    }

    fn put_file(&self, key: &str, path: &Path) -> Result<u64> {
        let data = std::fs::read(path)?;
        self.put(key, &data)?;
        Ok(data.len() as u64)
    }

    fn get(&self, key: &str) -> Result<Vec<u8>> {
        let p = self.path_for(key)?;
        std::fs::read(&p).map_err(|_| FlintError::NotFound { resource: "object", id: key.to_string() })
    }

    fn get_to_file(&self, key: &str, dest: &Path) -> Result<u64> {
        let data = self.get(key)?;
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(dest, &data)?;
        Ok(data.len() as u64)
    }

    fn delete(&self, key: &str) -> Result<()> {
        let p = self.path_for(key)?;
        let _ = std::fs::remove_file(&p);
        Ok(())
    }

    fn exists(&self, key: &str) -> Result<bool> {
        let p = self.path_for(key)?;
        Ok(p.exists())
    }

    fn list(&self, prefix: &str) -> Result<Vec<String>> {
        let prefix = sanitize_key(prefix)?;
        let mut out = Vec::new();
        let start_dir = self.root.join(&prefix);
        let walk_root = if start_dir.is_dir() { start_dir } else { self.root.clone() };
        collect_keys(&walk_root, &self.root, &mut out);
        out.retain(|k| k.starts_with(&prefix));
        out.sort();
        Ok(out)
    }
}

fn collect_keys(dir: &Path, root: &Path, out: &mut Vec<String>) {
    let Ok(entries) = std::fs::read_dir(dir) else { return };
    for e in entries.flatten() {
        let p = e.path();
        if p.is_dir() {
            collect_keys(&p, root, out);
        } else if let Ok(rel) = p.strip_prefix(root) {
            out.push(rel.to_string_lossy().replace('\\', "/"));
        }
    }
}

// ---------------------------------------------------------------------------
// S3 (SigV4, minimal)
// ---------------------------------------------------------------------------

#[derive(Clone)]
pub struct S3ObjectStore {
    endpoint: String,
    region: String,
    bucket: String,
    access_key: String,
    secret_key: String,
    path_style: bool,
}

impl S3ObjectStore {
    pub fn new(
        endpoint: &str,
        region: &str,
        bucket: &str,
        access_key: &str,
        secret_key: &str,
        path_style: bool,
    ) -> Self {
        Self {
            endpoint: endpoint.trim_end_matches('/').to_string(),
            region: region.to_string(),
            bucket: bucket.to_string(),
            access_key: access_key.to_string(),
            secret_key: secret_key.to_string(),
            path_style,
        }
    }

    pub fn from_env(endpoint: &str, region: &str, bucket: &str, path_style: bool) -> Option<Self> {
        let access_key = std::env::var("AWS_ACCESS_KEY_ID").ok()?;
        let secret_key = std::env::var("AWS_SECRET_ACCESS_KEY").ok()?;
        Some(Self::new(endpoint, region, bucket, &access_key, &secret_key, path_style))
    }

    fn url_for(&self, key: &str) -> (String, String, String) {
        // returns (url, host_header, canonical_path)
        let key_enc = key
            .split('/')
            .map(|seg| {
                let mut s = String::new();
                for b in seg.bytes() {
                    const UNRESERVED: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~";
                    if UNRESERVED.contains(b as char) {
                        s.push(b as char);
                    } else {
                        s.push_str(&format!("%{b:02X}"));
                    }
                }
                s
            })
            .collect::<Vec<_>>()
            .join("/");
        if self.path_style {
            let url = format!("{}/{}/{}", self.endpoint, self.bucket, key_enc);
            let host = self.endpoint.trim_start_matches("https://").trim_start_matches("http://").to_string();
            (url, host, format!("/{}/{key_enc}", self.bucket))
        } else {
            let host = format!(
                "{}.{}",
                self.bucket,
                self.endpoint.trim_start_matches("https://").trim_start_matches("http://")
            );
            let scheme = if self.endpoint.starts_with("http://") { "http" } else { "https" };
            (format!("{scheme}://{host}/{key_enc}"), host, format!("/{key_enc}"))
        }
    }

    fn sign(
        &self,
        method: &str,
        host: &str,
        path: &str,
        query: &str,
        payload: &[u8],
    ) -> Vec<(String, String)> {
        let now = chrono::Utc::now();
        let amz_date = now.format("%Y%m%dT%H%M%SZ").to_string();
        let date = now.format("%Y%m%d").to_string();
        let payload_hash = if payload.len() <= 8 * 1024 * 1024 {
            hex::encode(Sha256::digest(payload))
        } else {
            "UNSIGNED-PAYLOAD".to_string()
        };

        let canonical_headers = format!("host:{host}\nx-amz-content-sha256:{payload_hash}\nx-amz-date:{amz_date}\n");
        let signed_headers = "host;x-amz-content-sha256;x-amz-date";
        let canonical_request = format!(
            "{method}\n{path}\n{query}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
        );

        let scope = format!("{}/{}/s3/aws4_request", date, self.region);
        let string_to_sign = format!(
            "AWS4-HMAC-SHA256\n{amz_date}\n{scope}\n{}",
            hex::encode(Sha256::digest(canonical_request.as_bytes()))
        );

        fn hmac_sha(key: &[u8], data: &[u8]) -> Vec<u8> {
            let mut mac = HmacSha256::new_from_slice(key).expect("hmac key");
            mac.update(data);
            mac.finalize().into_bytes().to_vec()
        }

        let k_date = hmac_sha(format!("AWS4{}", self.secret_key).as_bytes(), date.as_bytes());
        let k_region = hmac_sha(&k_date, self.region.as_bytes());
        let k_service = hmac_sha(&k_region, b"s3");
        let k_signing = hmac_sha(&k_service, b"aws4_request");
        let signature = hex::encode(hmac_sha(&k_signing, string_to_sign.as_bytes()));

        let auth = format!(
            "AWS4-HMAC-SHA256 Credential={}/{}, SignedHeaders={}, Signature={}",
            self.access_key, scope, signed_headers, signature
        );
        vec![
            ("Authorization".into(), auth),
            ("x-amz-date".into(), amz_date),
            ("x-amz-content-sha256".into(), payload_hash),
        ]
    }

    fn ureq_call(
        &self,
        method: &str,
        key: &str,
        query: &str,
        body: Vec<u8>,
    ) -> Result<ureq::Response> {
        let (url, host, path) = self.url_for(key);
        let mut full_url = url;
        if !query.is_empty() {
            full_url.push('?');
            full_url.push_str(query);
        }
        let headers = self.sign(method, &host, &path, query, &body);
        let mut req = match method {
            "GET" => ureq::get(&full_url),
            "PUT" => ureq::put(&full_url),
            "DELETE" => ureq::delete(&full_url),
            "HEAD" => ureq::request("HEAD", &full_url),
            _ => ureq::request(method, &full_url),
        };
        for (k, v) in headers {
            req = req.set(&k, &v);
        }
        req.send_bytes(&body).map_err(|e| {
            let msg = e.to_string();
            if msg.contains("404") {
                FlintError::NotFound { resource: "object", id: key.to_string() }
            } else {
                FlintError::Internal(format!("s3: {msg}"))
            }
        })
    }

    fn read_to_vec(&self, key: &str, resp: ureq::Response) -> Result<Vec<u8>> {
        let mut buf = Vec::new();
        let mut reader = resp.into_reader();
        reader
            .read_to_end(&mut buf)
            .map_err(|e| FlintError::Internal(format!("s3 read: {e}")))?;
        if buf.is_empty() {
            return Err(FlintError::NotFound { resource: "object", id: key.to_string() });
        }
        Ok(buf)
    }
}

impl ObjectStore for S3ObjectStore {
    fn put(&self, key: &str, data: &[u8]) -> Result<()> {
        sanitize_key(key)?;
        let resp = self.ureq_call("PUT", key, "", data.to_vec())?;
        if resp.status() >= 300 {
            return Err(FlintError::Internal(format!("s3 put status {}", resp.status())));
        }
        Ok(())
    }

    fn put_file(&self, key: &str, path: &Path) -> Result<u64> {
        let data = std::fs::read(path)?;
        self.put(key, &data)?;
        Ok(data.len() as u64)
    }

    fn get(&self, key: &str) -> Result<Vec<u8>> {
        sanitize_key(key)?;
        let resp = self.ureq_call("GET", key, "", Vec::new())?;
        self.read_to_vec(key, resp)
    }

    fn get_to_file(&self, key: &str, dest: &Path) -> Result<u64> {
        let data = self.get(key)?;
        if let Some(parent) = dest.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(dest, &data)?;
        Ok(data.len() as u64)
    }

    fn delete(&self, key: &str) -> Result<()> {
        sanitize_key(key)?;
        let _ = self.ureq_call("DELETE", key, "", Vec::new())?;
        Ok(())
    }

    fn exists(&self, key: &str) -> Result<bool> {
        sanitize_key(key)?;
        match self.ureq_call("HEAD", key, "", Vec::new()) {
            Ok(resp) => Ok(resp.status() < 300),
            Err(FlintError::NotFound { .. }) => Ok(false),
            Err(e) => Err(e),
        }
    }

    fn list(&self, prefix: &str) -> Result<Vec<String>> {
        let mut keys = Vec::new();
        let mut token: Option<String> = None;
        loop {
            let mut query = format!("list-type=2&prefix={}", prefix.replace('/', "%2F"));
            if let Some(t) = &token {
                query.push_str(&format!("&continuation-token={t}"));
            }
            let resp = self.ureq_call("GET", "", &query, Vec::new())?;
            let body = resp.into_string().map_err(|e| FlintError::Internal(format!("s3 list: {e}")))?;
            // Minimal XML scrape: <Key>...</Key> entries.
            let mut rest = body.as_str();
            while let Some(start) = rest.find("<Key>") {
                let end = rest[start + 5..].find("</Key>").map(|i| start + 5 + i);
                match end {
                    Some(end) => {
                        keys.push(rest[start + 5..end].to_string());
                        rest = &rest[end + 6..];
                    }
                    None => break,
                }
            }
            token = extract_tag(&body, "NextContinuationToken");
            if token.is_none() {
                break;
            }
        }
        Ok(keys)
    }
}

fn extract_tag(xml: &str, tag: &str) -> Option<String> {
    let open = format!("<{tag}>");
    let close = format!("</{tag}>");
    let s = xml.find(&open)? + open.len();
    let e = xml[s..].find(&close)? + s;
    Some(xml[s..e].to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn local_store_roundtrip() {
        let tmp = tempfile::tempdir().unwrap();
        let store = LocalObjectStore::new(tmp.path()).unwrap();
        store.put("snapshots/sbx_1/layers/fs.tar.gz", b"blob").unwrap();
        assert!(store.exists("snapshots/sbx_1/layers/fs.tar.gz").unwrap());
        assert_eq!(store.get("snapshots/sbx_1/layers/fs.tar.gz").unwrap(), b"blob");
        let listed = store.list("snapshots/").unwrap();
        assert_eq!(listed, vec!["snapshots/sbx_1/layers/fs.tar.gz".to_string()]);
        store.delete("snapshots/sbx_1/layers/fs.tar.gz").unwrap();
        assert!(!store.exists("snapshots/sbx_1/layers/fs.tar.gz").unwrap());
    }

    #[test]
    fn rejects_bad_keys() {
        let tmp = tempfile::tempdir().unwrap();
        let store = LocalObjectStore::new(tmp.path()).unwrap();
        assert!(store.put("../escape", b"x").is_err());
        assert!(store.put("/abs", b"x").is_err());
    }
}
